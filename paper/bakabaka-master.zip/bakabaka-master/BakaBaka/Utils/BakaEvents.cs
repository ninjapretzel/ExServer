using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

/// <summary>
///		<para> 
///				Abstract class providing boilerplate for event handlers.
///				Keys (<typeparamref name="T"/>) must be enum types, 
///				Data payloads (<typeparamref name="D"/>) can be whatever you want. 
///		</para>
///		<para> Automatically registers all methods matching 'onXXX(Event)' pattern </para>
///		<para> XXX is the name of a given element in the enumeration <typeparamref name="T"/>. </para>
/// </summary>
/// <typeparam name="T"> Key/Event type </typeparam>
/// <typeparam name="D"> Data payload type </typeparam>
public abstract class EventHandler<T, D> : EnumDictionary<T, Action<EventHandler<T,D>.Event> > where T : struct, IComparable, IFormattable, IConvertible {
	
	/// <summary> If a handler is not found, do we sperg about it? </summary>
	public bool reportWarnings;

	/// <summary> Basic constructor. Must inherit this to get the functionality. </summary>
	public EventHandler(bool reportWarnings = true) {
		this.reportWarnings = reportWarnings;
		LoadMethods(reportWarnings);
	}

	/// <summary> Blob holding a single event data to pass to handler methods.  </summary>
	public class Event {
		/// <summary> Event Type </summary>
		public T type { get; private set; }
		/// <summary> Data Payload </summary>
		public D data { get; private set; }
		/// <summary> Instigator of event </summary>
		public object source { get; private set; }
		public Event(T t, D d = default(D), object s = null) { type = t; data = d; source = s; }
	}

	/// <summary> This method always gets called when an event is passed to this object. </summary>
	public virtual void always(Event e) { }

	/// <summary> Loads all methods of the 'onXXXX' method pattern in the class. </summary>
	private void LoadMethods(bool reportWarnings = true) {
		Type tt = typeof(T);
		Type t = GetType();
		Type[] expected = new [] { typeof(Event) };
		if (tt.IsEnum) {
			string[] names = Enum.GetNames(tt);
			foreach (var name in names) {
				var method = t.GetMethod("on"+name, expected);
				if (method != null) {
					T elem; 
					// Don't need to check, never going to fail 
					//		(unless someone's doing concurrent in-place string modification)
					// but gives us a value of the correct type.
					Enum.TryParse(name, true, out elem);
					this[elem] = method.CreateDelegate(typeof(Action<Event>), this) as Action<Event>;
				} else if (reportWarnings) {
					Debug.LogWarning($"No handler on{name} for element {name} found!");
				}
			}
		} else {
			throw new Exception($"EventHandler: Type {tt} is not an enum!");
		}
	}

	/// <summary> Sends an event to this handler. </summary>
	/// <param name="type"> Type of event </param>
	/// <param name="data"> Data payload for event (optional. Uses default value if not provided) </param>
	/// <param name="source"> Source object or instigator. Uses null if not provided) </param>
	public void SendEvent(T type, D data = default(D), object source = null) {
		Event e = new Event(type, data, source);
		always(e);
		if (ContainsKey(type)) {
			this[type](e);
		} else {
			if (reportWarnings) {
				Debug.LogWarning($"EventHandler: No handler for on{type}!");
			}
		}
	}

}

/// <summary> Load/runtime utility to load some information about Enums. </summary>
/// <typeparam name="E"> Enum type to check information about </typeparam>
public static class Enum<E> where E : struct, IComparable, IFormattable, IConvertible {

	/// <summary> typeof(E) </summary>
	private static Type type = typeof(E);

	/// <summary> Array of all elements in the Enum, sorted. Please don't modify. Thanks </summary>
	public static E[] __SortedElements { get; private set; }
	
	/// <summary> All the elements in the enum. </summary>
	public static E[] Elements { get; private set; }

	/// <summary> Is this enum Ordinal? (values range [0, n-1], no repeats, no duplicates) </summary>
	private static bool _IsOrdinal;
	/// <summary> Is this enum Ordinal? (values range [0, n-1], no repeats, no duplicates) </summary>
	public static bool IsOrdinal { get { return _IsOrdinal; } }

	/// <summary> What is the index of the given Enum object? </summary>
	/// <param name="e"> Enum object to get the index of. </param>
	/// <returns> Index of with best guess. </returns>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static int IndexOf(E e) {
		if (_IsOrdinal) { return Convert.ToInt32(e); }
		try { return Array.BinarySearch(__SortedElements, e); }
		catch { return -1; }
	}

	/// <summary> Hack to get around performance hits due to static initializer. </summary>
	public static bool loaded { get; private set; } = Load();
	/// <summary> Loads data for the given enum. A static initializer without the performance hit. </summary>
	/// <returns> True. </returns>
	private static bool Load() {
		if (typeof(E).IsEnum) {
			
			E[] elem = Enum.GetValues(typeof(E)) as E[];
			Elements = elem;

			E[] selem = Enum.GetValues(typeof(E)) as E[];
			Array.Sort(selem);
			__SortedElements = selem;

			_IsOrdinal = CheckOrdinal();
			return true;
		} else {
			Debug.Log($"Yeah no, {type} is not an enum.");
			
			return false;
		}

	}

	/// <summary> Checks that the given enum is ordinal. </summary>
	/// <returns> True if it is ordinal, false otherwise. </returns>
	private static bool CheckOrdinal() {
		long lo = long.MaxValue;
		long hi = long.MinValue;

		foreach (E val in __SortedElements) {
			long v = Convert.ToInt64(val);
			
			if (v < lo) { lo = v; }
			if (v > hi) { hi = v; }
		}

		return (lo == 0 && hi == Elements.Length-1);
	}

	/// <summary> Gets the <typeparamref name="E"/> value of a given long. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(long v)		{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given int. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(int v)		{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given short. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(short v)	{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given byte. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(byte v)		{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given ulong. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(ulong v)	{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given uint. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(uint v)		{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given ushort. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(ushort v)	{ return (E)Enum.ToObject(type, v); }
	/// <summary> Gets the <typeparamref name="E"/> value of a given sbyte. </summary>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static E ValueOf(sbyte v)	{ return (E)Enum.ToObject(type, v); }
	
}

/// <summary> Optimized dictionary using Enum values as keys. </summary>
/// <typeparam name="K"> Key type. Must be an Enum type. </typeparam>
/// <typeparam name="V"> Value type. Any value type is allowed. </typeparam>
public class EnumDictionary<K, V> : IDictionary<K, V>
		where K : struct, IComparable, IFormattable, IConvertible {
	private static int _Length = (Enum<K>.Elements != null) ? Enum<K>.Elements.Length : 0;
	private static int Length { get { return _Length; } }

	private V[] values;
	private bool[] sets;

	public EnumDictionary() {
		sets = new bool[Length];
		values = new V[Length];
	}

	public static bool IsOrdinal { get { return Enum<K>.IsOrdinal; } }

	public ICollection<K> Keys { get { return Enum<K>.Elements; } }

	public ICollection<V> Values { get { return new List<V>(values); } }

	public int Count { get { return Length; } }

	public bool IsReadOnly { get { return false; } }

	public V this[K key] {
		get { return values[Enum<K>.IndexOf(key)]; }
		set { 
			var idx = Enum<K>.IndexOf(key); 
			values[idx] = value; 
			sets[idx] = true;
		}
	}

	public void Add(K key, V value) { this[key] = value; }

	public bool ContainsKey(K key) { return sets[Enum<K>.IndexOf(key)]; }

	public bool Remove(K key) { 
		bool wasSet = ContainsKey(key);
		this[key] = default(V); 
		return wasSet;
	}

	public bool TryGetValue(K key, out V value) {
		value = this[key];
		return ContainsKey(key);
	}

	public void Add(KeyValuePair<K, V> item) { this[item.Key] = item.Value; }

	public void Clear() {
		for (int i = 0; i < values.Length; i++) { values[i] = default(V); sets[i] = false; }	
	}

	public bool Contains(KeyValuePair<K, V> item) {
		if (ContainsKey(item.Key)) {
			object o1 = item.Value;
			object o2 = this[item.Key];
			return (o1 == o2);
		}
		return false;
	}

	public void CopyTo(KeyValuePair<K, V>[] array, int arrayIndex) {
		for (int i = 0; i < Length; i++) {
			array[arrayIndex + i] = new KeyValuePair<K, V>(Enum<K>.__SortedElements[i], values[i]);
		}
	}

	public bool Remove(KeyValuePair<K, V> item) { return Remove(item.Key); }

	public IEnumerator<KeyValuePair<K, V>> GetEnumerator() {
		for (int i = 0; i < Length; i++) {
			yield return new KeyValuePair<K, V>(Enum<K>.__SortedElements[i], values[i]);
		}
	}

	IEnumerator IEnumerable.GetEnumerator() {
		for (int i = 0; i < Length; i++) {
			yield return new KeyValuePair<K, V>(Enum<K>.__SortedElements[i], values[i]);
		}
	}
}
