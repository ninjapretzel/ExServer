using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaDB;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using LevelUpper.Extensions;

namespace BakaCR {
	
	/// <summary> Core class for wrapping content repository functionality. </summary>
	public class Repository {

		/// <summary> Static set of repositories. </summary>
		private static IDictionary<string, Repository> repos = new ConcurrentDictionary<string, Repository>();
		
		/// <summary> Locate the repository with the given path. </summary>
		/// <param name="path"> Path to find database </param>
		/// <param name="compress"> Should the repository be compressed? (Only affects initialization) </param>
		/// <returns> Repository object for path. </returns>
		public static Repository Local(string path = "repo", bool compress = false) {
			if (!repos.ContainsKey(path)) { repos[path] = new Repository(path, compress); }
			return repos[path];
		}

		/// <summary> Closes all open nodes in the repository, and deletes it from disk. </summary>
		/// <param name="path"> Path to delete. </param>
		public static void Drop(string path) {
			Repository repo = Local(path);
			if (!repo.root.invalid) {
				repo.root.Close(false);
			}

			DB.Drop(path);
			repo.__Reinitialize();
		}

		/// <summary> LocalDB database to use. Shares path. </summary>
		internal LocalDB database;

		/// <summary> Root node of the repository. </summary>
		public Node root { get; private set; } 

		/// <summary> Private constructor </summary>
		/// <param name="path"> Path of database backing repository </param>
		/// <param name="compress"> Should the database be compressed? </param>
		private Repository(string path = "repo", bool compress = false) {
			database = DB.Local(path, compress);
			__Reinitialize();
		}

		/// <summary> Re-initializes the repository. Use at your own risk. 
		/// Intended use is to recover a repository that has had it's root closed. </summary>
		public void __Reinitialize() {
			if (root != null && !root.invalid) {
				root.Close(false);
			}
			root = new Node();
			root.Initialize(this);
		}

		/// <summary> Gets the node at the given path.  </summary>
		/// <param name="path"> Path to get node at </param>
		/// <returns> Node at given path. </returns>
		public Node Get(string path) {
			path = path.Trim();
			if (path == "" || path == "/") {
				return root;
			}
			return root.Get(path);
		}

		/// <summary> Gets the property at the path as a T </summary>
		/// <typeparam name="T"> Generic Type </typeparam>
		/// <param name="path"> Path to get property from </param>
		/// <param name="defaultValue"> Value to return if property does not exist </param>
		/// <returns> property at path as a T, or defaultValue if it does not exist. </returns>
		public T Pull<T>(string path, T defaultValue = default(T)) {
			return root.Pull<T>(path, defaultValue);
		}


		/// <summary> Sets the Node or Property at path to the given value </summary>
		/// <param name="path"> path to set </param>
		/// <param name="value"> Value to set to (defaults to null, meaning node creation) </param>
		/// <param name="save"> Should the operation after completion? </param>
		/// <returns> Node that had its property changed </returns>
		public Node Set(string path, JsonValue value = null, bool save = true) {
			return root.Set(path, value, save);
		}

		/// <summary> Alias for Set with "save=false" </summary>
		/// <param name="path"> path to set </param>
		/// <param name="value"> Value to set (defaults to null, meaning node creation) </param>
		/// <returns> Node that had its property changed </returns>
		public Node Put(string path, JsonValue value = null) {
			return root.Put(path, value);
		}

		/// <summary> Closes the root node of the repository. Recursivly saves nodes by default, pass "false" to not save. </summary>
		/// <param name="save"> Should the state be saved to disk?</param>
		public void Close(bool save = true) {
			root.Close(save);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="relpath"></param>
		/// <param name="saveFirst"></param>
		/// <returns></returns>
		public Node Reload(string relpath, bool saveFirst = false) {
			root.Get(relpath).Close(saveFirst);
			return root.Get(relpath);
		}

	}

	/// <summary> Repository Node. </summary>
	public class Node {

		/// <summary> Name of node </summary>
		public string name { get; private set; }

		/// <summary> Path to the folder this node resides in. </summary>
		public string path { get; private set; }

		/// <summary> Path to the folder in the database representing this node. </summary>
		public string id { get { return parent == null ? "" : path + "/" + name; } }

		/// <summary> Path in database to metafile </summary>
		public string metaPath { get { return id + "/meta.wtf"; } }

		/// <summary> Path to this item, as a folder (ending in / if not root) </summary>
		public string folderPath { get { return parent == null ? "" : id + "/"; } }

		/// <summary> The repository this node belongs to. </summary>
		public Repository repo { get; private set; }

		/// <summary> Access to repo database instance. </summary>
		internal LocalDB database { get { return repo.database; } }

		/// <summary> Parent of the node. </summary>
		public Node parent { get; private set; }
		
		/// <summary> Metainfo- version of node </summary>
		public int version { get; private set; }
		
		/// <summary> GUID of node </summary>
		public Guid guid { get; private set; }

		/// <summary> Embedded properties </summary>
		public JsonObject properties { get; private set; }
		
		/// <summary> Loaded, Direct children </summary>
		public IDictionary<string, Node> children { get; private set; }

		/// <summary> Is this node invalid? (Closed) </summary>
		public bool invalid { get; private set; } = false;
		
		//private string _basePath;

		/// <summary> Empty constructor. Constructs scaffolding and nullifies other fields, but performs no logic. </summary>
		public Node() {
			name = path = null;
			repo = null;
			parent = null;
			version = -1;
			guid = Guid.Empty;
			properties = new JsonObject();
			children = new ConcurrentDictionary<string, Node>();
		}

		public void CheckValid() {
			if (invalid) { throw new InvalidOperationException("Cannot operate on an invalid node!"); }
		}

		private static readonly char[] PATH_SPLIT = { '/' };


		/// <summary> Gets all children nodes as are currently represented on the disk. </summary>
		/// <returns> Enumerable of string of relative paths of all children on disk. </returns>
		public IEnumerable<string> GetChildren() {
			CheckValid();
			return Directory.GetDirectories(database.dbPath + id).Select(dir => dir.ForwardSlashPath().FromLast('/'));
		}


		/// <summary> Retrieves the node at a given path </summary> 
		/// <param name="relpath"> Relative path from the current node.  </param>
		/// <returns> Node at the given path, if open or exists, or </returns>
		public Node Get(string relpath) {
			CheckValid();
			if (relpath.Contains("/")) {
				string[] splits = relpath.Split(PATH_SPLIT, StringSplitOptions.RemoveEmptyEntries);
				Node trace = this;

				for (int i = 0; i < splits.Length; i++) {
					string split = splits[i];
					trace = trace.Get(split);
					if (trace == null) { return null; }
				}
				return trace;
			}

			if (children.ContainsKey(relpath)) {
				return children[relpath];
			}

			// Check if node exists at all
			if (database.Exists(id + "/" + relpath + "/meta.wtf")) {
				// If so, make it and add it to children.
				return MakeChild(relpath);
			}

			return null;
		}

		/// <summary> Does this node have either a child or property at relpath? </summary>
		/// <param name="relpath">Path to check for</param>
		/// <returns> True if there is a child or property at relpath </returns>
		public bool Has(string relpath) {
			CheckValid();
			if (relpath.Contains("/")) {
				string[] splits = relpath.Split(PATH_SPLIT, StringSplitOptions.RemoveEmptyEntries);
				Node trace = this;

				for (int i = 0; i < splits.Length-1; i++) {
					string split = splits[i];
					trace = trace.Get(split);
					if (trace == null) { return false; }
				}
				
				string last = splits[splits.Length - 1];
				
				return trace.HasDirectChild(last) || trace.properties.Has(last);
			}
			
			return HasDirectChild(relpath) || properties.Has(relpath);
		}

		/// <summary> Is there directly a child </summary>
		/// <param name="name"> name of child to check for </param>
		/// <returns> True</returns>
		private bool HasDirectChild(string name) {
			if (children.ContainsKey(name)) { return true; }
			return database.Exists(id + "/" + name + "/meta.wtf");
		}
		
		/// <summary> Gets a property as a T.  </summary>
		/// <typeparam name="T"> Generic type </typeparam>
		/// <param name="relpath"> Path to check for property </param>
		/// <param name="defaultValue"> Default value to use, if property does not exist </param>
		/// <returns> Property interpreted as a T, or defaultValue if it does not exist. </returns>
		public T Pull<T>(string relpath, T defaultValue = default(T) ) {
			CheckValid();

			if (relpath.Contains("/")) {
				string[] splits = relpath.Split(PATH_SPLIT, StringSplitOptions.RemoveEmptyEntries);
				Node trace = this;
				
				for (int i = 0; i < splits.Length-1; i++) {
					string split = splits[i];
					trace = trace.Get(split);
					if (trace == null) { return defaultValue; }
				}
				
				return trace.properties.Pull<T>(splits[splits.Length-1], defaultValue);
			}

			return properties.Pull<T>(relpath, defaultValue);
		}

		/// <summary> Sets the given relative path from the current node, to the given data. If Save is set, saves. Otherwise, returns the modified node. </summary>
		/// <param name="relpath"> Relative xpath to navigate. </param>
		/// <param name="data"> Data to set (defaults to null, meaning node creation) </param>
		/// <param name="save"> Flag to save, or not. Defaults to true, set false to perform batch operations with manual saves. </param>
		/// <returns> Modified or created node </returns>
		public Node Set(string relpath, JsonValue data = null, bool save = true) {
			CheckValid();
			// Split and traverse XPATH.
			if (relpath.Contains("/")) {
				// avoid any empty strings.
				string[] splits = relpath.Split(PATH_SPLIT, StringSplitOptions.RemoveEmptyEntries);
				Node trace = this;

				for (int i = 0; i < splits.Length; i++) {
					string split = splits[i];

					trace = trace.Set(split, i == (splits.Length - 1) ? data : null);
					if (save && i == (splits.Length - 1)) {
						trace.Save();
					}
				}

				// Return last visited node.
				return trace;
			}

			// Otherwise, we have a singular path.
			// If we have a child by that path already, just grab it.
			if (children.ContainsKey(relpath)) {
				// If data is not null, we are setting.
				// If we are setting, we only want to apply objects to children.
				// The xpath traversal should prevent any mishaps
				// but someone might call this method wrong.
				if (data != null && data is JsonObject) {
					var child = children[relpath];
					child.properties.Set(data as JsonObject);
					if (save) { child.Save(); }
					return child;

				} else if (data == null) {
					// Otherwise, we are just getting the node. 
					return children[relpath];
				}
			}

			// Otherwise, we need to create a child, or add a property.
			if (data != null && !data.isObject) {
				// If data exists and is not an object, 
				// just apply it to the current node.
				properties[relpath] = data;
				if (save) { Save(); }
				return this;
			}

			// Otherwise, at this point, we need to create a new node below.
			Node node = MakeChild(relpath);

			if (data != null && data.isObject) {
				node.properties.Set(data as JsonObject);
				if (save) { node.Save(); }
			}

			return node;
		}

		/// <summary> Alias for Set with "save=false" </summary>
		/// <param name="relpath"> Relative xpath to navigate. </param>
		/// <param name="data"> Data to set (defaults to null, meaning node creation)</param>
		/// <returns> Modified or created node. </returns>
		public Node Put(string relpath, JsonValue data = null) { return Set(relpath, data, false); }
		
		/// <summary> Close the node, and all of its children, and removes itself from it's parent's live list. </summary>
		/// <param name="save"> Should changes be saved? </param>
		public void Close(bool save = true) {
			CheckValid();
			children.Select(pair => pair.Value)
				.ToList()
				.ForEach((kid => { kid.Close(save); }));
			
			if (parent != null) {
				parent.children.Remove(name);
			} else {
				// We root node. 
				// Closing is okay, but the repo must be reinitialized.
			}
			if (save) { Save(); }
			invalid = true;
			database.Close(metaPath);

			// Assertion... meh.
			if (children.Count != 0) {
				throw new Exception("BakaCR.Repository.Node: Closed all children, but still has open children! Not good!");
			}
		}

		/// <summary> Reloads the given child node's subtree. 
		/// Optionally, can save changes before reloading, 
		/// but normally you reload because you don't want to save. </summary>
		/// <param name="relpath"> Relative path to close/reload. </param>
		/// <param name="saveFirst"> Save any changes before reloading? Default is false. </param>
		/// <returns> Node representing refreshed subtree </returns>
		public Node Reload(string relpath, bool saveFirst = false) {
			CheckValid();

			Node old = Get(relpath);
			old.Close(saveFirst);

			return Get(relpath);
		}

		/// <summary> Reloads the given node and it's subtree. 
		/// Optionally, can save changes before reloading, 
		/// but normally you reload because you don't want to save.</summary>
		/// <param name="saveFirst"> Save any changes before reloading? Default is false. </param>
		/// <returns> Node representing refreshed subtree </returns>
		public Node Reload(bool saveFirst = false) {
			CheckValid();

			Close(saveFirst);
			if (parent != null) {
				return parent.Get(name);
			} else {
				repo.__Reinitialize();
				return repo.root;
			}

		}

		/// <summary> Creates a child node under the current node, with the given name. </summary>
		/// <param name="relpath"> Name of new node, path from current node. </param>
		/// <returns> Newly created node </returns>
		private Node MakeChild(string relpath) {
			Node node = new Node();
			children[relpath] = node;
			node.parent = this;
			node.repo = repo;

			node.path = id;
			node.name = relpath;
			node.LoadProperties();
			return node;
		}

		/// <summary> Initializes this Node as the root of the given repository. </summary>
		internal void Initialize(Repository repo) {
			this.repo = repo;
			name = "";
			path = "";
			parent = null;
			LoadProperties();
		}
		
		/// <summary> Increments version and saves THIS NODE'S properties to database. </summary>
		internal void Save() {
			CheckValid();
			version++;
			properties["version"] = version;
			database.Set(metaPath, properties, true);
		}
		
		/// <summary> 
		///		Loads properties object for the given node. 
		///		Initializes them if they do not already exist.
		///	</summary>
		internal void LoadProperties() {
			JsonObject props;
			bool existed;
			
			props = database.Open(metaPath, out existed) as JsonObject;
			if (existed) {
				properties.Set(props);

				version = properties["version"].intVal;
				guid = Guid.Parse(properties["guid"]);

			} else {
				// Will be incremented to 0 and set into properties
				//		when saved.
				version = -1;
				guid = Guid.NewGuid();
				properties["guid"] = guid.ToString();
				
				Save();
			}
		}

		
	}

}
