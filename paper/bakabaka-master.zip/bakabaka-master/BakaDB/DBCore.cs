using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BakaDB {

	/// <summary> 
	/// Static class holding a collection of existing Database objects. 
	/// TBD: 
	/// - Should handle client connections into remote databases. 
	/// - Should be able to request sync from/to remote databases.
	/// - Should handle some simple queries
	/// </summary>
	public static class DB {

		/// <summary> Local In-Memory databases </summary>
		public static IDictionary<string, LocalDB> dbs = new ConcurrentDictionary<string, LocalDB>();

		/// <summary> Helper function to make sure multiple instances of the same local database are not created. </summary>
		/// <param name="path"> Path to open </param>
		/// <param name="compress"> Whether or not to compress data (if the database must be created. Default = false) </param>
		/// <returns> Database associated with path </returns>
		public static LocalDB Local(string path = "documents", bool compress = false) {
			if (dbs.ContainsKey(path)) { return dbs[path]; }
			LocalDB db = new LocalDB(path, compress);
			dbs[path] = db;
			return db;
		}
		/*
		//public static Action<Exception> onError;
		//private static ConcurrentQueue<Action> pendingCommits;
		
		public static async void CommitTask() {
			while (true) {
				try {

					
				} catch (Exception e) {
					onError?.Invoke(e);
				}
				await Task.Delay(15);
			}
		}
		//*/

		/// <summary> Remove all references to a given database. </summary>
		public static void Drop(string path) {
			LocalDB db = Local(path);
			db.Close(false);

			if (Directory.Exists(db.dbPath)) {
				Directory.Delete(db.dbPath, true);
			}
		}

	}
	
	

	/// <summary> Class representing a local, In-Memory database. Good for raw data that has a well-defined structure. </summary>
	public class LocalDB {

		/// <summary> For ease of use </summary>
		private static readonly Encoding UTF8 = Encoding.UTF8;

		/// <summary> Directory the program is running from. Shorthand for Directory.GetCurrentDirectory() </summary>
		public static string CurrentDirectory { get { return Directory.GetCurrentDirectory(); } }

		/// <summary> Relative path for this database. </summary>
		public string directory { get; private set; }

		/// <summary> Absolute path for this database. </summary>
		public string dbPath { get { return CurrentDirectory + "/db/" + directory; } }

		/// <summary> Is data on disk compressed? </summary>
		public bool compress { get; private set; }
		/// <summary> Are JsonObject's PrettyPrint'd? </summary>
		public bool pretty { get; set; }

		/// <summary> 
		/// Distinct from JsonObject... 
		/// Collection of open files, and their live data. 
		/// Values are either JsonObject or JsonArray only. 
		/// </summary>
		//private Dictionary<string, JsonValue> documents;
		private ConcurrentDictionary<string, JsonValue> documents;

		/// <summary> Last timestamp when files were loaded/saved. </summary>
		private ConcurrentDictionary<string, DateTime> times;

		/// <summary> Indexer into this LocalDB object </summary>
		/// <param name="key"> Key, or path of target object </param>
		/// <returns> Copy of the requested object </returns>
		/// <remarks> 
		///		Uses the ConcurrentDictionary backing this database, and performs a get/set by copy. 
		///		Meaning, upon set, the object in the database is a copy of the object that was used for the set.
		///		And upon get, the resulting return value is a copy of the object in the database.
		///		Nothing in the database is directly worked on using this accessor.
		/// </remarks>
		/// <usage>
		///		LocalDB db = DB.Local("somePath");
		///		// ... Somewhere...
		///		// Open the document before we use it.
		///		db.Open("someKey");
		///		// ... other stuff
		///		// Only gets a copy of 'someKey'
		///		var x = db["someKey"];
		///		// ... do stuff with x, fill it with data, etc
		///		// Since we changed a copy, we have to tell it to update that value.
		///		db["someKey"] = x;
		/// </usage>
		public JsonValue this[string key] {
			get {
				JsonValue doc = null;
				documents.TryGetValue(key, out doc);
				if (doc == null) { return null; }
				return doc.DeepCopy();
			}
			set {
				if (value.JsonType != JsonType.Object && value.JsonType != JsonType.Array) {
					throw new NotSupportedException("LocalDB.this[string]: Only JsonObject and JsonArray may be stored as documents in this database!");
				}
				JsonValue copy = value.DeepCopy();
				if (documents.ContainsKey(key)) {
					documents[key] = copy;
				}
			}
		}
		
		/* Old version of the this[] accessor...
		public JsonValue this[string key] {
			get {
				JsonValue doc = null;
				lock (documents) {
					if (documents.ContainsKey(key)) {
						doc = documents[key];
					}
				}
				if (doc == null) { return null; }
				return doc.DeepCopy();
			}
			set {
				if (value.JsonType != JsonType.Object && value.JsonType != JsonType.Array) {
					throw new NotSupportedException("LocalDB.this[string]: Only JsonObject and JsonArray may be stored as documents in this database!");
				}
				JsonValue val = value.DeepCopy();
				lock (documents) {
					if (documents.ContainsKey(key)) {
						documents[key] = val;
					}
				}
			}
		}//*/

		/// <summary> Convert a file or folder path to only contain forward slashes '/' instead of backslashes '\'. </summary>
		/// <param name="path"> Path to convert </param>
		/// <returns> <paramref name="path"/> with all '\' characters replaced with '/' </returns>
		public static string ForwardSlashPath(string path) {
			string s = path.Replace('\\', '/');
			return s;
		}
		
		/// <summary> Convert a file path to a folder path. Assumed that path is a forward slash path. </summary>
		/// <param name="path"> Path to file </param>
		/// <returns> Path to a folder </returns>
		public static string PathOfFolder(string path) {
			return path.Substring(0, path.LastIndexOf('/'));
		}

		/// <summary> Takes a relative path and prepends the database path to it </summary>
		/// <param name="relativePath"> Relative path to a document </param>
		/// <returns> Absolute path to a document file </returns>
		public string FullPath(string relativePath) { return dbPath + relativePath; }
		
		/// <summary> Constructor </summary>
		/// <param name="localPath"> Relative path of the database, from the program directory. </param>
		/// <param name="compress"> Is the data in this database GZip compressed? Keep this consistant- don't change it on the next startup after a database actually has data in it. </param>
		public LocalDB(string localPath = "documents", bool compress = false, bool pretty = true) {
			this.compress = compress;
			this.pretty = pretty;
			directory = localPath.Replace('\\', '/') + '/';
			if (!Directory.Exists(dbPath)) { Directory.CreateDirectory(dbPath); }
			documents = new ConcurrentDictionary<string, JsonValue>();
			times = new ConcurrentDictionary<string, DateTime>();
		}

		/// <summary> Saves all open documents to disk. </summary>
		public void Save() {
			foreach (var pair in documents) { Save(pair.Key); }
		}

		/// <summary> Saves a specific document to disk. </summary>
		/// <param name="path"> Relative path of document to save. </param>
		public void Save(string path) {
			JsonValue doc = this[path];

			SaveInternal(path, doc);
		}

		/// <summary> Sets the value of a specific document, then saves it to disk. </summary>
		/// <param name="path"> Relative path of document to overwrite/save. </param>
		/// <param name="doc"> Data to save at the given <paramref name="path"/> </param>
		public void Save(string path, JsonValue doc) {
			this[path] = doc;

			SaveInternal(path, doc);
		}

		/// <summary> Common logic for saving a document </summary>
		/// <param name="path"> Path to save at </param>
		/// <param name="doc"> Document to save </param>
		private void SaveInternal(string path, JsonValue doc) {
			if (doc != null) {
				string filePath = FullPath(path);
				string json = pretty ? doc.PrettyPrint() : doc.ToString();
				byte[] data = compress ? GZip.Compress(json) : UTF8.GetBytes(json);
				File.WriteAllBytes(filePath, data);
				times[path] = DateTime.UtcNow;
			}
		}

		/// <summary> See if a given document is currently open </summary>
		/// <param name="path"> Path of document to check for </param>
		/// <returns> True if the document is open, false otherwise. </returns>
		public bool IsOpen(string path) { return documents.ContainsKey(path); }

		/// <summary> Check for a given document existing, and get it if it does  </summary>
		/// <param name="path"> Path to check for document at </param>
		/// <param name="existed"> out parameter. True after the method ends if the object existed, false if it did not. </param>
		/// <returns> A copy of the given object if it did exist, or JsonNull.instance if it did not. </returns>
		public JsonValue Check(string path, out bool existed) {
			existed = Exists(path);
			if (existed) { return Open(path); }
			return JsonNull.instance;
		}

		/// <summary> Check for a given document existing, and get it if it does  </summary>
		/// <param name="path"> Path to check for document at </param>
		/// <param name="record"> out parameter. Set to the record after the method ends if the record existed, and JsonNull.instance if it did not. </param>
		/// <returns> True if it did exist, or false if it did not. </returns>
		public bool Check(string path, out JsonValue record) {
			if (Exists(path)) { 
				record = Open(path); 
				return true; 
			}
			record = JsonNull.instance;
			return false;
		}

		/// <summary> Chec k for a given document existing, as a JsonObject, and get it if it does </summary>
		/// <param name="path"> Path to check for document at </param>
		/// <param name="record"> Out parameter. Set to the record after the method ends if the record existed and was a JsonObject, and null otherwise. </param>
		/// <returns> True, if the object existed, false otherwise. </returns>
		public bool Check(string path, out JsonObject record) {
			if (Exists(path)) {
				record = Open(path) as JsonObject;
				return true;
			}
			record = null;
			return false;
		}

		/// <summary> Chec k for a given document existing, as a JsonArray, and get it if it does </summary>
		/// <param name="path"> Path to check for document at </param>
		/// <param name="record"> Out parameter. Set to the record after the method ends if the record existed and was a JsonArray, and null otherwise. </param>
		/// <returns> True, if the array existed, false otherwise.</returns>
		public bool Check(string path, out JsonArray record) {
			if (Exists(path)) {
				record = Open(path) as JsonArray;
				return true;
			}
			record = null;
			return false;
		}

		/// <summary> Intended to use to access documents in a read only manner.
		/// Returns the reference to the document that is open for the given name
		/// Anything that uses this should adhere to the contract.
		/// Hence the __ to mark the function as spooky. </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public JsonValue __readonly(string path) {	
			if (!IsOpen(path)) { JustOpen(path); }
			return documents[path];
		}

		/// <summary> Just makes sure a document is open, to not incurr the cost of duplication of data. </summary>
		/// <param name="path"> Relative path of document to open from the root of this LocalDB instance </param>
		/// <param name="type"> Type of document to create, if not found. Must be either JsonType.Object or JsonType.Array. Default is Object. </param>
		/// <returns> True if the object existed before it was opened, false if a new document was created. </returns>
		public bool JustOpen(string path, JsonType type = JsonType.Object) {
			var existed = Exists(path);
			if (!documents.ContainsKey(path)) {
				if (type != JsonType.Object && type != JsonType.Array) {
					throw new NotSupportedException("LocalDB.Open: Type must be Object or Array - no other JsonType can be made into a single document.");
				}

				string filePath = FullPath(path);
				string fileFolder = PathOfFolder(filePath);
				if (!Directory.Exists(fileFolder)) { Directory.CreateDirectory(fileFolder); }

				if (File.Exists(filePath)) {
					times[path] = DateTime.UtcNow;
					byte[] data = File.ReadAllBytes(filePath);
					string json = compress ? GZip.DecompressString(data) : UTF8.GetString(data);
					var doc = Json.Parse(json);
					if (doc.isArray || doc.isObject) {
						documents[path] = doc;
						//lock (documents) { documents[path] = doc; }

					}

				} else {
					times[path] = DateTime.UtcNow;
					JsonValue doc; // This is a stupid hack, but it works. Assigning to a variable to cast it to the correct type!
					doc = (type == JsonType.Object) ? (doc = new JsonObject()) : (doc = new JsonArray());
					documents[path] = doc;

					//lock (documents) { documents[path] = doc; }
				}

			}
			return existed;
		}

		/// <summary> Open a document based on a given <paramref name="path"/> </summary>
		/// <param name="path"> Relative path of document to open from the root of this LocalDB instance </param>
		/// <param name="existed"> out parameter. True after the method ends if the object existed before it was opened. </param>
		/// <returns> Copy of opened document, same as this[<paramref name="path"/> </returns>
		public JsonValue Open(string path, out bool existed, JsonType type = JsonType.Object) {
			existed = Exists(path);
			return Open(path, type);
		}


		/// <summary> Open a document based on a given path </summary>
		/// <param name="path"> Relative path of document to open from the root of this LocalDB instance </param>
		/// <param name="type"> Type of document to create, if not found. Must be either JsonType.Object or JsonType.Array. Default is Object. </param>
		/// <returns> Copy of opened document, ready for work </returns>
		public JsonValue Open(string path, JsonType type = JsonType.Object) {
			JustOpen(path, type);
			return this[path];
		}

		/// <summary> Forcefully reload/reopen a document based on a given path. Discards any changes that are currently on the document if used. </summary>
		/// <param name="path"> Relative path of document to open from the root of this LocalDB instance </param>
		/// <param name="type"> Type of document to open, if not found. Must be either JsonType.Object or JsonType.Array. Default is Object. </param>
		/// <returns> Copy of the opened document, ready for work. </returns>
		public JsonValue ReOpen(string path, JsonType type = JsonType.Object) {
			Close(path, false);
			return Open(path, type);
		}

		/// <summary> Opens a document, and reloads it if it has been changed since the last access. </summary>
		/// <param name="path"> Relative path of document to open from the root of this LocalDB instance </param>
		/// <param name="type"> Type of document to open, if not found. Must either be JsonType.Object or JsonType.Array. Default is Object.  </param>
		/// <returns> Copy of the opened document, ready for work. </returns>
		public JsonValue HotOpen(string path, JsonType type = JsonType.Object) {
			if (times.ContainsKey(path)) {
				string filePath = FullPath(path);
				DateTime time = File.GetLastWriteTimeUtc(filePath);
				if (time > times[path]) {
					return ReOpen(path);
				}
			}
			return Open(path);
		}

		/// <summary> Sets the document at path to be equal to the given value. Document must be open for this operation to be successful. </summary>
		/// <param name="path"> Relative path of document to set </param>
		/// <param name="value"> Value to set as the document's content </param>
		/// <param name="forceSave"> Should there be a save performed after the operation? </param>
		/// <returns> True if set was successful, false if it failed. </returns>
		public bool Set(string path, JsonValue value, bool forceSave = false) {
			if (!value.isArray && !value.isObject) {
				throw new NotSupportedException("LocalDB.Set: Type of passed JsonValue must be Object or Array - no other JsonType can be made into a single document");
			}

			if (documents.ContainsKey(path)) {
				//lock (documents) { documents[path] = value; }
				documents[path] = value;
				if (forceSave) { Save(path); }
				return true;
			}
			return false;
		}

		/*
		 * This shit can be done later
		 * 
		/// <summary> Get a copy of a part or whole of a given document from the database. </summary>
		/// <param name="path"> Relative Path to the document </param>
		/// <param name="subIndexes"> Sub-paths inside of that object to navigate, in order. </param>
		/// <returns> A copy of the object pointed to by path and subindexes. </returns>
		public JsonValue Get(string path, params JsonValue[] subIndexes) {
			JsonValue val;
			// Has to lock for thread safety, since we're traversing the actual object inside the DB
			lock (documents) {
				JsonValue ptr;
				ptr = documents[path];
				for (int i = 0; i < subIndexes.Length; i++) {
					if (ptr.isObject || ptr.isArray) {
						ptr = ptr[subIndexes[i]];
					} else { ptr = JsonNull.instance; break; }
				}
				val = ptr.DeepCopy();
			}
			return val;
		}

		/// <summary> Sets a </summary>
		/// <param name="path"></param>
		/// <param name="val"></param>
		/// <param name="subIndexes"></param>
		public void Set(string path, JsonValue val, params JsonValue[] subIndexes) {

		}
		//*/




		/// <summary> Immediately Save and close ALL open documents. </summary>
		public void Close(bool save = true) {

			foreach (var pair in documents) {

				Close(pair.Key, save);

			}

		}

		/// <summary> Close a given document. </summary>
		/// <param name="path"> relative path of document to close </param>
		/// <param name="save"> True to save, false to not save. </param>
		public void Close(string path, bool save = true) {
			JsonValue __;
			DateTime ___;
			if (documents.ContainsKey(path)) {
				if (save) { Save(path); }
				while (!documents.TryRemove(path, out __)) { }
			}
			if (times.ContainsKey(path)) {
				while (!times.TryRemove(path, out ___)) { }
			}
		}

		/// <summary> Check if a document exists at a given path. Returns true if a file exists at the path, or if that file is currently open. </summary>
		/// <param name="path"> Path to check </param>
		/// <returns> True if a document exists at that path, false otherwise. </returns>
		public bool Exists(string path) {
			if (documents.ContainsKey(path)) { return true; }
			string fullPath = FullPath(path);
			return File.Exists(fullPath);
		}


	}

}
