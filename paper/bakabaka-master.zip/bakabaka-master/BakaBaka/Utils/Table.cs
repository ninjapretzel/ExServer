using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace BakaBaka {

	public static class Table<T> where T : class {
	
		public static readonly IDictionary<string, T> data = new ConcurrentDictionary<string, T>();

		public static T Get(string key) {
			if (data.ContainsKey(key)) { return data[key]; }
			return null;
		}

		public static bool Put(string key, T value) {
			if (data.ContainsKey(key)) { return false; }
			data[key] = value;
			return true;
		}

		public static bool Has(string key) {
			return data.ContainsKey(key);
		}
	
	}
	
	public static class Join<T1, T2> where T1 : class where T2 : class {
	
		private static readonly IDictionary<string, ConcurrentSet<string>> map = new ConcurrentDictionary<string, ConcurrentSet<string>>();
		
		public static bool Has(string key1, string key2) {
			return map.ContainsKey(key1) && map[key1].Contains(key2);
		}

		public static bool Map(string key1, string key2) {
			if (Table<T1>.Has(key1) && Table<T2>.Has(key2)) {
				if (Has(key1, key2) && Join<T2, T1>.Has(key2, key1)) {
					return true;
				}

				if (!map.ContainsKey(key1)) { map[key1] = new ConcurrentSet<string>(); }
				if (!Join<T2,T1>.map.ContainsKey(key2)) {
					Join<T2,T1>.map[key2] = new ConcurrentSet<string>();
				}

				map[key1].Add(key2);
				Join<T2, T1>.map[key2].Add(key1);

				return true;
			}
			return false;
		}

		public static bool Unmap(string key1, string key2) {
			if (Has(key1, key2) && Join<T2,T1>.Has(key2, key1)) {
				map[key1].Remove(key2);
				Join<T2,T1>.map[key2].Remove(key1);

				return true;
			}

			return false; 
		}
		
	}

}
