using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using BakaBaka;
using System.IO;
using LevelUpper.Extensions;
using System.Text;
using BakaBaka.Utils;
using System.Diagnostics;
#if UNITY_EDITOR
using UnityEditor;

namespace BakaBaka {
	public static class GibsBuild {



	}
}


#endif

namespace BakaBaka {
	
	public static class Loader {

		static ConcurrentDictionary<string, Encoding> textEncodings;
		static ConcurrentDictionary<string, Action<string>> textCallbacks;
		static ConcurrentDictionary<string, Action<byte[]>> rawCallbacks;
		static ConcurrentDictionary<string, DateTime> lastLoads;

		public static Task ongoing { get; private set; }

		public static string path {
			get {
				#if UNITY_EDITOR
					// Current Directory is the project root, so we just get that directory and add the external assets directory to it.
					return Directory.GetCurrentDirectory().ForwardSlashPath() + "/ExtAssets/";
					//return Directory.GetCurrentDirectory().ForwardSlashPath() + "/Assets/Data/System";
				#else
					// Get '_Data' directory from same folder as executable.
					// TBD: Maybe move it to "x_Data/ExtAssets"?
					string[] dirs = Directory.GetDirectories(Directory.GetCurrentDirectory(), "*_Data");
					return dirs[0] + "/System";	
				#endif
			}
		}

		
		/// <summary> Begins services for <see cref="Loader.Load"/>s </summary>
		public static void Start() {
			if (textCallbacks == null) { textCallbacks = new ConcurrentDictionary<string, Action<string>>(); }
			textEncodings = new ConcurrentDictionary<string, Encoding>();
			textCallbacks = new ConcurrentDictionary<string, Action<string>>();
			rawCallbacks = new ConcurrentDictionary<string, Action<byte[]>>();
			lastLoads = new ConcurrentDictionary<string, DateTime>();
			
			ongoing = Task.Run(async ()=>{ 
				Daemon.Print("\\eHotloading Enabled");

				while (Daemon.UnityRunning) {
					
					if (Daemon.UnityPaused) {
						await Task.Delay(100);
						continue;
					}

					try {

						DateTime tickNow = DateTime.UtcNow;
						foreach (var pair in lastLoads) {
							if (!Daemon.UnityRunning) { goto done; }
							var file = pair.Key;

							
							DateTime lastLoad = pair.Value;
							DateTime lastChange = File.GetLastWriteTimeUtc(file);
							if (lastLoad < lastChange) {
								lastLoads[file] = tickNow;
								var filePath = path + file;

								if (textCallbacks.ContainsKey(file)) {
									Action<string> textCallback = textCallbacks[file];
									
									LoadAsync(filePath, textCallback).Forget();

								} else if (rawCallbacks.ContainsKey(file)) {
									Action<byte[]> rawCallback = rawCallbacks[file];
									
									LoadAsync(filePath, rawCallback).Forget();

								}
							
							}



						}
					} catch (Exception e) {
						Daemon.LogWarning("\\rException during ongoing hotloading task: " + e.GetType(), e);
					}


					await Task.Delay(100);
				}

				done:;
			});

		}

		
		public static void HotLoad(string path, Action<string> callback, Encoding enc = null) {
			if (enc == null) { enc = Encoding.UTF8; }

			lastLoads[path] = DateTime.MinValue;
			textCallbacks[path] = callback;
			textEncodings[path] = enc;
		}
		

		// Allocate space for one 4k sector by default
		// since text is typically pretty small, and most text files should be quick to read 
		/// <summary> Default buffer size for Text load jobs </summary>
		const int TEXT_SIZE = 4096;
		// Allocate space for 1MB of data by default (256 4k sectors)
		// since data files can be fairly large, textures and sounds especially.
		/// <summary> Default buffer size for Data load jobs </summary>
		const int DATA_SIZE = 4096 * 256; // 1 MB = 256 4k sectors



		/// <summary> Actually does the loading and proecessing of a text file </summary>
		/// <param name="path"> Full path to text file. </param>
		/// <param name="callback"> Callback to run on loaded text which returns the loaded object</param>
		/// <returns> Async Task handling the load job. </returns>
		public static async Task<object> LoadAsync(string path, Func<string, object> callback, Encoding enc = null, int bufferSize = TEXT_SIZE) {
			string text = await ReadTextAsync(path, enc, bufferSize);
			if (text != null && callback != null) {
				return callback(text);
			}
			return null;
		}

		/// <summary> Actually does the loading and proecessing of a text file </summary>
		/// <param name="path"> Full path to text file. </param>
		/// <param name="callback"> Callback to run on loaded text </param>
		/// <returns> Async Task handling the load job. </returns>
		public static async Task LoadAsync(string path, Action<string> callback, Encoding enc = null, int bufferSize = TEXT_SIZE) {
			string text = await ReadTextAsync(path, enc, bufferSize);
			//Daemon.Print("hotloaded text:\n" + (text != null ? text : "null"));
			if (text != null && callback != null) {
				callback(text);
			}
		}

		/// <summary> Actually does the loading and proecessing of a text file </summary>
		/// <param name="path"> Full path to text file. </param>
		/// <param name="callback"> Callback to run on loaded text which returns the loaded object</param>
		/// <returns> Async Task handling the load job. </returns>
		public static async Task<object> LoadAsync(string path, Func<byte[], object> callback, int bufferSize = TEXT_SIZE) {
			byte[] data = await ReadBytesAsync(path, bufferSize);
			if (data != null && callback != null) {
				return callback(data);
			}
			return null;
		}

		/// <summary> Actually does the loading and proecessing of a data file </summary>
		/// <param name="path"> Full path to data file. </param>
		/// <param name="callback"> Callback to run on loaded data </param>
		/// <returns> Async Task handling the load job. </returns>
		public static async Task LoadAsync(string path, Action<byte[]> callback, int bufferSize = DATA_SIZE) {
			byte[] data = await ReadBytesAsync(path, bufferSize);
			if (data != null && callback != null) {
				callback(data);
			}
		}


		/// <summary> Load a text file completely into memory. </summary>
		/// <param name="filePath"> Path of file to read </param>
		/// <param name="enc"> Encoding to use to read the file. Default is UTF8. </param>
		/// <param name="bufferSize"> Size of initial buffer. Default is <see cref="TEXT_SIZE"/>. </param>
		/// <returns> string loaded from file </returns>
		private static async Task<string> ReadTextAsync(string filePath, Encoding enc = null, int bufferSize = TEXT_SIZE) {
			using (FileStream sourceStream = new FileStream(filePath,
				FileMode.Open, FileAccess.Read, FileShare.Read,
				bufferSize: bufferSize, useAsync: true)) {
				if (enc == null) { enc = Encoding.UTF8; }

				StringBuilder sb = new StringBuilder();
				byte[] buffer = new byte[bufferSize];
				int numRead;
				if (!Daemon.UnityRunning) { return null; }

				while ((numRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length)) != 0) {
					if (!Daemon.UnityRunning) { return null; }
					string text = enc.GetString(buffer, 0, numRead);
					sb += text;
				}
				
				return sb.ToString();
			}
		}

		/// <summary> Load a data file completely into memory. </summary>
		/// <param name="filePath"> Path of file to read </param>
		/// <param name="bufferSize"> Size of initial buffer. Default is <see cref="DATA_SIZE"/>. </param>
		/// <returns> Byte[] loaded from file </returns>
		private static async Task<byte[]> ReadBytesAsync(string filePath, int bufferSize = DATA_SIZE) {
			using (FileStream sourceStream = new FileStream(filePath,
				FileMode.Open, FileAccess.Read, FileShare.Read,
				bufferSize: bufferSize, useAsync: true)) {
				
				using (MemoryStream ms = new MemoryStream(bufferSize)) {
					byte[] buffer = new byte[bufferSize];
					int numRead;
					if (!Daemon.UnityRunning) { return null; }

					while ((numRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length)) != 0) {
						if (!Daemon.UnityRunning) { return null; }

						//string text = Encoding.Unicode.GetString(buffer, 0, numRead);

						await ms.WriteAsync(buffer, 0, numRead);
					}

					return ms.ToArray();
				}
			}


		}

	}


	// @Experement
	// Basically, experement loading PNG->Texture2D via tasks.
	// Probably not worth continuing
	// Kept in comment for posterity and reference.
	/*
	// @Unfinished
	/// <summary> Stupid base class only exists to let us cast the generics in the direved class away and back as needed. </summary>
	public class Asset { }
	// @Unfinished
	/// <summary> Represents an asset request for an external asset. </summary>
	/// <typeparam name="T"> </typeparam>
	public class Asset<T> : Asset where T : UnityEngine.Object {
		
		/// <summary> Last value successfuly loaded. </summary>
		public T value { get; private set; }
		/// <summary> Name of the loaded asset. </summary>
		public string name { get; private set; }

		/// <summary> Async function generator to use to load this type of asset. </summary>
		Func<Task<T>> loader { get; set; }
		/// <summary> Hook function of what to do with the asset after it has been loaded. </summary>
		public Action<T> onLoad { get; set; }

		/// <summary> Is the asset ready to be used? </summary>
		public bool ready { get; private set; }

		public string filePath { get; set; }
		public DateTime lastUpdate { get; private set; }

		public Task loadTask;
		public bool isReloading { get { return loadTask.IsAlive(); } }
		public bool lastSuccess { get; private set; }


		public Asset(string name, Func<Task<T>> loader) {
			this.name = name;
			this.loader = loader; 
			value = null;
			ready = false;

			Reload();
		}

		public void Reload() {
			ready = false;
			loadTask = Task.Run(async () => {
				T result = await loader();
				if (result != null) {
					Daemon.Print("Finished loading asset \\e" + name);
					value = result;
					ready = true;
					lastUpdate = DateTime.UtcNow;
					lastSuccess = true;
				} else {
					Daemon.Print("\\rAsset \\e" + name + "\\r failed to load!");
					ready = false;
					lastUpdate = DateTime.UtcNow;
					lastSuccess = false;
				}

			});

		}

		


		/// <inheritdoc />
		/// <remarks> Overidden to allow easy and fast comparison of assets. </remarks>
		public override bool Equals(object obj) {
			if (obj is Asset<T>) {
				Asset<T> other = obj as Asset<T>;
				if (other != null && other.name == name && ReferenceEquals(value, other.value)) {
					return true;
				}
			}

			return false;
		}

		/// <inheritdoc />
		/// <remarks> Overidden to use the name and typeof T as hash codes. </remarks>
		public override int GetHashCode() {
			return name.GetHashCode();
		}

	}
	
	public static class AssetLoader {

		//public static Asset<T> HotLoad

		// @Unfinished
		public static Asset<T> Load<T>(string name) where T : UnityEngine.Object {
			Asset at = null;

			if (typeof(T) == typeof(Texture2D)) {
				string sourcePath = path + name;
				// @TBD: Get dump compressed data at this path.
				// string compressedPath = path + name + ".crt";

				if (!File.Exists(sourcePath)) {
					if (File.Exists(path + name + ".png")) {
						sourcePath = path + name + ".png";
					} else if (File.Exists(path + name + ".jpg")) {
						sourcePath = path + name + ".jpg";
					}
				}


				// Gotta be lambda to bind to filepath...
				Asset<Texture2D> asset = new Asset<Texture2D>(name, () => {
					return Task.Run(async () => {

						//Daemon.Print("Created Texture2D Asset Loader for " + filepath);
						byte[] data = await ReadBytesAsync(sourcePath);
						//Daemon.Print("Read Texture2D bytes successfully");
						Texture2D tex = null;
						int wid = -1;

						// Testing reading PNGS:
						// Maybe? TBD: use the data that comes back from the following function to actually load the PNG
						//byte[] rawData = PNGtoRAW(data);
						//byte[] rawData = null;

						Daemon.RunOnMainThread(() => {
							//Daemon.Print("Creating texture on main thread");
							Stopwatch timer = new Stopwatch();
							timer.Start();
							tex = new Texture2D(512, 512);
							var t2dConstructor = timer.Elapsed;

							tex.LoadImage(data);
							tex.Compress(false);
							// @TBD: Dump this data into compressed data,
							//		And skip loading the compressed data if it exists and is newer than the source file.
							//rawData = tex.GetRawTextureData();
							wid = tex.width;
							timer.Stop();

							var t2dLoad = timer.Elapsed;
							Daemon.Print("Constructor Time: " + t2dConstructor + "\n Total: " + t2dLoad + " for " + tex.width + "x" + tex.height);
							//Daemon.Print("Loaded texture on main thread");
						});

						while (tex == null && wid == -1) {
							//Daemon.Print("\\eAwaiting texture load");
							await Task.Delay(25);
						}



						return tex;
					});
				});


				at = asset;
			}



			return at as Asset<T>;
		}

		// @Unfinished
		public struct PNGData {
			public int width;
			public int height;
			public byte bitDepth;
			public byte colorType;
			public byte compression;
			public byte filter;
			public byte interlaced;

			public override string ToString() {
				StringBuilder str = "PNGDATA:";
				str = str + "\n" + width + " x " + height;
				str = str + "\nBit Depth " + bitDepth;
				str = str + "\nColorType " + colorType;
				str = str + "\nCompression " + compression;
				str = str + "\nFilter " + filter;
				str = str + "\nInterlacing " + interlaced;

				return str;
			}
		}

		// @Unfinished
		public static PNGData? PNGInfo(byte[] pngdata) {
			PNGData? data = null;
			using (BinaryReader reader = new BinaryReader(new MemoryStream(pngdata))) {
				// just check header
				ulong header = reader.ReadUInt64();
				if (header != pngHeader) { return null; }

				int len = reader.Int32(Endianness.Big);
				// Make sure the first chunk is the IHDR
				string type = new string(reader.ReadChars(4));
				if (type != "IHDR") { return null; }
				byte[] block = reader.ReadBytes(len);
				data = Unsafe.Reinterpret<PNGData>(block);

				// = reader.Int32(Endianness.Big);

			}
			return data;
		}

		/// <summary> 8-byte header of a PNG (in Big-Endian form) </summary>
		const ulong pngHeader = (0x89504E470D0A1A0AL);
		// @Unfinished
		public static byte[] PNGtoRAW(byte[] pngdata) {
			Daemon.Print("Loading " + pngdata.Length + " bytes of png data");
			int pos = 0;

			byte[] data = null;
			//byte[] buffer = new byte[65524]; // Most PNG chunks shouldn't be this big, right?

			using (MemoryStream stream = new MemoryStream()) {
				using (MemoryStream fstream = new MemoryStream(pngdata)) {
					BinaryReader reader = new BinaryReader(fstream, Encoding.ASCII);
					Daemon.Print("Little Endian: " + BitConverter.IsLittleEndian);

					ulong header = reader.UInt64(Endianness.Big);
					Daemon.Print("Header: " + header.Hex() + " Good: " + (header == pngHeader));


					while (fstream.Position < fstream.Length) {
						int len = reader.Int32(Endianness.Big);

						string type = new string(reader.ReadChars(4));
						uint crc = reader.ReadUInt32();
						reader.ReadBytes(len);


						Daemon.Print("PNG Block " + pos + ": " + type + " " + len + " #" + crc.Hex());

						pos++;
					}






				}
				data = stream.ToArray();
			}





			return data;
		}

	}

	//*/

}
