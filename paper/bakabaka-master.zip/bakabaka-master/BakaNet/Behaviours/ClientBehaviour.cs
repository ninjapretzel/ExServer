using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet.Modules;

namespace BakaNet {

	public class ClientBehaviour : MonoBehaviour {
	
		public bool loggedIn { get { return GetModule<LoginModule>()?.LoggedIn ?? false; } }

		public T GetModule<T>() where T : Module { return NetworkDaemon.main?.GetModule<T>(); }

	}
}
