using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
namespace BakaBaka.Utils {

	/// <summary> Holds some functions to print out the hex representations of primitives. </summary>
	public static class HexUtils {
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this byte v) { return String.Format("0x{0:X2}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this short v) { return String.Format("0x{0:X4}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this int v) { return String.Format("0x{0:X8}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this long v) { return String.Format("0x{0:X16}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this float v) { return String.Format("0x{0:X8}", Unsafe.Reinterpret<float, int>(v)); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this double v) { return String.Format("0x{0:X16}", Unsafe.Reinterpret<double, long>(v)); }

		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this sbyte v) { return String.Format("0x{0:X2}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this ushort v) { return String.Format("0x{0:X4}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this uint v) { return String.Format("0x{0:X8}", v); }
		/// <summary> Converts number to internal hex representation </summary>
		/// <param name="v"> Value to convert </param>
		/// <returns> 0x formatted hex string representing given number </returns>
		public static string Hex(this ulong v) { return String.Format("0x{0:X16}", v); }





	}
}
