using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace BakaBaka.Utils {
	public static class ExceptionUtils {

		/// <summary> Constructs a string with information about an exception, and all of its inner exceptions. </summary>
		/// <param name="e"> Exception to print. </param>
		/// <returns> String containing info about an exception, and all of its inner exceptions. </returns>
		public static string InfoString(this Exception e) {
			StringBuilder str = "\nException Info: " + e.MiniInfoString();
			str += "\n\tMessage: " + e.Message;
			Exception ex = e.InnerException;

			while (ex != null) {
				str = str + "\n\tInner Exception: " + ex.MiniInfoString();
				ex = ex.InnerException;
			}


			return str;
		}

		/// <summary> Constructs a string with information about an exception. </summary>
		/// <param name="e"> Exception to print </param>
		/// <returns> String containing exception type, message, and stack trace. </returns>
		public static string MiniInfoString(this Exception e) {
			StringBuilder str = e.GetType().ToString();
			str = str + "\n\tMessage: " + e.Message;
			str = str + "\nStack Trace: " + e.StackTrace;
			return str;
		}

	}
}
