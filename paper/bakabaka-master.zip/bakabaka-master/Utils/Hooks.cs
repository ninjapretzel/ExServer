using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

/// <summary> Generic interface for hooks that read a specific data source </summary>
/// <typeparam name="T"> Generic Source </typeparam>
public interface IHook<T> {
	/// <summary> Reads the data source, and reacts to it in whatever way is necessary </summary>
	/// <param name="source"> Data object to read, of whatever type. </param>
	void Read(T source);
}

/// <summary> Represents a single hook into some syncdata field on some entity <summary>
/// <typeparam name="T"> Generic type </typeparam>
public class JsonHook<T> : IHook<JsonObject> {
	/// <summary> Name of field from syncdata record </summary>
	public string fieldName { get; private set; }
	/// <summary> Default value, if it does not exist. </summary>
	public T defaultValue { get; private set; }
	/// <summary> Callback when the value is updated </summary>
	public Action<T> update { get; private set; }

	/// <summary> Last Value read from client </summary>
	public T lastValue;
	bool readOne = false;

	public JsonHook(string fieldName, T defaultValue, Action<T> update) {
		this.fieldName = fieldName;
		this.defaultValue = defaultValue;
		this.update = update;
		readOne = false;
		lastValue = defaultValue;
	}

	public void Read(JsonObject source) {
		T read = source.Pull(fieldName, defaultValue);
		
		if (!readOne || !lastValue.Equals(read)) {
			readOne = true;
			update(read);
		}
		lastValue = read;
	}
}
