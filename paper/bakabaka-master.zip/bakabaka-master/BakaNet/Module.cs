using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using BakaNet.Utils;
using BakaBaka;
using LevelUpper.Extensions;

namespace BakaNet { 

	/// <summary> Base class to hold module logic, and make it easier to interface with. </summary>
	public class Module {

		public delegate void RPCMethod(RPCMessage m);

		/// <summary> Cache of methods for quicker calls </summary>
		private static Dictionary<Type, Dictionary<string, MethodInfo>> methodCache = new Dictionary<Type, Dictionary<string, MethodInfo>>();
		
		/// <summary> Quick easy access to the type of the object. </summary>
		public Type type { get { return GetType(); } }

		/// <summary> Tracked reference to the server object. Only exists when the machine is hosting. </summary>
		public Server server = null;
		/// <summary> Tracked reference to the local client object. </summary>
		public Client localClient = null;

		/// <summary> Internal value of the deltaTime of the current tick </summary>
		protected float delta;
		/// <summary> Internal value of when the current tick started </summary>
		protected DateTime tickStart;

		/// <summary> Is this module attached to a server? </summary>
		public bool IsServer { get { return server != null; } }

		/// <summary> Basic constructor </summary>
		public Module() { }
		
		/// <summary> Binding flags for Event methods. </summary>
		public const BindingFlags EVENT_BINDINGS = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

		/// <summary> Attempts to call a method on the type by name, via Reflection. </summary>
		/// <param name="eventName"> Name of method to call. </param>
		/// <param name="failSilently"> If the method doesn't exist should it be ignored (true) or reported as a warning (false)? </param>
		/// <param name="args"> Arguments into the method to call. </param>
		/// <returns> True, if a method invocation was attempted, even if it failed. False if no method was found to invoke. </returns>
		/// <remarks> Does not support overloaded methods. </remarks>
		public bool SendEvent(string eventName, params object[] args) {
			
			Dictionary<string, MethodInfo> methods = methodCache.ContainsKey(type) ?
				(methodCache[type]) :
				(methodCache[type] = new Dictionary<string, MethodInfo>());
			
			MethodInfo method = methods.ContainsKey(eventName) ?
				(methods[eventName]) :
				(methods[eventName] = type.GetMethod(eventName, EVENT_BINDINGS));


			if (method != null) {
				try {
					//Daemon.Log("Invoking " + method.DeclaringType.Name + "." + method.Name, LogLevel.Maximal);
					method.Invoke(this, args);
				} catch (TargetInvocationException e) {
					StringBuilder str = "\\rModule.SendEvent: Exception in Module ";
					str = str + method.DeclaringType + "." + method.Name;
					str = str + " Details:";

					Daemon.LogWarning(str, e);

				} catch (Exception e) {
					Daemon.LogWarning("\\rModule.SendEvent: " + method.DeclaringType + "." + method.Name + "  Something werid happened. Exception raised:", e);
				}
				return true;
			}
			return false;
			
		}

		/// <summary> Gets the first module of type <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic Module Type </typeparam>
		/// <returns> First Module of type <typeparamref name="T"/> attached to a Server or Client object related to this Module, or null if none are. </returns>
		public T GetModule<T>() where T : Module {
			List<Module> modules = IsServer ? server.modules : localClient.modules;
			if (modules == null) { return null; }
			return GetModule<T>(modules);
		}

		public static T GetModule<T>(List<Module> modules) where T: Module {
			foreach (var module in modules) {
				if (typeof(T).IsAssignableFrom(module.GetType())) {
					return (T)module;
				}
			}

			return null;
		}

		/// <summary> Calls "Update" if it exists. </summary>
		/// <remarks> Server Only. </remarks>
		public void TriggerUpdate(DateTime tickStart, float delta) { 
			this.tickStart = tickStart;
			this.delta = delta;
			Update();
			//SendEvent("Update");
			//SendEvent("Update", tickStart, delta); 
		}

		/// <summary> Calls "OnConnected" if it exists. </summary>
		/// <param name="c"> Client that just connected </param>
		public void TriggerOnConnected(Client c) {  OnConnected(c); }

		/// <summary> Calls "OnDisconnected" if it exists. </summary>
		/// <param name="c"> Client that just disconnected </param>
		public void TriggerOnDisconnected(Client c) { OnDisconnected(c); }

		/// <summary> Calls "OnServerAwake" if it exists </summary>
		/// <param name="s"> Server that just started </param>
		public void TriggerOnServerAwake(Server s) { server = s; OnServerAwake(s); }

		/// <summary> Calls "OnClientAwake" if it exists </summary>
		/// <param name="c"> Client that just started </param>
		public void TriggerOnClientAwake(Client c) { if (c.isLocal) { localClient = c; } OnClientAwake(c); }


		public virtual void Update() { }

		/// <summary> Called when a client is connected. </summary>
		/// <param name="c"> Client that just connected. </param>
		public virtual void OnConnected(Client c) { }

		/// <summary> Called when a client is disconnected. </summary>
		/// <param name="c"> Client that just disconnected. </param>
		public virtual void OnDisconnected(Client c) { }

		/// <summary> Called when the server starts up. </summary>
		/// <param name="s"> Server that just started up. </param>
		public virtual void OnServerAwake(Server s) { }

		/// <summary> Called when a new client object has been activated. </summary>
		/// <param name="s"> Client that just started up. </param>
		public virtual void OnClientAwake(Client c) { }


		/// <summary> Common way of calling an arbitrary RPC. </summary>
		/// <param name="name"> Name of RPC to call. </param>
		/// <param name="message"> RPCMessage object with RPC information. </param>
		public bool SendRPCEvent(RPCMessage message) {
			return SendEvent(message.methodName, message);
		}

		/// <summary> Sends <paramref name="stuff"/> to the server, only if this is a localClient Module. </summary>
		/// <param name="stuff"> Stuff to pass to the local client </param>
		public void SendToServer(params object[] stuff) { localClient?.Send(stuff); }

		public static readonly Color TOP_COLOR = new Color(.6f, .8f, 1f);
		public const int TOP_SIZE = 32;
		
		public bool open { get; private set; } = false;

		/// <summary> Entry point to have consistant UI panels for all modules. </summary>
		/// <param name="area">Area to draw into </param>
		public void OnGUI(Rect area) {
			Rect brush = area;
			brush.height = TOP_SIZE;

			GUI.color = TOP_COLOR;
			GUI.Box(brush, "Module " + GetType());
			if (GUI.Button(brush.Right(.2f), open ? "-" : "+")) { open = !open; }

			if (open) {
				Rect remaining = area;
				remaining.y += TOP_SIZE; remaining.height -= TOP_SIZE;
				GUI.color = Color.white.Alpha(.5f);
				GUI.Box(remaining, "");
				GUI.color = Color.white;


				DrawIMGUI(remaining);
			}
		}

		/// <summary> Function intended to be called as an IMGUI function call </summary>
		/// <param name="area"> Area to draw into </param>
		public virtual void DrawIMGUI(Rect area) { 
			GUI.Label(area, "No custom UI for " + GetType());
		}

	}

	
		


	/// <summary> Class to be copy/pasted for module creation </summary>
	public sealed class BaseModule : Module {

		private BaseModule() { }


		public override void OnServerAwake(Server s) {
			// Server-side initialization

		}

		public override void OnClientAwake(Client c) {

			if (c.isLocal) {
				// Local-Client initialization

			}
			// Common Client initialization

		}

		public override void OnConnected(Client c) {

			if (c.isLocal) {
				// Client-side connection handling

			} else {
				// Server-side connection handling 

			}

		}


		public override void Update() {

			// Always Server Only...

		}

		public override void OnDisconnected(Client c) {

			if (c.isLocal) {
				// Client side disconnection cleanup 

			} else {
				// Server side disconnection cleanup 

			}

		}


	}

}
