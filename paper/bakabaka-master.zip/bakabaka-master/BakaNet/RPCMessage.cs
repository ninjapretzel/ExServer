using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace BakaNet {
	/// <summary> Represents a single RPC request </summary>
	public class RPCMessage {
	
		/// <summary> Connected client, to use to respond. </summary>
		public Client client { get; private set; }
		/// <summary> Original raw message </summary>
		public string message { get; private set; }
		/// <summary> Timestamp of object creation </summary>
		public DateTime recievedAt { get; private set; }
		/// <summary> Individual pieces of the request </summary>
		public string[] content { get; private set; }

		/// <summary> RPC method requested </summary>
		public string methodName { get; private set; }
		/// <summary> Number of arguments in this request </summary>
		public int numArgs { get; private set; }

		/// <summary> Gets the argument by number. Valid indexes are in [0, numArgs-1] </summary>
		/// <param name="index"> Index of argument to retrieve </param>
		/// <returns> Argument of the given index </returns>
		public string this[int index] { get { return content[index+1]; } }

		public RPCMessage(Client source, string str) {
			client = source;
			message = str;
			recievedAt = DateTime.UtcNow;
			content = message.Split(Client.SEP);

			methodName = content[0];
			numArgs = content.Length - 1;

		}
	
	}

}
