using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaBaka;
using TMPro;
using LevelUpper.Markdown;
using BakaNet.Modules;
using LevelUpper.Extensions;
using LevelUpper.Debugs;

namespace BakaNet {

	public class Entity : ClientBehaviour {

		
		public static Dictionary<string, Transform> registeredPrefabs = new Dictionary<string, Transform>();



		public static Entity localEntity = null;

		static SyncData entityData;

		static Entities entityModule;

		public string id { get; private set; }

		public bool isPlayer { get { return id == entityModule?.localID; } }

		/// <summary> Gets the data object for this entity. </summary>
		public JsonObject ownData { get { return entityData.ReadClient(id) as JsonObject; } }

		/// <summary> Reads a given property from the data object for this entity. </summary>
		/// <param name="property"> Property to read </param>
		/// <returns> JsonValue of the property </returns>
		public JsonValue Read(string property) { return entityData.ReadClient(id + "." + property); }

		/// <summary> Reads a given property from the data object as a <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic type </typeparam>
		/// <param name="property"> Property to read </param>
		/// <returns> Value of the property read as a <typeparamref name="T"/> </returns>
		public T Read<T>(string property) { return Json.GetValue<T>(Read(property)); }

		/// <summary> Creates a function that samples the given property of the local (player) entity data as a <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic type </typeparam>
		/// <param name="name"> Property to read </param>
		/// <param name="defaultValue"> Default value to use if there is no local entity </param>
		/// <returns> Function which reads the property as a <typeparamref name="T"/> when invoked </returns>
		public static Func<T> LocalReader<T>(string name, T defaultValue) {
			return () => {
				return localEntity != null
					? Json.GetValue<T>(localEntity.Read(name))
					: defaultValue;
			};
		}

		/// <summary> Creates a function that samples the given property of the given entity data as a <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic type </typeparam>
		/// <param name="name"> Property to read </param>
		/// <returns> Function which reads the property as a <typeparamref name="T"/> when invoked </returns>
		public Func<T> Reader<T>(string name) {
			return () => {
				return Json.GetValue<T>(Read(name));
			};
		}


		public Transform modelObject;
		public Transform nameObject;
		public Transform spriteObject;
		public Transform ghostObject;
	
		Vector3 lastPositionSent;
		Quaternion lastRotationSent;
		Vector3 lastVelocitySent;
		Vector3 lastAngularVelocitySent;

		public Vector3 velocity;
		public Vector3 angularVelocity;

		public Action<Entity, JsonObject> interpolationFunction;

		public static Action<Transform, Vector3> onRubberBand;

		public static Action<Transform> onSpawnGhost;

		/// <summary> Callback chain when a player entity is given a model </summary>
		public static Action<Entity> onPlayerModel;

		public List<IHook<JsonObject>> hooks;

		/// <summary> Creates a closure of a function which can be used to interpolate an entity. </summary>
		/// <returns> Function taking and updating an entity with dead reckoning based on position/rotation and velocity/angularvelocity </returns>
		public static Action<Entity, JsonObject> DeadReckoningInterpolationFunction() {
		
			Vector3 lastPositionRead = Vector3.zero;
			Quaternion lastRotationRead = Quaternion.identity;

			return (e, data)=>{ 
				var positionRead = data.Get<Vector3>("position");
				var rotationRead = data.Get<Quaternion>("rotation");
				var velocityRead = data.Get<Vector3>("velocity");
				var angularVelocityRead = data.Get<Vector3>("angularVelocity");

				if (positionRead != lastPositionRead) { e.transform.position = positionRead; }
				if (rotationRead != lastRotationRead) { e.transform.rotation = rotationRead; }
				lastPositionRead = positionRead;
				lastRotationRead = rotationRead;
			
				e.transform.position += velocityRead * Time.deltaTime;
				e.transform.rotation *= Quaternion.Euler(angularVelocityRead * Time.deltaTime);
			};

		}

		/// <summary> Creates a closure of a function which can be used to interpolate an entity. </summary>
		/// <param name="moveDampening"> Dampening to apply to position </param>
		/// <param name="rotDampening"> Dampening to apply to rotation </param>
		/// <returns> Function taking and updating an entity based on moving/rotating the entity towards its targets at a given rate </returns>
		public static Action<Entity, JsonObject> SmoothInterpolationFunction(float moveDampening = 9, float rotDampening = 11) {
		
			return (e, data) => {
				var positionRead = data.GetV3("position");
				var rotationRead = data.GetQ("rotation");
				

				e.transform.position = Vector3.Lerp(e.transform.position, positionRead, Time.deltaTime * moveDampening);
				e.transform.rotation = Quaternion.Lerp(e.transform.rotation, rotationRead, Time.deltaTime * rotDampening);

			};
		}


		public float tickrate = 25;
		[NonSerialized] public float tickTime = 0;
		//private static readonly JsonArray emptyArray = new JsonArray();
		private static readonly JsonObject emptyObject = new JsonObject();
		private RectTransform useUI = null;

		void Awake() {
			id = gameObject.name;
			hooks = new List<IHook<JsonObject>>();

			hooks.Add(new JsonHook<string>("model", "default", UpdateModel));
			hooks.Add(new JsonHook<string>("name", "", UpdateName));
			hooks.Add(new JsonHook<string>("sprite", "none", UpdateSprite));
			hooks.Add(new JsonHook<float>("scale", 1f, (scale)=>{ 
				if (modelObject != null) { modelObject.localScale = Vector3.one * scale; } 
				if (spriteObject != null) { spriteObject.localScale = Vector3.one * scale; } 

			}));
			hooks.Add(new JsonHook<JsonObject>("usable", emptyObject, UpdateUsable));
			
			hooks.Add(new JsonHook<float>("radius", 1f, (radius)=>{ 
				var gizmo = transform.Require<DrawsGizmo>();
				gizmo.sphere = true;
				gizmo.size = Vector3.up * radius;
			}));

			if (entityModule == null) { entityModule = GetModule<Entities>(); }	
			if (entityData == null) { entityData = SyncData.Context("Entities"); }
		
			if (isPlayer) {

				localEntity = this;
			} else {

			}
		

			DontDestroyOnLoad(gameObject);
		}
	
		void Start() {
			JsonObject data = ownData;
			if (isPlayer) {
				transform.position = data.Get<Vector3>("position");
				transform.rotation = data.Get<Quaternion>("rotation");
			} else {
				if (data != null) {
					if (data["type"].stringVal == "bullet") {
						interpolationFunction = DeadReckoningInterpolationFunction();
					}
				}
			}
			

		}
	
		void LateUpdate() {
			tickTime += Time.deltaTime;
		
			if (tickTime > (1f / tickrate)) {
				tickTime -= (1f / tickrate);
				
				JsonObject data = ownData;
				if (data != null) {
			
					foreach (var hook in hooks) { hook.Read(data); }

					if (!isPlayer) {
						interpolationFunction?.Invoke(this, data);
					} else {
						ghostObject.position = data.Get<Vector3>("position"); 
						ghostObject.rotation = data.Get<Quaternion>("rotation");
					}
				}
				
				if (isPlayer) {
					SendMotionUpdate();
				}

			}

		}
		void OnDestroy() {
			if (useUI != null) {
				Destroy(useUI.gameObject);
			}
		}

		private void SendMotionUpdate() {
			JsonObject obj = null;
			if ((transform.position - lastPositionSent).magnitude > Entities.minMoveDelta) {
				obj = obj ?? new JsonObject();
				obj["position"] = Json.Reflect(transform.position);

				lastPositionSent = transform.position;
			}
			if (Quaternion.Angle(transform.rotation, lastRotationSent) > Entities.minRotDelta) {
				obj = obj ?? new JsonObject();
				obj["rotation"] = Json.Reflect(transform.rotation);

				lastRotationSent = transform.rotation;
			}

			if (lastVelocitySent != velocity) {
				obj = obj ?? new JsonObject();
				obj["velocity"] = Json.Reflect(velocity);

				lastVelocitySent = velocity;
			}

			if (lastAngularVelocitySent != angularVelocity) {
				obj = obj ?? new JsonObject();
				obj["angularVelocity"] = Json.Reflect(angularVelocity);

				lastAngularVelocitySent = angularVelocity;
			}

			if (obj != null) {
				entityModule.localClient.Send("Move", obj);
			}
		}

		public static Transform LoadModel(string model) {
			if (registeredPrefabs.ContainsKey(model)) { return registeredPrefabs[model]; }
			
			Transform modelPrefab = Resources.Load<Transform>("Models/" + model)
				?? Resources.Load<Transform>("Models/Error");
		
			return modelPrefab;
		}


		static readonly string[] colors = {
			"_Color",
			"_Color1",
			"_Color2",
			"_Color3",
		};

		public void RubberBand(Vector3 position) {
			StartCoroutine(RubberBand_(position));
		}

		
		public IEnumerator RubberBand_(Vector3 pos) {
			yield return new WaitForEndOfFrame();
			onRubberBand?.Invoke(transform, pos);
			transform.position = pos;
		}

		private void UpdateModel(string readModel) {
			if (modelObject != null) { Destroy(modelObject.gameObject); }
			modelObject = Instantiate(LoadModel(readModel), transform.position, transform.rotation);
			modelObject.SetParent(transform);


			var data = ownData;
			var colorData = ownData?.Get<JsonObject>("colors");
			Color?[] entity_colors = new Color?[colors.Length];
			
			if (colorData != null) {
				for (int i = 0; i < colors.Length; i++) {
					string colorName = colors[i];
				
					if (colorData.Has(colorName)) {
						var colVal = colorData[colorName];
						if (colVal.isObject) {
							entity_colors[i] = Json.GetValue<Color>(colVal);
						} else if (colVal.isString) {
							Color parsed;
							if (Colors.TryParse(colVal.stringVal, out parsed)) {
								entity_colors[i] = parsed;
							}
						}
					}
				}

				MaterialPropertyBlock block = new MaterialPropertyBlock();
				foreach (var renderer in modelObject.GetComponentsInChildren<Renderer>()) {
					renderer.GetPropertyBlock(block);
					for (int i = 0; i < entity_colors.Length; i++) {
						var col = entity_colors[i];
						if (col.HasValue) {
							block.SetColor(colors[i], col.Value);
						}
					}
					renderer.SetPropertyBlock(block);
				}

			}

			if (isPlayer) {

				// Ghost
				ghostObject = Instantiate(modelObject, transform.position, transform.rotation);
				ghostObject.parent = null;
				DontDestroyOnLoad(ghostObject.gameObject);

				foreach (var renderer in ghostObject.GetComponentsInChildren<Renderer>()) {
					var mats = renderer.materials;
					foreach (var mat in mats) {
						mat.shader = Shader.Find("Recolor/Transparent/Diffuse Clip");
						for (int i = 0; i < entity_colors.Length; i++) {
							string colorName = colors[i];
							var col = entity_colors[i].HasValue ? entity_colors[i].Value : mat.GetColor(colorName);
							col.a *= .25f;
							mat.SetColor(colorName, col);
						}
					}
				}
				onSpawnGhost?.Invoke(ghostObject);
				onPlayerModel(this);
			}
		}

		private void UpdateName(string readName) {
			if (readName == null || readName.Length == 0) {
				if (nameObject != null) {
					Destroy(nameObject.gameObject);
				}
			} else {

				if (nameObject == null) { 

					nameObject = Instantiate(Resources.Load<Transform>("Text"), transform.position, transform.rotation);
					nameObject.SetParent(transform);
					nameObject.localPosition = Vector3.up;
					var bb = nameObject.gameObject.AddComponent<Billboard>();
					bb.matchRotationMode = true;
					bb.flip = true;
					bb.doLate = true;
				}

				var tmp = nameObject.GetComponent<TextMeshPro>();
				tmp.text = ("\\j" + readName).ReplaceColors();
		
			}
		}

		// Required to use "Sprite" object for sprites.
		private void UpdateSprite(string readSprite) {
			if (readSprite == null || readSprite.Length == 0) { readSprite = "none"; }
			
			if (readSprite == "none") {
				if (spriteObject != null) { Destroy(spriteObject.gameObject); }

			} else {
				if (spriteObject == null) {
					spriteObject = Instantiate(Resources.Load<Transform>("Sprite"), transform.position, transform.rotation);
					spriteObject.SetParent(transform);
					spriteObject.localPosition = Vector3.zero;

				} 

				SpriteRenderer rend = spriteObject.GetComponentInChildren<SpriteRenderer>();
				string[] splits = readSprite.Split('.');
				string spriteName = splits[0];
				int index = 0;
				if (splits.Length > 1) { int.TryParse(splits[1], out index); }
				

				Sprite[] sprites = Resources.LoadAll<Sprite>(spriteName);
				if (sprites != null && sprites.Length > 0) {
					rend.sprite = sprites[index];
				}

			}

		}

		private void UpdateUsable(JsonObject obj) {
			if (useUI != null) { Destroy(useUI.gameObject); useUI = null; }
			
			if (!obj.IsEmpty) {
				int i = 0;
				// Do an iterative count over obj to not lock the ConcurrentDictionary inside of it...
				foreach (var pair in obj) { i++; }
				
				useUI = GGUI.Render(() => {
					Rect brush = GGUI.unitRect;
					brush.height /= i;
					foreach (var pair in obj) {
						string label = pair.Value.stringVal;
						string action = pair.Key.stringVal;
						GGUI.Button(brush, label, ()=>{ 
							//Debug.Log("Used " + action + ":" + label);
							NetworkDaemon.main.SendToServer("Use", id, action);
						});	
					}
					brush.y -= brush.height;
				}, new Rect(0,.1f,.2f, .05f * i), transform);

			}


				
		}

	}

}
