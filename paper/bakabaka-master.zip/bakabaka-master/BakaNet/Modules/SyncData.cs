using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaBaka;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BakaNet.Modules {

	/// <summary> 
	/// <para>
	///		Module that provides some automatic data sync between clients and servers. 
	///		Only one should be attached per server/client.
	/// </para>
	/// <para>
	///		References to individual instances can be obtained via the static <see cref="Context"/> method.
	/// </para>
	/// </summary>
	public class SyncData : Module {

		/// <summary> Cache of all created SyncData contexts. </summary>
		private static ConcurrentDictionary<string, SyncData> contexts = new ConcurrentDictionary<string, SyncData>();

		/// <summary> Retrieve a SyncData context by name. Creates a context if one does not already exist. </summary>
		/// <param name="name"> Name of context to retrieve. </param>
		/// <returns> SyncData context with the given name. </returns>
		public static SyncData Context(string name) {
			if (!contexts.ContainsKey(name)) {
				contexts[name] = new SyncData(name);
			}

			return contexts[name];
		}

		/// <summary> Gets a context by name, if it exists. </summary>
		/// <param name="name"></param>
		/// <returns></returns>
		public static SyncData Get(string name) {
			if (contexts.ContainsKey(name)) { return contexts[name]; }
			return null;
		}
		
		/// <summary> Local data. Sync to this when accessing data from a client-only context within a script </summary>
		public JsonObject locJson { get; private set; }
		/// <summary> Server data. Sync to this when accessing data from a server-only context within a script </summary>
		public JsonObject srvJson { get; private set; } 

		/// <summary> Changes to the server data that need to be reflected on the clients </summary>
		private JsonObject srvDirty;

		/// <summary> Whitelist </summary>
		public HashSet<string> whitelist { get; private set; }

		/// <summary> Function to figure out to apply the whitelist to a given client for a given set of data. By default, nothing is whitelisted. </summary>
		public Func<Client, string, bool> useWhitelist;
	
		/// <summary> Tracks what sets of data clients are subscribed to </summary>
		public ConcurrentDictionary<Client, ConcurrentSet<string>> subscriptions;

		/// <summary> Name of the SyncData context </summary>
		public string name { get; private set; }
		/// <summary> Is this context the debug context? </summary>
		private bool isDebug { get; set; }

		/// <summary> Default set of subscriptions for newly connected clients. </summary>
		private string[] defaultSubs = { };

		/// <summary> Data to initialize with when starting as a server. </summary>
		public JsonObject defaultData = null;

		/// <summary> Assigns a set of subscriptions to the defaults for this syncData. 
		/// Should only be called once per instance. Do all such initialization in one place.</summary>
		/// <param name="subs"> Sets to subscribe to by default. </param>
		public void DefaultSubs(params string[] subs) { defaultSubs = subs; }

		/// <summary> Assigns data for the initalization of this syncdata.
		/// Should only be called once per instance. Do all such initialization in one place.</summary>
		/// <param name="data"> Data to use as the default data. </param>
		public void DefaultData(JsonObject data) { defaultData = data; }
		
		private SyncData(string context) {
			name = context;
			isDebug = name == "Debug";
			whitelist = new HashSet<string>();
			useWhitelist = (cient, set) => { return false; };

		}

		float time;

		public override void OnServerAwake(Server s) {
			subscriptions = new ConcurrentDictionary<Client, ConcurrentSet<string>>();
			
			if (defaultData != null) {
				srvJson = defaultData.DeepCopy() as JsonObject;
			} else {
				srvJson = new JsonObject();
			}
			srvDirty = new JsonObject();

			if (isDebug) {
				time = 0;
				srvJson["gameState"] = new JsonObject("gravity", 9.8f, "tickrate", 100);
				srvJson["Test"] = new JsonObject("blah", "blarg", "Only", "Top", "Level", "Objects", "Get", "Syncd");
				srvJson["Of"] = "Not an object, This doesn't get sync'd";
				srvJson["Data"] = new JsonArray("Not", "an", "object,", "Neither", "does", "this");
			}

		}

		public override void OnClientAwake(Client c) {
			if (c.isLocal) { 
				locJson = new JsonObject();
			}

		}

		/// <summary> Marks the data at the given <paramref name="path"/> as dirty, sending updates to all clients who can receive them </summary>
		/// <param name="path"> Path to mark as dirty </param>
		public void SetDirty(string path) {
			if (!IsServer) { return; }
			// TBD: Don't use setData to mark things as dirty- whole idea was to avoid that!
			SetData(path, ReadServer(path));
		}
		

		/// <summary> Increments the data stored at <paramref name="path"/> by <paramref name="value"/>, considering the value there as a float. </summary>
		/// <param name="path"> path to read/write </param>
		/// <param name="value"> value to add/subtract from the given path </param>
		public void Increment(string path, float value) {
			if (!IsServer) { return; }
			var val = ReadServer(path).floatVal;
			SetData(path, val + value);
		}

		/// <summary> Sets data at <paramref name="path"/> to be the JSON reflection of <paramref name="value"/> </summary>
		/// <param name="path"> Path in context to store data at </param>
		/// <param name="value"> Object to reflect and store into data </param>
		public void SetData(string path, object value) {
			if (IsServer) {
				// TBD???: Move the main logic of this into an ongoing task, and place information into a queue. ???
				//			-- May be done via refactoring of modules to work via message passing queues
				if (path.Contains('.')) {
					string[] pathSplits = path.Split('.');

					JsonObject srvCursor = srvJson;
					JsonObject drtCursor = srvDirty;

					for (int i = 0; i < pathSplits.Length-1; i++) {
						string field = pathSplits[i];
			
						JsonObject srvNext = srvCursor[field] as JsonObject;
						JsonObject drtNext = drtCursor[field] as JsonObject;

						if (srvNext == null) { srvCursor[field] = new JsonObject(); srvNext = srvCursor[field] as JsonObject; }
						if (drtNext == null) { drtCursor[field] = new JsonObject(); drtNext = drtCursor[field] as JsonObject; }

						srvCursor = srvNext;
						drtCursor = drtNext;

					}

					string lastField = pathSplits[pathSplits.Length - 1];
					JsonValue rfl = Json.Reflect(value);
					srvCursor[lastField] = rfl;
					drtCursor[lastField] = rfl;
				} else {
					JsonValue rfl = Json.Reflect(value);
					srvJson[path] = rfl;
					srvDirty[path] = rfl;
				}
				
			} else {
				throw new Exception("Updates to SyncData can only be done on a Server!");
			}
		}

		/// <summary> Merges <paramref name="changes"/> deltas onto the data at the given <paramref name="path"/>. </summary>
		/// <param name="path"> Path to apply <paramref name="changes"/> to. </param>
		/// <param name="changes"> Changes to apply onto <paramref name="path"/>. </param>
		public void Merge(string path, JsonObject changes) {
			if (IsServer) {
				if (changes.IsEmpty) { return; }

				Daemon.Log("Merging SyncData" + name + ":" + path, LogLevel.Maximal);

				string[] pathSplits = path.Split('.');

				JsonObject srvCursor = srvJson;
				JsonObject drtCursor = srvDirty;

				for (int i = 0; i < pathSplits.Length - 1; i++) {
					string field = pathSplits[i];

					JsonObject srvNext = srvCursor[field] as JsonObject;
					JsonObject drtNext = drtCursor[field] as JsonObject;

					if (srvNext == null) { srvCursor[field] = new JsonObject(); srvNext = srvCursor[field] as JsonObject; }
					if (drtNext == null) { drtCursor[field] = new JsonObject(); drtNext = drtCursor[field] as JsonObject; }

					srvCursor = srvNext;
					drtCursor = drtNext;

				}
				
				string lastField = pathSplits[pathSplits.Length - 1];
				JsonObject srvTarget = srvCursor[lastField] as JsonObject ?? new JsonObject();
				JsonObject drtTarget = drtCursor[lastField] as JsonObject ?? new JsonObject();
				foreach (var pair in changes) {
					srvTarget[pair.Key] = pair.Value;
					drtTarget[pair.Key] = pair.Value;
				}
				//JsonValue rfl = Json.Reflect(value);
				srvCursor[lastField] = srvTarget;
				drtCursor[lastField] = drtTarget;

			} else {
				throw new Exception("Updates to SyncData can only be done on a Server!");
			}
		}

		/// <summary> Reads data from the client cache. </summary>
		/// <param name="path"> Path to read data from </param>
		/// <returns> JsonValue at path within <see cref="locJson"/>, or null if it doesn't exist </returns>
		public JsonValue ReadClient(string path) { return Get(path, locJson); }
		
		/// <summary> Reads data from the client cache, and interprets it as an object of type <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic Type </typeparam>
		/// <param name="path"> Path to read data from </param>
		/// <param name="defaultValue"> Default value to return if anything fails. </param>
		/// <returns> Data in client cache at <paramref name="path"/>, if it exists, otherwise <paramref name="defaultValue"/> </returns>
		public T PullClient<T>(string path, T defaultValue) {
			var val = ReadClient(path);
			if (val != null) {
				return Json.GetValue<T>(val);
			}
			return defaultValue;
		}


		/// <summary> Reads data from the server cache. </summary>
		/// <param name="path"> Path to read data from </param>
		/// <returns> JsonValue at path within <see cref="srvJson"/>, or null if it doesn't exist </returns>
		public JsonValue ReadServer(string path) { return Get(path, srvJson); }

		/// <summary> Reads data from the server cache, and interprets it as an object of type <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic Type </typeparam>
		/// <param name="path"> Path to read data from </param>
		/// <param name="defaultValue"> Default value to return if anything fails. </param>
		/// <returns> Data in server cache at <paramref name="path"/>, if it exists, otherwise <paramref name="defaultValue"/> </returns>
		public T PullServer<T>(string path, T defaultValue) {
			var val = ReadServer(path);
			if (val != null) {
				return Json.GetValue<T>(val);
			}
			return defaultValue;
		}

		/// <summary> Removes a value from the server's data by setting it to null. </summary>
		/// <param name="path"> Path to value to remove. </param>
		public void RemoveServer(string path) { SetData(path, null); }

		/// <summary> Used to read from either the local or server data in ReadServer/ReadClient </summary>
		/// <param name="path"> Path to read </param>
		/// <param name="obj"> Object containing data to read from </param>
		/// <returns> Value at the given path </returns>
		internal static JsonValue Get(string path, JsonObject obj) {
			//if (path == null) { return JsonNull.instance; }

			string[] pathSplits = path.Split('.');
			JsonObject cursor = obj;

			for (int i = 0; i < pathSplits.Length-1; i++) {
				string field = pathSplits[i];
				JsonObject next = cursor[field] as JsonObject;

				if (next == null) { return JsonNull.instance; }
				cursor = next;
			}

			string lastField = pathSplits[pathSplits.Length - 1];

			return cursor[lastField];
		}

		public override void Update() {

			if (IsServer && isDebug) {
				float lastTime = time;
				time += delta;
				float tick = .5f;
				if (lastTime % tick > time % tick) {

					SetData("gameState.info.time", time);
				}
			}

			JsonObject dirtyChanges = new JsonObject();
			dirtyChanges = Interlocked.Exchange(ref srvDirty, dirtyChanges);

			if (!dirtyChanges.IsEmpty) {

				foreach (var pair in subscriptions) {
					Client c = pair.Key;
					ConcurrentSet<string> subs = pair.Value;

					JsonObject update = BuildJsonUpdate(c, subs, dirtyChanges);
					
					if (update.Count > 0) {
						c.Send("SyncJson", name, update.ToString());
					}

				}

			}

		}

		public override void OnConnected(Client c) {
			if (!c.isLocal) {
				if (defaultSubs.Length > 0) {
					DoSubscribe(c, defaultSubs);
				}

			} else if (isDebug) { SubscribeTo("Test", "Sets", "Of", "Data", "gameState"); }

		}

		public override void OnDisconnected(Client c) {
			if (!c.isLocal) {
				ConcurrentSet<string> __;
				subscriptions.TryRemove(c, out __);
			}
		}
		/// <summary> Called on a client to send an RPC to the server to subscribe them to sets of data. </summary>
		/// <param name="sets"> Names of sets to subscribe to </param>
		public void SubscribeTo(params string[] sets) {
			if (localClient != null) {
				object[] joined = new[] { "Subscribe", name }.Concat(sets).ToArray();
				localClient.Send(joined);
			}
		}


		/// <summary> Called on a client to send an RPC to the server to unsubscribe them from sets of data. </summary>
		/// <param name="sets"> Names of sets to unsubscribe from </param>
		public void UnsubscribeTo(params string[] sets) {
			if (localClient != null) {
				object[] joined = new[] { "Unsubscribe", name }.Concat(sets).ToArray();
				localClient.Send(joined);
				foreach (string s in sets) {
					if (locJson.ContainsKey(s)) { locJson.Remove(s); }
				}
			}
		}

		/// <summary> RPC, Server->Client. Applies JsonData recieved over the wire. </summary>
		/// <param name="msg"> RPC Message info. </param>
		void SyncJson(RPCMessage msg) {
			string target = msg[0];
			if (target != name) { return; }
			Client c = msg.client;
			if (c.isLocal) {

				JsonObject data = Json.TryParse(msg[1]) as JsonObject;
				if (data != null) {

					locJson.SetRecursively(data);
				}
				
			}
			
		}

		/// <summary> RPC, Server->Client. Clears the given sets of data from the local data set. </summary>
		/// <param name="msg"> RPC Message info. </param>
		void ClearJson(RPCMessage msg) {
			string target = msg[0];
			if (target != name) { return; }
			Client c = msg.client;
			if (c.isLocal) {
				for (int i = 1; i < msg.numArgs; i++) {
					if (locJson.ContainsKey(msg[i])) {
						locJson.Remove(msg[i]);
					}
				}

			}
		}
		/// <summary> RPC, Server->Client. Clears all datas from the local data set. </summary>
		/// <param name="msg"> RPC Message Info </param>
		void ClearAllJson(RPCMessage msg) {
			string target = msg[0];
			if (target != name) { return; }
			Client c = msg.client;
			if (c.isLocal) {
				locJson.Clear();
			}
		}

		/// <summary> RPC, Client->Server, subscribes client to given sets of data. </summary>
		/// <param name="msg"> RPC Message info. </param>
		void Subscribe(RPCMessage msg) {
			string context = msg[0];
			Client c = msg.client;
			
			if (context == name && !c.isLocal) {
				string[] args = new string[msg.numArgs-1]; // Skip the first arg, as it is the context.
				for (int i = 1; i < msg.numArgs; i++) { args[i-1] = msg[i]; }

				DoSubscribe(msg.client, args);
			} 
		}


		/// <summary> Actually subscribes the client to the set of data in this context, and sends a sync update for all sub'd data. </summary>
		/// <param name="c"> Client to subscribe </param>
		/// <param name="sets"> sets of data to subscribe to </param>
		public void DoSubscribe(Client c, params string[] sets) {
			if (!subscriptions.ContainsKey(c)) { subscriptions[c] = new ConcurrentSet<string>(); }

			ConcurrentSet<string> newSets = new ConcurrentSet<string>();
			for (int i = 0; i < sets.Length; i++) {
				string set = sets[i];
				subscriptions[c].Add(set);
				newSets.Add(set);
				if (isDebug) { Daemon.Print(c.identity + " Subscribed to " + set); }
				
			}
			
			JsonObject newStuff = BuildJsonUpdate(c, newSets, srvJson);

			c.Send("SyncJson", name, newStuff.ToString());

		}

		/// <summary> RPC, Client->Server, unsubscribes client from given sets of data. </summary>
		/// <param name="msg"> RPC Message info. </param>
		void Unsubscribe(RPCMessage msg) {
			string context = msg[0];
			Client c = msg.client;
			if (context == name && !c.isLocal) {
				string[] args = new string[msg.numArgs-1];
				for (int i = 1; i < msg.numArgs; i++) { args[i-1] = msg[i]; } // Skip the first arg, as it is the context. 

				DoUnsubscribe(msg.client, args);
			}
		}

		/// <summary> Actually unsubscribes client from the set of data in this context. Sends them a message to clean up that data. </summary>
		/// <param name="c"> Client to unsubscribe </param>
		/// <param name="sets"> Sets of data to unsubscribe from. </param>
		public void DoUnsubscribe(Client c, params string[] sets) {

			if (subscriptions.ContainsKey(c)) {
				for (int i = 0; i < sets.Length; i++) {
					string set = sets[i];
					subscriptions[c].Remove(set);
					Daemon.Log(c.identity + " \\eUnsubbed from " + set, LogLevel.Maximal);
				}
				object[] prams = new[]{ "ClearJson", name }.Concat(sets).ToArray();
				c.Send(prams);
			}
		}

		/// <summary> Actually unsubscribes client from all sets of data in this context. Sends them a message to clean up all data. </summary>
		/// <param name="c"> Client to unsubscribe </param>
		public void DoUnsubscribeAll(Client c) {
			if (subscriptions.ContainsKey(c)) {
				subscriptions[c].Clear();	
				c.Send("ClearAllJson", name);
			}
		}

		/// <summary> 
		/// Performs any unsubscribing and subscribing that needs to happen to make the client 
		/// subscribed to only the sets in <paramref name="sets"/>, 
		/// each batched into one DoUnsubscribe and DoSubscribe call.
		/// </summary>
		/// <param name="c"> Client to un/subscribe </param>
		/// <param name="sets"> Sets of data the client should be subscribed to. </param>
		public void DoBatchSub(Client c, HashSet<string> sets) {
			if (!subscriptions.ContainsKey(c)) { subscriptions[c] = new ConcurrentSet<string>(); }
			List<string> unSub = new List<string>();
			List<string> toSub = new List<string>();

			var subs = subscriptions[c];
			foreach (var id in subs) {
				if (!sets.Contains(id)) { unSub.Add(id); }
			}
			foreach (var id in sets) {
				if (!subs.Contains(id)) { toSub.Add(id); }
			}

			DoUnsubscribe(c, unSub.ToArray());
			DoSubscribe(c, toSub.ToArray());
		}


		/// <summary> Builds an update message to send to the given client. </summary>
		/// <param name="client"> Client for update to be sent to </param>
		/// <param name="subs"> Sets of data to include in the update </param>
		/// <param name="dirty"> Data that has changed (to build the update against) </param>
		/// <returns> JsonObject containing the relevant data for that client. </returns>
		internal JsonObject BuildJsonUpdate(Client client, ConcurrentSet<string> subs, JsonObject dirty) {
			
			//StringBuilder str = "";
			//str = str + "Building Update from\n" + dirty.PrettyPrint();

			JsonObject update = new JsonObject(new Dictionary<JsonString, JsonValue>() );
			foreach (var sub in subs) {

				bool applyWhiteList = useWhitelist(client, sub);

				//if (Daemon.logLevel >= LogLevel.Maximal) { str = str + "\n" + sub + "?"; }
				JsonObject set = dirty[sub] as JsonObject;
				if (set != null) {
					if (set["hidden"]) { continue; }
					//if (Daemon.logLevel >= LogLevel.Maximal) { str = str + "Yes! - adding"; }
					// ?????: If there's a concurrency issue here, make it a deepcopy maybe?
					if (applyWhiteList) {
						update[sub] = set.Mask(whitelist);
					} else {
						update[sub] = set;
					}

				}
			}
			//Daemon.Log(str, LogLevel.Maximal);
			return update;
		}

		

		public static readonly Color[] ALTERNATE_COLORS = { Color.white, new Color(.8f, .8f, .8f) };
		private bool displayLocal = true;
		private Vector2 scroll;
		public ConcurrentSet<string> expandedSets;
		private struct Pair { 
			public string key;
			public JsonString Key;
			public JsonValue Value; 
			public Pair(JsonString key, JsonValue value) { this.key = (Key = key).stringVal; Value = value; }
			public Pair(KeyValuePair<JsonString, JsonValue> pair) { key = (Key = pair.Key).stringVal; Value = pair.Value; }
		}
		private List<Pair> cachedDraw;

		public override void DrawIMGUI(Rect area) {
			bool isLayout = Event.current.type == EventType.Layout;
			if (cachedDraw == null) { cachedDraw = new List<Pair>(); }
			
			Rect brush = area;
			brush.height = 20;
			
			GUI.Box(brush, "SyncData Context [" + name + "]");
			brush.y += brush.height;


			if (IsServer) {

				GUI.Label(brush, displayLocal ? "Showing Client" : "Showing Server");
				brush.y += brush.height;

				if (GUI.Button(brush, "Toggle")) { displayLocal = !displayLocal; }
				brush.y += brush.height;

			}

			brush.height = area.height - brush.y;
			expandedSets = expandedSets ?? new ConcurrentSet<string>();

			if (isLayout) {
				JsonObject toDisplay = (displayLocal ? locJson:srvJson);
				cachedDraw.Clear();
				foreach (var pair in toDisplay) { cachedDraw.Add(new Pair(pair)); }
				cachedDraw.Sort( (a, b) => b.key.CompareTo(a.key) );
			}
			int i = 0;
			GUILayout.BeginArea(brush); {
				scroll = GUILayout.BeginScrollView(scroll); {
					
					foreach (var pair in cachedDraw) {

						GUI.color = ALTERNATE_COLORS[(i++)%ALTERNATE_COLORS.Length];
						string key = pair.key;
						bool expand = expandedSets.Contains(pair.key);
						GUILayout.BeginHorizontal("box"); {

							if (GUILayout.Button(expand ? "-" : "+", GUILayout.ExpandWidth(false))) { 
								if (expand) { expandedSets.Remove(pair.key); } else { expandedSets.Add(pair.key); }
							}

							string label = key;
							if (pair.Value.ContainsKey("type")) { label += " t=" + pair.Value["type"].stringVal; }
							if (pair.Value.ContainsKey("name")) { label += " n=" + pair.Value["name"].stringVal; }
							GUILayout.Label(label);

						} GUILayout.EndHorizontal();

						if (expand) {
							GUILayout.Label(pair.Value.PrettyPrint());
						}

					}

				} GUILayout.EndScrollView();
			} GUILayout.EndArea();

			/*
			string display = (displayLocal ? locJson : srvJson).PrettyPrint();
			var content = new GUIContent(display);
			Vector2 size = GUI.skin.label.CalcSize(content);
			
			Rect view = brush;
			view.height = size.y;
			view.width = Mathf.Max(size.x, view.width - 32);
			Rect inner = view;
			
			scroll = GUI.BeginScrollView(brush, scroll, view, false, true);{
				GUI.Label(inner, content);
			} GUI.EndScrollView();
			//*/


		}


	}


}
