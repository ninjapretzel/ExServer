using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaNet.Utils;
using BakaBaka.Utils;

namespace BakaNet.Modules {
	
	/// <summary> Provides no encryption, but encodes transmissions using Base64 to mangle them a bit :) </summary>
	public class Base64Armor : Module {
	
		public Base64Armor() { }

		public override void OnClientAwake(Client c) {
			c.SetEncDec(Encrypt, Decrypt);
		}

		public static byte[] Encrypt(byte[] data) {
			//Debug.Log("Encrypting " + data.Length + "bytes...");
			string armored = Convert.ToBase64String(data);
			return armored.ToBytes();
		}
		// Have to do a bit more work on the recieving end with this I guess...
		public static byte[] Decrypt(byte[] data) {
			string str = data.GetString();
			//Debug.Log("Decrypting " + data.Length + "bytes... [" + str + "]");
		
			List<byte> bytes = new List<byte>();
		
			StringBuilder builder = "";
		
			for (int i = 0; i < str.Length; i++) {
				char c = str[i];
				builder = builder+c;
				if (i % 4 == 3 && c == '=') {
					string pulled = builder.ToString();
					//Debug.Log("Decrypted " + pulled);
					bytes.AddRange(Convert.FromBase64String(pulled));
					builder.Clear();
				}
			}
		
			if (builder.Length != 0) { bytes.AddRange(Convert.FromBase64String(builder)); }
			return bytes.ToArray();
			//return Convert.FromBase64String(str);
		}

	
	}

}
