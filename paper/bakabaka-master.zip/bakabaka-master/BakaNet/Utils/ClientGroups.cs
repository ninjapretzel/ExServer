using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using LevelUpper.Extensions;
using System.Collections.Concurrent;

namespace BakaNet.Utils {
	/// <summary> Class used to keep track of sets of clients that receive certain messages, and send messages to various groups. </summary>
	public class ClientGroups {

		/// <summary> Alias class definition </summary>
		private class Group : ConcurrentSet<Client> { }


		private ConcurrentDictionary<string, Group> groups;

		public ClientGroups() {
			groups = new ConcurrentDictionary<string, Group>();

		}

		/// <summary> Adds the given client to the given group. Creates the group if it does not already exist. </summary>
		/// <param name="group"> Group id </param>
		/// <param name="client"> Client to add to group </param>
		public void AddToGroup(string group, Client client) {
		
			if (!groups.ContainsKey(group)) { 
				groups[group] = new Group();
			}
		
			groups[group].Add(client);

		}

		/// <summary> Removes a group from the collections, which disassociates all clients from it. </summary>
		/// <param name="group"> Group id</param>
		public void RemoveGroup(string group) {
			if (groups.ContainsKey(group)) {
				Group __;
				groups.TryRemove(group, out __);
			}
		}

		/// <summary> Removes a specific client from a specific group. </summary>
		/// <param name="group"> Group id </param>
		/// <param name="client"> Client to remove </param>
		public void RemoveFromGroup(string group, Client client) {
			if (groups.ContainsKey(group) && groups[group].Has(client)) {
				groups[group].Remove(client);
			}
		}

		/// <summary> Pass over all groups, and remove any references to disconnected clients. </summary>
		public void Prune() {
			foreach (var pair in groups) {
				pair.Value.RemoveWhere( c => !c.IsCommunicating );
			}
		}

		/// <summary> Sends a message to all clients in a given group </summary
		/// <param name="group"> Group id to send to </param>
		/// <param name="prams"> Message and parameters to send </param>
		public void Broadcast(string group, params object[] prams) {
			// All clients get the same message, only need to prepare it once. 
			string message = Client.FormatMessage(prams);

			// Also keep track of clients that are no longer connected to remove them from the group.
			List<Client> dead = null;

			Group g = groups[group];
			foreach (var c in g) {
				
				if (c.IsCommunicating) {
					c.SendMessageDirectly(message);

				} else {
					( dead ?? (dead = new List<Client>()) ).Add(c);
				}

			}

			// Prune any dead clients from the group. 
			if (dead != null) {		
				foreach (var died in dead) {
					g.Remove(died);
				}
			}
		
		}

		//private Vector2 scroll;
		/// <summary> Method to be able to quickly and easily draw UI for client groups </summary>
		/// <param name="area"> Area of the screen to draw into </param>
		public void DrawIMGUI(Rect area) {
			Rect brush = area;
			brush.height = 20;
		
			foreach (var pair in groups) {
				GUI.Label(brush, "Group [" + pair.Key + "]");
			}
		}


	}

}
