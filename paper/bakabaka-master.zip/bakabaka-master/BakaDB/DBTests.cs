using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaTest;
using BakaDB;

public static class DB_Tests {
	
	public static readonly string TEST_DB_NAME = "TestDatabase";
	private static readonly string TEST_FILE = "yo.wtf";

	public static LocalDB testDB { get { return DB.Local(TEST_DB_NAME); } }
	
	public static void Clean() {
		// Drop closes the database, and then deletes the directory.
		DB.Drop(TEST_DB_NAME);
		
		
	}
	
	public static void SetupEmpty() {

	}

	public static void TestBasics() {
		SetupEmpty();
		
		bool exists;
		bool existed = testDB.Exists(TEST_FILE);
		existed.ShouldBe(false);

		// Accessing indexer of unopened document should yield a null.
		JsonObject nothing = testDB[TEST_FILE] as JsonObject;
		nothing.ShouldBe(null);
		
		// Opening a new document should yield an empty object
		JsonObject first = testDB.Open(TEST_FILE, out existed) as JsonObject;
		first.Count.ShouldBe(0);
		existed.ShouldBe(false);
		exists = testDB.Exists(TEST_FILE);
		exists.ShouldBe(true);

		// Accessing database of open object should yield a copy.
		JsonObject first_again = testDB[TEST_FILE] as JsonObject;
		first_again.Count.ShouldBe(0);
		// Equal but not the same object
		first.ShouldEqual(first_again);
		first.ShouldNotBe(first_again);

		// Set something into the object
		first["data"] = "value";

		// Apply and save to database.
		testDB[TEST_FILE] = first;
		testDB.Save();
		// Close everything
		testDB.Close();

		// File should still exist, even if it is not opened.
		exists = testDB.Exists(TEST_FILE);
		exists.ShouldBe(true);
		// Closed existing document should still be null when accessed by indexer.
		nothing = testDB[TEST_FILE] as JsonObject;
		nothing.ShouldBe(null);
	
		// Open document again
		JsonObject second = testDB.Open(TEST_FILE, out existed) as JsonObject;
		existed.ShouldBe(true);
		// Data should be retained
		second.Count.ShouldBe(1);
		// But they should be separate objects
		second.ShouldNotBe(first);
		exists = testDB.Exists(TEST_FILE);
		exists.ShouldBe(true);

		// Access document again
		JsonObject second_again = testDB.Open(TEST_FILE) as JsonObject;
		// Should have same data, but be a different reference
		second_again.Count.ShouldBe(1);
		second.ShouldEqual(second_again);
		second.ShouldNotBe(second_again);
		
		// Add more data to blob object
		second["moreData"] = "anotherValue";
		testDB.Set(TEST_FILE, second);
		// Explicitly close the document
		testDB.Close(TEST_FILE);
		
		// Can directly open a file 
		existed = testDB.JustOpen(TEST_FILE);
		existed.ShouldBe(true);
		// And then withdraw the data separately.
		JsonObject third = testDB[TEST_FILE] as JsonObject;
		// Open() just wraps these operations
		// With an optional check to see if the document was on disk first.
		third.Count.ShouldBe(2);

		// No objects should be == eachother, should all be separate objects.
		first.ShouldNotBe(second);
		first.ShouldNotBe(third);
		second.ShouldNotBe(third);


	}

	public static void TestCheck() {
		SetupEmpty();

		bool existed;
		JsonObject record;
		JsonArray wrongTypeOfRecord;
		JsonValue generalRecord;
		
		existed = testDB.Check(TEST_FILE, out record);
		existed.ShouldBe(false);
		record.ShouldBe(null);

		existed = testDB.Check(TEST_FILE, out wrongTypeOfRecord);
		existed.ShouldBe(false);
		wrongTypeOfRecord.ShouldBe(null);

		existed = testDB.Check(TEST_FILE, out generalRecord);
		existed.ShouldBe(false);
		generalRecord.ShouldEqual(null);

		generalRecord = testDB.Check(TEST_FILE, out existed);
		existed.ShouldBe(false);
		generalRecord.ShouldEqual(null);

		testDB.Open(TEST_FILE);

		existed = testDB.Check(TEST_FILE, out record);
		existed.ShouldBe(true);
		record.ShouldNotBe(null);

		existed = testDB.Check(TEST_FILE, out wrongTypeOfRecord);
		existed.ShouldBe(true);
		wrongTypeOfRecord.ShouldBe(null);

		existed = testDB.Check(TEST_FILE, out generalRecord);
		existed.ShouldBe(true);
		generalRecord.ShouldNotEqual(null);

		generalRecord = testDB.Check(TEST_FILE, out existed);
		existed.ShouldBe(true);
		generalRecord.ShouldNotEqual(null);

	}


}
