using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using BakaNet.Utils;
using LevelUpper.Markdown;
using LevelUpper.Extensions;

using BakaBaka.Utils;
using System.Collections.Concurrent;
using System.IO;

namespace BakaBaka {
	
	
	/// <summary> 
	///		Behaviour for attaching to some object to track general Unity information for the BakaBaka library. 
	///		Also provides a way to place code to run on the main thread.
	/// </summary>
	public class Daemon : MonoBehaviour {

#if UNITY_EDITOR
		/// <summary> Utility class used to make the pause button work as expected for pausing tasks. </summary>
		[InitializeOnLoad]
		public static class DaemonEditorUtil {
			//static EditorApplication.CallbackFunction lastPlaymodeStateChange = null;

			static Action<PlayModeStateChange> playChange = null;
			static Action<PauseState> pauseChange = null;
			static DaemonEditorUtil() {
				/*
				
				if (lastPlaymodeStateChange != null) {
					EditorApplication.playmodeStateChanged -= lastPlaymodeStateChange;
				}
				lastPlaymodeStateChange = () => {
					bool paused = EditorApplication.isPaused;
					if (main != null && main.LogAppMessages) {
						Debug.Log("Editor Pause " + paused);
					}

					EditorPaused = UnityPaused = paused;
				};
				EditorApplication.playmodeStateChanged += lastPlaymodeStateChange; 
				//*/
				
				if (playChange != null) {
					EditorApplication.playModeStateChanged -= playChange;
				}
				playChange = (playState) => {
					
					Debug.Log("PlayState changed: " + playState);

					if (playState == PlayModeStateChange.EnteredPlayMode) {
						UnityRunning = true;
					}
					if (playState == PlayModeStateChange.ExitingPlayMode) {
						UnityRunning = false;
					}
					//playChange == PlayModeStateChange.
				};
				EditorApplication.playModeStateChanged += playChange;
				
				//*/

				if (pauseChange != null) {
					EditorApplication.pauseStateChanged -= pauseChange;
				}
				pauseChange = (pauseState) => {
					bool paused = pauseState == PauseState.Paused;
					Debug.Log("EditorPause " + paused);
					EditorPaused = UnityPaused = paused;
				};
				EditorApplication.pauseStateChanged += pauseChange;
				//*/
			}
		}
		public class CompilerHook : EditorWindow {
			[MenuItem("Baka/Compiler Hook")]
			public static void Init() {
				GetWindow(typeof(CompilerHook)).Show();
			}
			[NonSerialized] private bool WasCompiling;
			void Update() {
				bool isCompiling = EditorApplication.isCompiling;
				if (isCompiling && !WasCompiling) {
					GC.Collect();
					Debug.Log("Hitting GC");
				}
				WasCompiling = isCompiling;
			}

			void OnGUI() {
				GUILayout.Label("Keep me open to force GC on Tasks when recompiling.");
			}
		}


		/// <summary>
		/// Gets the paused state of the editor.
		/// Used because many things can't be accessed from the main thread.
		/// </summary>
		public static bool EditorPaused { get; private set; }
#endif
		/// <summary> 
		/// Gets the running state of the player. 
		/// Used because <see cref="Application.isPlaying"/> is not accessable from outside the main thread. 
		/// </summary>
		public static bool UnityRunning { get; private set; }
		/// <summary> Gets the pause state of the player. 
		/// Used because <see cref="Application.isPlaying"/> is not accessable from outside the main thread, 
		/// and Tasks can't recieve OnApplicationFocus() and OnApplicationPause().
		/// </summary>
		/// <remarks>
		/// This can be used to safeguard running <see cref="Task"/>s so they close if Unity is not running.
		/// </remarks>
		public static bool UnityPaused { get; private set; }
		/// <summary> Gets the focused state of the player. 
		/// Used because <see cref="Application.isPlaying"/> is not accessable from outside the main thread, 
		/// and Tasks can't recieve OnApplicationFocus() and OnApplicationPause().
		/// </summary>
		public static bool UnityFocused { get; private set; }

		/// <summary> Returns an object representing the current running state of unity. </summary>
		public static UnityState UnityState {
			get {
				UnityState state = UnityRunning ? UnityState.Running : UnityState.Empty;
				state |= UnityFocused ? UnityState.Focused : UnityState.Empty;
				state |= UnityPaused ? UnityState.Paused : UnityState.Empty;

				return state;
			}

		}

		/// <summary> Little hack to run code without an explicit static initializer and the overhead it produces. </summary>
		public static bool ready = Load();

		/// <summary> Does some stuff to get the TPL ready to report unhandled exceptions, and other misc. stuff. </summary>
		/// <returns> true </returns>
		public static bool Load() {
			TaskScheduler.UnobservedTaskException += (sender, e) => {
				LogWarning("\\rTaskScheduler: Unobserved exception:", e.Exception);
			};

			return true;
		}

		/// <summary> 
		/// Identity of this program. 
		/// All servers/clients on the program will share this identity. 
		/// This is used to make sure that once a disconnected client reconnects, its identity can be maintained.
		/// </summary>
		/// <remarks>
		/// This is of course, completely optional.
		/// If you want to, you could write a module to handle identities separately.
		/// This is provided simply as a convienience to identify a single program over its lifetime.
		/// </remarks>
		public static Guid identity {
			get { return main.Identity; }
		}
		/// <summary> Local reference to see in inspector. </summary>
		private Guid Identity;
		public string ID_String { get; private set; }

		/// <summary> Singleton Reference. </summary>
		public static Daemon main;
		/// <summary> Static reference to Singleton's LogLevel field </summary>
		public static LogLevel logLevel { get { return main != null ? main.LogLevel : LogLevel.Verbose; } }

		/// <summary> Current assigned LogLevel. </summary>
		public LogLevel LogLevel = LogLevel.Normal;

		/// <summary> Log EditorPause </summary>
		public bool LogAppMessages = true;


		/// <summary> Collection of delegates to execute on the "main" thread (Unity context) </summary>
		private ConcurrentQueue<Action> toInvoke = new ConcurrentQueue<Action>();


		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float time;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float deltaTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float unscaledTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float unscaledDeltaTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float fixedTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float fixedDeltaTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float fixedUnscaledTime;
		/// <summary> Last sampled value from <see cref="Time"/> </summary>
		public static float fixedUnscaledDeltaTime;

		/// <summary> Time between GC collections (seconds) </summary>
		public float gcTime = 300;




		/// <summary> Enqueues a delegate to be invoked on the "main" thread (Unity context) </summary>
		/// <param name="act"> Action delegate to invoke on the main thread. </param>
		public static void RunOnMainThread(Action act) {
			main.toInvoke.Enqueue(act);
		}

		/// <summary> Creates a task that ensures that an Action runs on the Main Unity Thread. </summary>
		/// <param name="act"> Callback to run on main thread </param>
		/// <param name="delayTime"> Time to wait between checking if that action has finished </param>
		/// <returns> Task object that is awaiting the completion of that action </returns>
		public static async Task<bool> RunOnMainThreadAsync(Action act, int delayTime = 25) {
			int state = -1;
			RunOnMainThread(() => {
				try {
					act();
					state = 0;
				} catch (Exception e) {
					LogWarning("RunOnMainThreadAsync: Action failed to complete " + e.GetType(), e);
					state = 1;
				}

			});

			while (state == -1) {
				if (!UnityRunning) { return false; }
				await Task.Delay(delayTime);
			}
			
			return state == 0;
		}


		void Awake() { 
			if (main != null) { 
				Destroy(gameObject); 
				return; 
			} 
			
			/// Start government services for <see cref="Loader.Load"/>s
			Loader.Start();

			toInvoke = new ConcurrentQueue<Action>();

			Application.runInBackground = true;

			//Hotloading.Start();
			string paths = "DirPath: " + Directory.GetCurrentDirectory().ForwardSlashPath()
				+ "\nDataPath:" + Application.dataPath 
				+ "\nPersistentDataPath: " + Application.persistentDataPath;
			Debug.Log(paths);
			Identity = Guid.NewGuid();
			ID_String = Identity.ToString();

			main = this; 
			UnityRunning = true; 

			Log("\\glogLevel set to " + logLevel, LogLevel.Minimal);

			Application.wantsToQuit += () => {
				UnityRunning = false;
				if (allowQuitting) {

					if (LogAppMessages) {
						Debug.Log("ApplicationQuit");
					}
					return true;
				} else {
					//Application.CancelQuit();

					StartCoroutine("DelayedQuit");
					return false;
				}
			};
		}

		float gcTimeout = 0;
		void Update() {
			time = Time.time;
			deltaTime = Time.deltaTime;
			unscaledTime = Time.unscaledTime;
			unscaledDeltaTime = Time.unscaledDeltaTime;

			gcTimeout += deltaTime;
			if (gcTimeout > gcTime) {
				gcTimeout -= gcTime;
				GC.Collect();
			}
			while (!toInvoke.IsEmpty) {
				Action act;
				if (toInvoke.TryDequeue(out act)) {
					try {
						act();
					} catch (Exception e) {
						LogWarning("\\rException occurred in delegate on main thread. " + e.GetType(), e);
					}

				}
			}

		}

		void FixedUpdate() {
			fixedTime = Time.fixedTime;
			fixedDeltaTime = Time.fixedDeltaTime;
			fixedUnscaledTime = Time.fixedUnscaledTime;
			fixedUnscaledDeltaTime = Time.fixedUnscaledDeltaTime;
		}

		private void OnApplicationFocus(bool focus) {
			if (LogAppMessages) { 
				Debug.Log("ApplicationFocus " + focus); 
			}
			UnityFocused = focus; 
		}

		private void OnApplicationPause(bool pause) {
			if (LogAppMessages) { 
				Debug.Log("ApplicationPause " + pause); 
			}
			#if UNITY_EDITOR
			UnityPaused = pause || EditorPaused;
			#else
			UnityPaused = pause; 
			#endif
		}
		
		private void OnApplicationQuit() { 
			UnityRunning = false; 
			/*
			if (allowQuitting) {

				if (LogAppMessages) {
					Debug.Log("ApplicationQuit"); 
				}
			
			} else {
				Application.CancelQuit();
				
				StartCoroutine("DelayedQuit");
			}
			//*/
			
		}

		bool allowQuitting = 
		#if UNITY_EDITOR
			true;
		#else 
			false;
		#endif
		IEnumerator DelayedQuit() {
			// Todo: Replace this with a loop that waits for a list of tasks to finish.
			yield return new WaitForSeconds(1);

			System.Diagnostics.Process.GetCurrentProcess().Kill();
		}

		public static Color callerColor = new Color(.25f, .25f, .25f);
		private static Color _CachedColor = Color.black;
		private static string _CachedString = "<color=#000000>";
		public static string colorString { 
			get {
				if (callerColor != _CachedColor) {
					_CachedString = "<color=#" + callerColor.HexString() + ">";
					_CachedColor = callerColor;
				}
				return _CachedString;
			}
		}
		public static string endColorString = "</color>";
		
		/// <summary> Debug.Logs a message, always. </summary>
		/// <param name="obj"> Message to Log</param>
		[MethodImpl(MethodImplOptions.AggressiveInlining)] // Gotta go fast. 
		public static void Print(object obj, string tag = "Baka",
				[CallerMemberName] string callerName = "[NO METHOD]",
				[CallerFilePath] string callerPath = "[NO PATH]",
				[CallerLineNumber] int callerLine = -1) {
			string callerInfo = CallerInfo(callerName, callerPath, callerLine);
			if (obj == null) {obj = "[null]";}
			string message = callerInfo + obj.ToString().ReplaceMarkdown();
			Debug.unityLogger.Log(tag, message);
			//Debug.Log(message);
		}
		
		/// <summary> Logs a message, respecting the LogLevel that has been set. </summary>
		/// <param name="obj"> Message to log. </param>
		/// <param name="minimum"> Minimum level for message to be logged. </param>
		[MethodImpl(MethodImplOptions.AggressiveInlining)] // Gotta go fast. 
		public static void Log(object obj, LogLevel minimum, string tag = "Baka",
				[CallerMemberName] string callerName = "[NO METHOD]",
				[CallerFilePath] string callerPath = "[NO PATH]",
				[CallerLineNumber] int callerLine = -1) {

			if (logLevel >= minimum) {
				if (obj == null) { obj = "[null]"; }
				string callerInfo = CallerInfo(callerName, callerPath, callerLine);
				string message = callerInfo + obj.ToString().ReplaceMarkdown();
				Debug.unityLogger.Log(tag, message); 
				//Debug.Log(message);
			}
		}

		/// <summary> Logs a message, as a warning. </summary>
		/// <param name="obj"> Message to log. </param>
		[MethodImpl(MethodImplOptions.AggressiveInlining)] // Gotta go fast. 
		public static void LogWarning(object obj, string tag = "Baka",
				[CallerMemberName] string callerName = "[NO METHOD]",
				[CallerFilePath] string callerPath = "[NO PATH]",
				[CallerLineNumber] int callerLine = -1) {
			if (obj == null) { obj = "[null]"; }
			string callerInfo = CallerInfo(callerName, callerPath, callerLine);
			string message = callerInfo + obj.ToString().ReplaceMarkdown();
			Debug.unityLogger.LogWarning(tag, message);
			//Debug.LogWarning(message);
		}

		/// <summary> Logs a message, as a warning, with an exception's information. </summary>
		/// <param name="obj"> Message to log. </param>
		/// <param name="e"> Exception to grab the <see cref="ExceptionUtils.InfoString"/> from.</param>
		[MethodImpl(MethodImplOptions.AggressiveInlining)] // Gotta go fast. 
		public static void LogWarning(object obj, Exception e, string tag = "Baka",
				[CallerMemberName] string callerName = "[NO METHOD]",
				[CallerFilePath] string callerPath = "[NO PATH]",
				[CallerLineNumber] int callerLine = -1) {
			if (obj == null) { obj = "[null]"; }
			string callerInfo = CallerInfo(callerName, callerPath, callerLine);
			string message = callerInfo + obj.ToString().ReplaceMarkdown() + "\n" + e.InfoString();
			Debug.unityLogger.LogWarning(tag, message);
			//Debug.LogWarning(message);
		}
		/// <summary> Little helper method to consistantly format caller information </summary>
		/// <param name="callerName"> Name of method </param>
		/// <param name="callerPath"> Path of file method is contained in </param>
		/// <param name="callerLine"> Line in file where log is called. </param>
		/// <returns></returns>
		[MethodImpl(MethodImplOptions.AggressiveInlining)] // Gotta go fast. 
		public static string CallerInfo(string callerName, string callerPath, int callerLine) {
			return "[" + DateTime.UtcNow.UnixTimestamp() + "]: " + colorString + ("Assets" + callerPath.FromLast("Assets"))+ " at " + callerLine + " in " + callerName + "()" + endColorString + "\n";
		}

	}
	
	/// <summary> Enum of log levels. </summary>
	public enum LogLevel {
		/// <summary> Disables all logging from the BakaNet library, minus exceptions. </summary>
		Minimal = 0,
		/// <summary> Logs only important information, such as when servers/clients start and stop. </summary>
		Lower = 1,
		/// <summary> Logs most information, such as when tasks start and stop.  </summary>
		Normal = 2,
		/// <summary> Logs more information, such as network messages </summary>
		Verbose = 3,
		/// <summary> Logs ALL information, including heartbeats. </summary>
		Maximal = 4,
	}

	/// <summary>
	/// Enum of all states of the UnityEngine.
	/// Represents flags, meaning multiple states can be true at the same time (eg, Running, Paused, and Focused.)
	/// </summary>
	[Flags] public enum UnityState : int {
		/// <summary> Value when Unity is not running, paused or focused. </summary>
		Empty = 0,
		/// <summary> Position set true when BakaNet.UnityRunning is true. </summary>
		Running = 1,
		/// <summary> Position set true when BakaNet.UnityFocused is true. </summary>
		Focused = 2,
		/// <summary> Position set true when BakaNet.UnityPaused is true. </summary>
		Paused = 4,
	}

}
