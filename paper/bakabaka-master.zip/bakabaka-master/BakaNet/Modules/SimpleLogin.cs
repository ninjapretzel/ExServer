using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaDB;
using System.Collections.Concurrent;
using LevelUpper.Extensions;
using BakaBaka;
using System.IO;

namespace BakaNet.Modules {
	/// <summary> 
	///		<para> Base login module. </para>
	///		<para> Provides some very light required implementation for login systems, as well as a common set of abstract RPC methods. </para>
	///		<para> The intent is that more secure login authentication can be swapped in or out as needed. </para>
	///		<para> 
	///			Dev servers can use the SimpleLogin module, and a prod server can use a more secure implementation, 
	///			for example, maybe some basic RSA or something, by handling ascii-armored encrypted binary payloads. 
	///		</para>
	/// </summary>
	public abstract class LoginModule : Module {

		/// <summary> Represents information about a user. </summary>
		public class Credentials {
			/// <summary> Name of user </summary>
			public string username { get; private set; }
			/// <summary> Password hash </summary>
			public string passhash { get; private set; }
			/// <summary> Session token </summary>
			public Guid token { get; private set; }
			/// <summary> Timestamp of creation </summary>
			public DateTime created { get; private set; }

			/// <summary> Used to create a credentials object on the client. </summary>
			/// <param name="user"> Username </param>
			/// <param name="tokenString"> Guid session token as a string </param>
			public Credentials(string user, string tokenString) {
				username = user;
				passhash = "local";
				Guid tok;
				Guid.TryParse(tokenString, out tok);
				token = tok;
				created = DateTime.UtcNow;
			}

			/// <summary> Used to create a credentials object on the server, after authenticating the user. </summary>
			/// <param name="user"> Username </param>
			/// <param name="hash"> Password hash </param>
			public Credentials(string user, string hash, Guid token) {
				username = user;
				passhash = hash;
				this.token = token;
				created = DateTime.UtcNow;
			}

		}

		/// <summary> Reference to login information that a local client can use. Hash of this is always "local" if it exists.</summary>
		public Credentials localLogin = null;

		/// <summary> Is the local Client logged in? </summary>
		public bool LoggedIn { get { return localLogin != null; } }
	
		/// <summary> Message about login state. </summary>
		public string message = "";

		/// <summary> Username that was last used to attempt a login. </summary>
		public string loginAttempt { get; protected set; }

		/// <summary> Hashes a password. Implementation should be more secure. </summary>
		/// <param name="pass"> Input password to hash </param>
		/// <returns> Hashed password. </returns>
		public abstract string Hash(string pass);

		#if UNITY_EDITOR
		/// <summary> RPC, Client->Server. Client requests a login from the server. Implementation should respond with a LoginResponse RPC call. </summary>
		/// <param name="msg"> RPC Message info </param>
		public abstract void Login(RPCMessage msg);

		/// <summary> RPC, Client->Server. Client requests to be reauthenticated after disconnect. Implementation should respond with a ReauthResponse RPC call. </summary>
		/// <param name="msg"> RPC Message info </param>
		public abstract void Reauth(RPCMessage msg);
		#endif

		/// <summary> RPC, Server->Client. Server responds to client with success/fail state of login, and any associated information. </summary>
		/// <param name="msg"> RPC Message info </param>
		public abstract void LoginResponse(RPCMessage msg);

		/// <summary> RPC, Server->Client. Server responds to client with success/fail state of reauth. Implementations may drop sessions at any time. </summary>
		/// <param name="msg"> RPC Message info </param>
		public abstract void ReauthResponse(RPCMessage msg);
	
		/// <summary> Get the credentials associated with a client, or null if they were not logged in. </summary>
		/// <param name="client"> Client to get info for </param>
		/// <returns> Credentials associated with client, or null if not logged in. </returns>
		public abstract Credentials GetInfo(Client client);

		/// <summary> Callback chain to run when a login is successful. </summary>
		public Action onLoginSuccess;

		/// <summary> Callback chain to run when a loggin is unsuccessful. </summary>
		public Action onLoginFailure;

		/// <summary> Callback chain to run on server when a login is successful. </summary>
		public Action<Client> onLoginSuccessServer;

		/// <summary> Callback chain to run on server when a login is successful. </summary>
		public Action<Client> onLoginFailureServer;
	
		/// <summary> Callback chain to run when a reauthentication is successful. </summary>
		public Action onReauthSuccess;
	
		/// <summary> Callback chain to run when a reauthentication is unsuccessful. </summary>
		public Action onReauthFailure;

		/// <summary> Callback chain to run on server when a reauthentication is successful. </summary>
		public Action<Client> onReauthSuccessServer;

		/// <summary> Callback chain to run on server when a reauthentication is successful. </summary>
		public Action<Client> onReauthFailureServer;

		/// <summary> Version associated with the login endpoint (client or server) </summary>
		public string versionCode = null;

		/// <summary> Called on the client to send a login request to the connected server. </summary>
		/// <param name="user"> Username to login with </param>
		/// <param name="password"> Password to hash and login with </param>
		public void TryLogin(string user, string password = "defaultPasswordAndYouAreAMoron") {
		
			if (!IsValidUsername(user)) { return; }
			if (!IsValidPassword(password)) { return; }

			if (loginAttempt == null) {
				loginAttempt = user;
				if (versionCode == null) {
					versionCode = "[[client version not set]]";
				}
				if (localLogin == null) {
					localClient?.Send("Login", user, Hash(password), versionCode);
				} else {
					localClient?.Send("Reauth", localLogin.token, versionCode);
				}

			} else {
				Daemon.Print("\\rAlready attempting a login, you BAKA");
			}

		}


		/// <summary> Simple quick check for valid usernames. </summary>
		/// <param name="user"> Name to check </param>
		/// <returns> True if name is between 4 and 64 characters long, and contains only [a-zA-Z_0-9] characters, and does not start with [0-9] </returns>
		public virtual bool IsValidUsername(string user) {
			if (user == null) { return false; }
			if (user.Length < 4 || user.Length > 64) { return false; }

			for (int i = 0; i < user.Length; i++) {
				char c = user[i];
				if (c > 'z') { return false; } // No characters past 'z' allowed, narrows down valid usernames quick.
				if (c >= 'a') { continue; } // Accept a-z
				if (c > 'Z') { return false; } // Next range is A-Z, reject characters between 'Z' and 'a'.
				if (c >= 'A') { continue; }
				if (c == '_') { continue; }

				// must start with [a-zA-Z_]
				if (i > 0 && c >= '0' && c <= '9') { continue; }

				// Reject any other characters
				return false;
			}

			// If we've passed the whole string without rejecting, it's good.
			return true;
		}

		/// <summary> Simple check for valid passwords. </summary>
		/// <param name="pass"> password to check </param>
		/// <returns> True, if password is at least 8 characters. That's all we care about for simplicity's sake. </returns>
		public virtual bool IsValidPassword(string pass) {
			if (pass.Length < 4) { return false; }

			return true;
		}
	
	}

	/// <summary> Simple, pretty insecure login. </summary>
	public class SimpleLogin : LoginModule {

		/// <summary> User database reference </summary>
		LocalDB users;

		/// <summary> Active logins. </summary>
		ConcurrentDictionary<Client, Credentials> logins;

		/// <summary> Recently active logins, clients that have recently disconnected. </summary>
		ConcurrentDictionary<Guid, Credentials> limbo;

		/// <summary> Users and the clients they are related to. </summary>
		ConcurrentDictionary<string, Client> userLogins;

		
		public SimpleLogin() {
			versionCode = "nope";
		}

		public SimpleLogin(string versionCode) {
			this.versionCode = versionCode;
		}

		public string Nickname(Client c) {
			if (logins.ContainsKey(c)) {
				return logins[c].username;
			}
			return "Guest " + c.GetHashCode();
		}

		#if UNITY_EDITOR

		/// <summary> Permissions granted to given users. </summary>
		private JsonObject permissions;

		/// <summary> AUTHZ a client for an action. </summary>
		/// <param name="c"></param>
		/// <param name="action"></param>
		/// <returns></returns>
		public bool AUTHZ(Client c, string action) {
			string role = "guest";

			if (logins.ContainsKey(c)) {
				var creds = logins[c];
				role = "user";
				JsonValue record;
				if (users.Check(creds.username, out record) && record.ContainsKey("role")) {
					role = record["role"].stringVal;
				}
			}
			
			if (!permissions.ContainsKey(role)) {
				Daemon.Log("\\eUNAUTHORIZED: client " + c.identity + " no role [" + role + "] defined.", LogLevel.Lower);
				return false; 
			}

			var perms = permissions[role];
			if (perms.ContainsKey("all")) { return true; }

			if (!perms.ContainsKey(action)) {
				Daemon.Log("\\eUNAUTHORIZED: client " + c.identity + " is role [" + role + "]. Cannot [" + action + "]", LogLevel.Lower);
				return false;
			}
			return true;
		}

		private void LoadPermissions() {
			if (File.Exists("config/permissions.json")) {
				permissions = Json.Parse<JsonObject>(File.ReadAllText("config/permissions.json"));
			} else {
				permissions = new JsonObject();
				permissions["guest"] = new JsonObject();
				permissions["user"] = new JsonObject("move",true);
				permissions["admin"] = new JsonObject("all", true);
			}

			Daemon.Log("Loaded Permissions: " + permissions.ToString(), LogLevel.Verbose);
		}
#else
		/// <summary> HAHAHAHA </summary>
		public bool AUTHZ(Client c, string action) { return true; }
#endif

		public override void OnServerAwake(Server s) {
			#if UNITY_EDITOR
			LoadPermissions();
			#endif
			// Server-side initialization
			users = DB.Local("users", false);
			logins = new ConcurrentDictionary<Client, Credentials>();
			limbo = new ConcurrentDictionary<Guid, Credentials>();
			userLogins = new ConcurrentDictionary<string, Client>();

		}

		public override Credentials GetInfo(Client client) {
			if (logins.ContainsKey(client)) { return logins[client]; }
			return null;
		}

		//public override Client GetInfo(Guid guid) { }


		public override void OnClientAwake(Client c) {

			if (c.isLocal) {
				// Local-Client initialization

			}
			// Common Client initialization

		}

		public override void OnConnected(Client c) {

			if (c.isLocal) {
				// Client-side connection handling
				if (localLogin != null) {
					TryLogin(localLogin.username);

				}
			
			} else {
				// Server-side connection handling 

			}

		}

		float userCountTime = 5;
		float timeout = 0;
		int userCount = 0;
		public override void Update() {
		
			timeout += delta;
			if (timeout >= userCountTime) {
				timeout -= userCountTime;
				userCount = logins.Count;
			}

		}

		public override void OnDisconnected(Client c) {

			if (c.isLocal) {
				// Client side disconnection cleanup

			} else {
				// Server side disconnection cleanup 
				Credentials creds;
				Client __;
			
				if (logins.TryRemove(c, out creds)) {
					userLogins.TryRemove(creds.username, out __);

					limbo[creds.token] = creds;
					Daemon.Print("Server limbo'd " + creds.username + " " + creds.token);
				}

			}

		}

		public static string StupidHash(string pass) {
			return ":\\:" + (pass + "IM A STUPID HACKER DECOMPILING YOUR CODE LOL").GetHashCode() + ":/:";
		}

		/// <inheritdoc />
		public override string Hash(string pass) {
			return StupidHash(pass);
		}

		#if UNITY_EDITOR 
		string _VERSION_MISMATCH = null;
		string VERSION_MISMATCH {
			get {
				if (_VERSION_MISMATCH != null) { return _VERSION_MISMATCH; }
				return (_VERSION_MISMATCH = "Version Mismatch\nPlease update to " + versionCode);
			}
		}

		/// <summary> RPC, Client->Server, asks server to validate login information. </summary>
		/// <param name="msg"> RPC Message Info </param>
		public override void Login(RPCMessage msg) {
			string user = msg[0];
			string hash = msg[1];
			string version = msg.numArgs >= 3 ? msg[2] : "[[server version not set]]";

			Guid token = Guid.NewGuid();

			JsonValue record = null; 
			Credentials creds = null;
			string reason = "none";
			string file = user + ".wtf";

			if (version != versionCode) {

				// Invalid usernames mean login fails automatically. 
				reason = VERSION_MISMATCH;

			} else if (!IsValidUsername(user)) {

				// Invalid usernames mean login fails automatically on client...
				// but just in case...
				reason = "Invalid username";

			} else if (userLogins.ContainsKey(user)) {

				reason = "Already logged in.";
				// Login failed, already exists.
				// TBD: Kick off existing user?
				// reason = "Already logged in, but not anymore.";
			
			} else if (users.Check(file, out record)) {
				// User exists, check the passhash
			
				string checkHash = record["hash"].stringVal;
				if (hash != checkHash) {
					// Login fails
					reason = "Bad credentials.";
				} else {
					creds = new Credentials(user, hash, token);
				}

			} else {
				// User doesn't exist yet... Create them
				record = users.Open(file);
				record["hash"] = hash;
				creds = new Credentials(user, hash, token);
			
			}
			
			if (creds == null) {
				msg.client.Send("LoginResponse", "fail", reason);
				onLoginFailureServer?.Invoke(msg.client);

			} else {
				logins[msg.client] = creds;
				userLogins[user] = msg.client;

				record["lastLogin"] = "" + DateTime.UtcNow.UnixTimestamp();
			
				users.Save(file, record);

				msg.client.Send("LoginResponse", "succ", token);

				onLoginSuccessServer?.Invoke(msg.client);
			}

		}
		/// <summary> RPC, Client->Server, asks the server to revalidate the session </summary>
		/// <param name="msg"> RPC Message Info </param>
		public override void Reauth(RPCMessage msg) {
			Guid token = Guid.Empty;
			string result = "fail";
			string reason = "liar";
			if (Guid.TryParse(msg[0], out token) && limbo.ContainsKey(token)) {
				Credentials creds;

				// TBD: maybe store in the credentials the endpoint of the client
				// And check that endpoint is the same?
				// Maybe some other form of ID info as well?
				if (limbo.TryRemove(token, out creds)) {
					logins[msg.client] = creds;
					result = "succ";	
				}

			}
		
			if (result == "fail") {
				Daemon.Print("Server failed to reauth: " + token + " for " + reason);
				onLoginFailureServer?.Invoke(msg.client);
			} else {
				Daemon.Print("Server reauth'd: " + token + " on " + msg.client.identity);
				onLoginSuccessServer?.Invoke(msg.client);
			}
		
			msg.client.Send("ReauthResponse", result, reason);

		}
#endif
		/// <summary> RPC, Server->Client, response to login success/failure </summary>
		/// <param name="msg"> RPC Message Info </param>
		public override void LoginResponse(RPCMessage msg) {
			string result = msg[0];

			if (result == "fail") {
				Daemon.Print("Login faiel'd!!!");
				result = msg[1];
				Daemon.RunOnMainThread( () => { onLoginFailure?.Invoke(); } );

			} else if (result == "succ") {
				Daemon.Print("Login SUCC'd???");
				localLogin = new Credentials(loginAttempt, msg[1]);
				Daemon.RunOnMainThread( () => { onLoginSuccess?.Invoke(); } );

			}

			loginAttempt = null;
			message = result;

		}


		/// <summary> RPC, Server->Client, response to reauth success/failure </summary>
		/// <param name="msg"> RPC Message Info </param>
		public override void ReauthResponse(RPCMessage msg) {
			string result = msg[0];

			if (result == "fail") {
				Daemon.Print("Reauth faiel'd!!!");
				result = msg[1];
				localLogin = null;
				Daemon.RunOnMainThread( () => { onReauthFailure?.Invoke(); } );
			} else if (result == "succ") {
				Daemon.Print("Login SUCC'd???");
				//localLogin can remain the same.
				Daemon.RunOnMainThread( () => { onReauthSuccess?.Invoke(); } );
			}

			loginAttempt = null;
			message = result;

		}

		Vector2 scroll;
		/// <inheritdoc />
		public override void DrawIMGUI(Rect area) {
			Rect brush = area;
			brush.height = 20;

			if (localClient != null) {
				string user = "[Not Logged In]";

				if (localLogin != null) { user = localLogin.username; }
				GUI.Label(brush, "Local Client Login: " + user);
				brush.y += brush.height;
			
			}

			if (IsServer) {
				GUI.Label(brush, "----Server Logins");
				brush.y += brush.height;

				brush.height = area.height - brush.y;

				StringBuilder str = "User Logins:";
				if (userCount == 0) { str += "\nNo Logins? (may be dirty)"; }

				foreach (var pair in logins) {
					str = str + "\nUser: " + pair.Value.username + " --- " + pair.Key.identity;
				}

				Rect view = brush;
				GUIContent content = new GUIContent(str.ToString());
				Vector2 size = GUI.skin.label.CalcSize(content);
				view.width = Mathf.Max(view.width - 32, size.x);
				view.height = Mathf.Max(view.height, size.y);
			
				scroll = GUI.BeginScrollView(brush, scroll, view, false, true); {
					GUI.Label(view, content);
				} GUI.EndScrollView();

			}


		}

	}

}
