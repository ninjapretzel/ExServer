using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

public static class JsonGet {

	/*//
	 
	// Experimental optimization stuff...
	///////
	// Remarks
	///////
	// Still slower than the below GetV3 method. 
	// For places where optimization matters, direct methods liek GetV3 is the way to go
	// This had slightly better performance than adding generators for JsonReflector
	// That is a better, more general boost to performance
	// But these performance boosts really only need to be applied where they become bottlenecks...
	// Rather than applied everywhere...

	public static Dictionary<Type, Func<JsonValue, object>> generators = BuildGenerators();
	public static Dictionary<Type, Func<JsonValue, object>> BuildGenerators() {
		var gens = new Dictionary<Type, Func<JsonValue, object>>();
		gens[typeof(Vector3)] = QGetV3;
		return gens;
	}

	public static T QGet<T>(this JsonValue val, string key) {
		if (val != null && val.isObject) {
			var type = typeof(T);
			if (generators.ContainsKey(type)) {

				object outVal = generators[type](val[key]);
				if (type.IsAssignableFrom(outVal.GetType())) { return (T)outVal; }
			}

		}
		return (default(T));
	}
	private static object QGetV3(this JsonValue val) {
		if (val is JsonObject) {
			float x = val["x"].floatVal;
			float y = val["y"].floatVal;
			float z = val["z"].floatVal;
			return new Vector3(x,y,z);
		}
		return Vector3.zero;
	}
	//*/

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static long GetLong(this JsonObject obj, string key) {
		string data = obj[key].stringVal;
		long val;
		if (long.TryParse(data, out val)) { return val; }
		return 0;
	}


	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static Vector3 GetV3(this JsonObject obj, string key) {
		if (obj == null) { return Vector3.zero; }
		JsonObject obj2 = obj[key] as JsonObject;
		if (obj2 != null) { return ToV3(obj2); }
		return Vector3.zero;
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static Quaternion GetQ(this JsonObject obj, string key) {
		if (obj == null) { return Quaternion.identity; }
		JsonObject obj2 = obj[key] as JsonObject;
		if (obj2 != null) { return ToQuaternion(obj2); }
		return Quaternion.identity;
	}


	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static Quaternion ToQuaternion(this JsonObject obj) {
		float x = obj["x"].floatVal;
		float y = obj["y"].floatVal;
		float z = obj["z"].floatVal;
		float w = obj["w"].floatVal;
		return new Quaternion(x,y,z,w);
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static Vector3 ToV3(this JsonObject obj) {
		float x = obj["x"].floatVal;
		float y = obj["y"].floatVal;
		float z = obj["z"].floatVal;
		return new Vector3(x, y, z);
	}

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static JsonObject ToJson(this Vector3 v) { return new JsonObject("x", v.x, "y", v.y, "z", v.z); }

	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public static JsonObject ToJson(this Quaternion q) { return new JsonObject("x", q.x, "y", q.y, "z", q.z, "w", q.w); }

}
