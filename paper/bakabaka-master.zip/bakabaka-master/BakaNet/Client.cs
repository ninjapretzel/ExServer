using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.Threading;
using BakaNet.Utils;
using System.IO;
using BakaBaka;
using BakaBaka.Utils;

namespace BakaNet {
	
	/// <summary> BakaNet Client class. </summary>
	public class Client {

		/// <summary> Class that maintains the connection of a client, so long as Unity remains open and running. </summary>
		public class Watcher {
			/// <summary> Remote host. </summary>
			public string host { get; private set; }
			/// <summary> Remote Port </summary>
			public int port { get; private set; }
			/// <summary> Modules to attach client to. </summary>
			public List<Module> modules { get; private set; }

			/// <summary> Client connection </summary>
			public Client client { get; private set; }

			public Watcher(string host, int port, List<Module> modules = null) {
				this.host = host;
				this.port = port;
				this.modules = modules;

				Task.Run(WatchClient);
			}

			/// <summary> Async loop that watches a client. </summary>
			/// <returns> Running Task </returns>
			private async Task WatchClient() {
				while (true) {
					try {
						if (!Daemon.UnityRunning) {
							Daemon.Log("\\iClient.Watcher: Unity has stopped.", LogLevel.Lower);
							if (client != null) { client.Close(); }
							break;
						}

						if (client == null) {
							client = new Client(host, port, modules);
						} else {
							if (client.CompletelyFinished) {
								Daemon.Log("\\iClient died. Delaying before restarting... [" + host + ":" + port + "]", LogLevel.Lower);
								await Task.Delay(6000);
								Daemon.Log("\\iClient.Watcher: Attempting to restart client for [" + host + ":" + port + "]", LogLevel.Lower);
								client = new Client(host, port, modules);
								
							}
						}
					} catch (Exception e) {
						Daemon.LogWarning("\\iClient.Watcher: Exception at top level of task:", e);
					}
					
				}
				
			}

		}
		/// <summary> Used to maintain client connections on client machines. </summary>
		/// <param name="host"> Remote host to maintain connection to. </param>
		/// <param name="port"> Remote port to connect to </param>
		/// <param name="modules"> Modules to attach to the client. </param>
		/// <returns> <see cref="Client.Watcher"/> object which maintains the connection so long as Unity remains running. </returns>
		public static Watcher Maintain(string host, int port, List<Module> modules = null) {
			return new Watcher(host, port, modules);
		}

		/// <summary>Separator character to separate segments of transmissions</summary>
		public const char SEP = (char)0x07; // 'Bell'
		/// <summary> End Of Transmission </summary>
		internal const char EOT = (char)0x1F; // 'Unit Separator'

		/// <summary> Byte array used to poke the client to check the connection. </summary>
		static readonly byte[] oneByte = { (byte)EOT };

		/// <summary> Task.Delay for sending. </summary>
		public static int sendDelay = 101;
		/// <summary> Task.Delay for recieving. </summary>
		public static int recieveDelay = 103;
		/// <summary> Delay between checking the connection (poking with EOT) during send. </summary>
		public static int checkConnectionDelay = 2000;
		/// <summary> Delay for handling sent messages. </summary>
		public static int handleDelay = 100;

		/// <summary> Get the wrapped TcpClient object.</summary>
		public TcpClient connection { get; private set; }
		// <summary> Lock object for reassigning the connection </summary>
		// private object connectionMutex;

		/// <summary>Get the stream used to communicate with the connected machine.</summary>
		NetworkStream stream { get { return connection.GetStream(); } }

		/// <summary> Task running for sending data. </summary>
		Task sendTask = null;
		/// <summary> Task running for recieving data. </summary>
		Task recTask = null;
		/// <summary> Task that a local client uses to respond to messages. </summary>
		Task handleTask = null;

		/// <summary> Has this connection been closed? Set to true upon disconnect. </summary>
		/// <remarks> Closed connections do not remain in Server.main.connections </remarks>
		bool closed = false;

		/// <summary> Checks that the client is alive and communicating with the server. </summary>
		/// <returns> True if the client is connected, and communication tasks are currently alive. </returns>
		public bool IsCommunicating {
			get { return connection != null && sendTask != null && recTask != null && !closed && sendTask.IsAlive() && recTask.IsAlive() && (!isLocal || handleTask.IsAlive()); }
		}
		/// <summary> Can be checked to make sure that a client has completely finished (abandoned all resources and all tasks are done) </summary>
		/// <returns> True if all tasks have finished, and all resources have been released </returns>
		public bool CompletelyFinished {
			get { return connection != null && sendTask != null && recTask != null && closed && !sendTask.IsAlive() && !recTask.IsAlive() && (!isLocal || !handleTask.IsAlive()); }
		}

		/// <summary> Is this client a Local or Server client? </summary>
		public bool isLocal { get; private set; }
		/// <summary> String describing the identity of the client. </summary>
		public string identity { get { return (isLocal ? "*[LocalClient]*" : ("*[Client#" + id + "]*")); } }

		/// <summary> User associated with this client, if any. </summary>
		public string user = null;

		/// <summary> Server associated with this client, if any. </summary>
		public Server server = null;

		/// <summary> Modules attached to this client, if any. </summary>
		public List<Module> modules = null;

		/// <summary>instance id for this client.</summary>
		public int id = -1;

		/// <summary> Outgoing messages </summary>
		internal ConcurrentQueue<string> outgoing = null;

		/// <summary> Incoming messages. Only local clients have this present. Server clients pass messages to their Server. </summary>
		internal ConcurrentQueue<RPCMessage> incoming = null;
		
		/// <summary> Common constructor. Doesn't actually create a valid Client, so is private. </summary>
		/// <remarks> Provides common construction logic for all constructors. </remarks>
		private Client() {
			// connectionMutex = new object();
			outgoing = new ConcurrentQueue<string>();
			//ed = new EncDec();
		}


		/// <summary> <see cref="Server "/> parameter constructor. Doesn't actually create a valid client, so is private. </summary>
		/// <param name="server"> Server that this client is a child of. </param>
		/// <remarks> Provides construction logic for remote clients on <see cref="Server"/>s. </remarks>
		private Client(Server server) : this() {
			this.server = server;
			id = Interlocked.Increment(ref server.nextID);
			// TBD: Fire OnCreated event inside of server's modules?
		}

		/// <summary> Creates a Local client. Attempts to connect on the given <paramref name="host"/> and <paramref name="port"/>. </summary>
		/// <param name="host"> Hostname to attempt to connect to. </param>
		/// <param name="port"> Port to attempt to connect on. </param>
		/// <remarks> Used to create a Client for a client machine who is connected to a server. </remarks>
		public Client(string host, int port, List<Module> modules = null) : this() {
			isLocal = true;
			// Only local clients deal with incoming messages.
			incoming = new ConcurrentQueue<RPCMessage>();

			this.modules = modules;
			if (this.modules == null) { this.modules = new List<Module>(); }
			foreach (var module in this.modules) {
				module.TriggerOnClientAwake(this);
			}

			// Don't need to lock inside the constructor.
			// Not available until after constructors complete.
			connection = new TcpClient(host, port);
			
			Communicate();
		}

		/// <summary> Creates a remote client </summary>
		/// <param name="tcpClient"> Remote connection, accepted by server. </param>
		/// <remarks> Used to create a Client for the server to handle a remote machine. </remarks>
		public Client(Server server, TcpClient tcpClient, List<Module> modules = null) : this(server) {
			this.modules = modules;
			if (this.modules == null) { this.modules = new List<Module>(); }
			foreach (var module in this.modules) {
				module.TriggerOnClientAwake(this);
			}

			isLocal = false;
			// Don't need to lock inside the constructor.
			// Not available until after constructors complete.
			connection = tcpClient;
			
			Communicate();
		}

		/// <summary> Begins communication with the other end of this object. </summary>
		private void Communicate() {
			if (connection != null) { 
				Daemon.Log("\\iClient " + identity + " Beginning communication.", LogLevel.Lower);
				sendTask = Task.Run(SendAsync);
				recTask = Task.Run(RecieveAsync);
				if (isLocal) {
					handleTask = Task.Run(HandleAsync);
					foreach (var module in modules) {
						module.TriggerOnConnected(this);
					}
				}
			}
		}
	
		/// <summary> Closes this client. </summary>
		public void Close() {

			if (!closed) {
				closed = true;
				if (!isLocal && server != null) {
					//server.clients.TryRemove(id);
					server.OnClosed(this);

				} else if (isLocal) {
					foreach (var module in modules) {
						module.TriggerOnDisconnected(this);
					}
				}
				try {
					connection.Close();
					
				} catch (Exception e) {
					// TBD: We could probably ignore ObjectDisposed exceptions. 
					// Multiple calls to Close() shouldn't be a problem but, 
					// Its possible the connection is already closed when the send/rec tasks call Close() on exit.
					Daemon.LogWarning("\\rClient.Close: encountered exception", e);
				}

				Daemon.Log("\\iClient " + identity + " Terminated.", LogLevel.Lower);
			}

		}

		/// <summary> Checks if Unity stopped, and if it did, closes the client. </summary>
		/// <returns> True if Unity stopped, false if it's still running. </returns>
		public bool DidUnityStop() {
			if (!Daemon.UnityRunning) {
				Daemon.Log("\\iClient " + identity + " Running after Unity closed. Terminating.", LogLevel.Lower);
				if (!closed) { ((Action)Close).TryInvoke(); }
				return true;
			}
			return false;
		}


		//public delegate byte[] Encryptor(byte[] data);
		private Func<byte[], byte[]> enc = null;
		private Func<byte[], byte[]> dec = null;
		private static readonly string testMessage = ("shut it down the goyim know too much" + EOT
				+ "Everything here is make believe, only a fool would take it seriously." + EOT
				+ "Don't worry, it's just fake news"+ EOT
				+ "SPIRIT COOKING" + EOT
				+ "SOME" + EOT + "VERY" + EOT + "SHORT" + EOT + "MESSAGES " + EOT + "HERE" + EOT
				+ "EVM" + EOT + "MORE" + EOT + "SHRT" + EOT + "MSGS" + EOT + "HRE " + EOT + "YEP" + EOT

				+ "its like annudah shoah" + EOT
				+ "SHUT IT DOWN THE GOYIM KNOW" + EOT
				+ "I'm running out of ideas, all I can do is type shitty /pol/ memes" + EOT
				+ "Don't you dare make negative memes about CNN" + EOT
			).Replace(' ', SEP);

		/// <summary>
		/// Attempts to set enc and dec to a pair of methods.
		/// Tests them agains some test data in a loop similar to how data is handled, 
		/// and makes sure that arbitrary cuts on the data doesn't break the encryption scheme.
		/// </summary>
		/// <param name="encrypt"> Function for encrypting the data </param>
		/// <param name="decrypt"> Function for decrypting the data </param>
		public void SetEncDec(Func<byte[], byte[]> encrypt, Func<byte[], byte[]> decrypt) {
			if (encrypt == null || decrypt == null) { 
				Daemon.LogWarning("\\rProper Encryption/Decryption functions must be provided to clients...");
				return;
			}

			try {
				byte[] oneEnc = encrypt(oneByte);
				byte[] oneDec = decrypt(oneEnc);

				if (oneDec.Length != 1 && oneDec[0] != oneByte[0]) { throw new Exception("catch me"); }
			} catch (Exception) {
				Daemon.LogWarning("!Encryption/decryption must properly handle tiny things as well! (One byte in size)");
				return;
			}

			List<byte[]> wew = new List<byte[]>();
			StringBuilder recieved = "";
			int stringpos = 0;
			SRNG rand = new SRNG();
			while (stringpos < testMessage.Length) {
				int next = stringpos + rand.NextInt(1, 42);
				if (next > testMessage.Length) { next = testMessage.Length; }

				int diff = next - stringpos;
				string cut = testMessage.Substring(stringpos, diff);
				stringpos = next;

				wew.Add(cut.ToBytesUTF8());
			}
			
			byte[][] multibytearraydrifting = wew.ToArray();
			StringBuilder held = "";
			string str;
			int pos = 0;
			foreach (var bytes in multibytearraydrifting) {
				byte[] message = encrypt(bytes);
				message = decrypt(message);
				str = message.GetStringUTF8();

				held += str;
				int index = held.IndexOf(EOT);
				while (index >= 0) {
					string pulled = held.Substring(0, index);
					held = held.Remove(0, index + 1);
					index = held.IndexOf(EOT);
					
					if (pulled.Length > 0) {
						recieved = recieved + pulled + EOT;
					}
				}
				pos++;
			}



			string fullRecieved = recieved.ToString();
			if (fullRecieved == testMessage) {
				enc = encrypt;
				dec = decrypt;
			} else {
				string s = "Client.SetEncDec: Attempted to set Encryption/Decryption methods, but they did not work properly."
					+ "\n\nExpected: " + testMessage + "\n\nRecieved: " + fullRecieved;
				Daemon.LogWarning(s);
				enc = null;
				dec = null;
			}

		}

		/// <summary> Sends an RPCMessage to the connected client </summary>
		/// <param name="stuff"> Everything to send. Method name first, parameters after. </param>
		/// <remarks> 
		///		ToString's all of the <paramref name="stuff"/>, and then joins it together with <see cref="SEP"/>.
		///		Enqueues the resulting string into <see cref="outgoing"/>. 
		///	</remarks>
		public void Send(params System.Object[] stuff) {
			//Debug.Log(identity + "Send Directly Called: " + stuff[0]);
			
			string msg = FormatMessage(stuff);
			Daemon.Log("Client " + identity + " Sending message " + msg.Replace(SEP, '|'), LogLevel.Maximal);

			// Concurrent queue. Don't have to lock() onto anything. wew.
			outgoing.Enqueue(msg);
		}

		/// <summary> Formats a message into a string intended to be sent over the network. </summary>
		/// <param name="stuff"> Array of parameters to format. </param>
		/// <returns> String of all objects in <paramref name="stuff"/> formatted to be sent over the network. </returns>
		public static string FormatMessage(params System.Object[] stuff) {
			string[] strs = new string[stuff.Length];
			for (int i = 0; i < strs.Length; i++) { strs[i] = stuff[i].ToString(); }
			string msg = String.Join("" + SEP, strs);
			return msg;
		}

		/// <summary> Enqueues a (hopefully, properly formatted) message directly into the outgoing queue. </summary>
		/// <param name="message"> Message to enqueue. </param>
		public void SendMessageDirectly(string message) {
			// Concurrent queue. Don't have to lock() onto anything. wew.
			outgoing.Enqueue(message);
		}

		/// <summary> Async Handle Loop </summary>
		/// <returns> Running task </returns>
		public async Task HandleAsync() {
			while (!closed) {
				if (!isLocal) { Daemon.LogWarning("\\r**Server client's shouldn't be handling messages, Baka!**"); return; }
				if (DidUnityStop()) { break; }

				while (incoming.Count > 0) {
					RPCMessage msg;
					if (incoming.TryDequeue(out msg)) {
						Daemon.Log("\\bClient handling " + msg.methodName, LogLevel.Maximal);
						//Daemon.Log("\\uClient.Handle: calling " + msg.methodName, LogLevel.Lower);
						bool called = false;
						foreach (var module in modules) {
							called |= module.SendRPCEvent(msg);
						}
						if (!called) {
							Daemon.LogWarning("\\rClient.Handle: Recieved request for unknown function \"" + msg.methodName + "\"");
						}

					}

					if (DidUnityStop()) { goto finished; }
				}


				await Task.Delay(handleDelay);
			}
			finished:
			Daemon.Log("\\bClient.HandleAsync: Exiting " + identity, LogLevel.Normal);
		}

		/// <summary> Async Send Loop </summary>
		/// <returns> Running task </returns>
		public async Task SendAsync() {
			//BakaNet.Log("\\bClient.SendAsync: Entering " + identity, LogLevel.Normal);
			DateTime lastPoke = DateTime.UtcNow;

			while (!closed) {
				if (DidUnityStop()) { break; }
				if (enc == null || dec == null) {
					Daemon.LogWarning("\\rNo Encryption/Decryption methods set on " + identity + "!");
					await Task.Delay(500);
					continue; 
				}
				DateTime now = DateTime.UtcNow;
				string msg = null;
				
				/* // Can't make use of this afaik...
				// Poke() // Cannot be it's own function, needs direct loop control
				{
					if ((now-lastPoke).TotalMilliseconds > checkConnectionDelay) {
						lastPoke = now;
						try {
							
							Daemon.Log("\\hClient.SendAsync: Poking " + (isLocal ? "To Server" : "To Client" + identity)
								+ " with 1 byte", LogLevel.Maximal);
							
							var blockMode = connection.Client.Blocking;
							connection.Client.Blocking = false;
							connection.Client.Send(enc(oneByte));
							connection.Client.Blocking = blockMode;
							

						} catch (IOException e) {
							Daemon.Log("\\hClient.SendAsync: User " + identity + " probably timed out.\\k" + e.GetType(), LogLevel.Maximal);
							Daemon.Log("\\hClient.SendAsync: Exiting " + identity + " from Poke", LogLevel.Maximal);
							Close();
							break;
						} catch (SocketException e) {
							if (e.NativeErrorCode.Equals(10035)) {
								// Can ignore this socket exception: WSAEWOULDBLOCK (10035)
								
								// From microsofts docs:
								// This error is returned from operations on nonblocking sockets that cannot be completed immediately, 
								//		for example recv when no data is queued to be read from the socket. 
								// It is a nonfatal error, and the operation should be retried later. 
								// It is normal for WSAEWOULDBLOCK to be reported as the result from calling connect on a nonblocking SOCK_STREAM socket,
								//		since some time must elapse for the connection to be established.
								//

								// Meaning this exception says that the underlying socket is still 'connected' 
							} else {
								Daemon.Log("\\hClient.SendAsync: " + identity + " probably disconnected. " + e.GetType(), LogLevel.Maximal);
								Close();
								break;
							}
						} catch (Exception e) {
							Daemon.LogWarning("\\rClient.SendAsync: Error occurred " + e.GetType(), e);
						}
					}
				}//*/

				if (DidUnityStop()) { break; }
				// DoSend() // Cannot be it's own function, needs direct loop control
				{
					try {
						while (outgoing.TryDequeue(out msg)) {
							//bool forceClose = msg.StartsWith("ForceDisconnect");

							Daemon.Log("Client sending " + msg, LogLevel.Maximal);

							msg += EOT;
							byte[] message = msg.ToBytesUTF8();
							message = enc(message);

							try {
								await stream.WriteAsync(message, 0, message.Length);
							
							} catch (Exception e) {
								Daemon.Log("\\hClient.SendAsync: Exiting " + identity + " from DoSend", LogLevel.Maximal);
								Daemon.Log("\\yClient.SendAsync: " + identity + " : " + e.GetType() + " - User probably disconnected", LogLevel.Maximal);
								throw e;
							}

							/*
							if (forceClose) {
								BakaNet.Log("Client.SendAsync: Forced to Terminate on " + identity + ".", LogLevel.Minimal);
								Close();
								return;
							}
							//*/
						}
					} catch (IOException e) {
						Daemon.Log("\\hClient.SendAsync: " + identity + " probably timed out. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (InvalidOperationException e) {
						Daemon.Log("\\hClient.RecieveAsync: " + identity + " probably timed out. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (SocketException e) {
						Daemon.Log("\\hClient.SendAsync: " + identity + " probably disconnected. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (Exception e) {
						Daemon.LogWarning("\\rClient.SendAsync: Error occurred " + e.GetType(), e);
					}
				}
				
				await Task.Delay(sendDelay);

			} // while (!closed) 
			Daemon.Log("\\bClient.SendAsync: Exiting " + identity, LogLevel.Normal);
		}


		/// <summary> Async Recieve Loop </summary>
		/// <returns> Running Task </returns>
		public async Task RecieveAsync() {
			byte[] buffer = new byte[4096];
			byte[] message;
			StringBuilder held = "";
			int bytesRead;
			string str;
			// BakaNet.Log("\\bClient.RecieveAsync: Entering " + identity, LogLevel.Normal);

			while (!closed) {
				if (DidUnityStop()) { break; }
				if (enc == null || dec == null) {
					Daemon.LogWarning("\\rNo Encryption/Decryption methods set on " + identity + "!");
					await Task.Delay(500);
					continue;
				}
				//Debug.Log("Client.RecieveAsync: Looping " + id, VERBOSE_CONNECTION_INFO);

				// DoRecieve() // Can't be its own function, again, it needs control over the loop.
				{
					bytesRead = 0;
					try {
						if (stream.DataAvailable) {
							bytesRead = await stream.ReadAsync(buffer, 0, 4096);
						}

						if (bytesRead > 0) {
							message = buffer.Chop(bytesRead);
							message = dec(message);
							str = message.GetStringUTF8();

							held += str;
							int index = held.IndexOf(EOT);
							while (index >= 0) {
								string pulled = held.Substring(0, index);
								held = held.Remove(0, index + 1);
								index = held.IndexOf(EOT);

								if (pulled.Length > 0) {
									RPCMessage msg = new RPCMessage(this, pulled);
									if (isLocal) {
										incoming.Enqueue(msg);
										Daemon.Log("\\bClient got " + msg.methodName, LogLevel.Maximal);
									} else {
										server.messages.Enqueue(msg);
										Daemon.Log("\\bServer got " + msg.methodName, LogLevel.Maximal);
									}

								} else {
									Daemon.Log("\\hHeartbeat " + identity, LogLevel.Maximal);
								}
								//TBD: Pass the message to a location for it to be handled, something like the following line
								//Server.main.messages.Enqueue(new Message(this, pulled));
							}
						}
					} catch (IOException e) {
						Daemon.Log("\\hClient.RecieveAsync: " + identity + " probably timed out. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (InvalidOperationException e) {
						Daemon.Log("\\hClient.RecieveAsync: " + identity + " probably timed out. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (SocketException e) {
						Daemon.Log("\\hClient.RecieveAsync: " + identity + " probably disconnected. " + e.GetType(), LogLevel.Maximal);
						Close();
						break;
					} catch (Exception e) {
						Daemon.LogWarning("\\rClient.RecieveAsync: Error occurred " + e.GetType(), e);
					}
				}

				await Task.Delay(recieveDelay);
			} // while (!closed)

			Daemon.Log("\\bClient.RecieveAsync: Exiting " + identity, LogLevel.Normal);
		}

	}
}
