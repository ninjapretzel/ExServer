using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.Threading;
using BakaBaka;

namespace BakaBaka.Utils {

	public static class ActionUtils {

		/// <summary> Attempts to invoke an Action, catch any exceptions that may have happened, and Debug.LogWarning if any exceptions occurred. </summary>
		/// <param name="action"> Action to attempt to invoke. </param>
		public static void TryInvoke(this Action action, 
				[CallerMemberName] string callerName = "[NO METHOD]", 
				[CallerFilePath] string callerPath = "[NO PATH]",
				[CallerLineNumber] int callerLine = -1) {
			if (action == null) {
				Daemon.LogWarning("\\rAction was null, you BAKA!\n", "Action.TryInvoke", callerName, callerPath, callerLine);
			} else {
				try {
					action();
				} catch (Exception e) {
					Daemon.LogWarning("\\rAction Failed to Invoke", e, "Action.TryInvoke", callerName, callerPath, callerLine);
				}
			}

		}
		
	}
}
