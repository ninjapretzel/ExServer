using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using LevelUpper.Extensions;
using TMPro;
using System.Reflection;
using LevelUpper.Extensions.Reflection;

[Serializable] public class RoundedBarInfo {
	public float angle { get; private set; }
	public float innerGap { get; private set; }
	public float width { get; private set; }
	public float startAngle { get; private set; }
	public Vector2 uvScale { get; private set; }
	public float direction { get; private set; } = 1;
	public float tesselationAngle { get; private set; } = 5;
	public float breakAngle { get; private set; } = -1;
	public RoundedBarInfo(float angle, float innerGap, float width, float startAngle, Vector2 uvScale, float direction = 1f, float tesselationAngle = 5f, float breakAngle = -1) {
		this.angle = angle;
		this.innerGap = innerGap;
		this.width = width;
		this.startAngle = startAngle;
		this.uvScale = uvScale;
		this.direction = direction;
		this.tesselationAngle = tesselationAngle;
		this.breakAngle = breakAngle;
	}
}

/// <summary> Class holding methods for advanced drawing during OnGUI() </summary>
public static class GLGUI {

	public static bool isRepaint { get { return Event.current != null && Event.current.type == EventType.Repaint; } }

	private static List<int> triangles = new List<int>(9000);
	private static List<Vector3> verts = new List<Vector3>(3000);
	private static List<Vector2> uv = new List<Vector2>(3000);

	public static void DrawRoundBar(RoundedBarInfo info, Vector3 point, Material mat, float normalizedSize = 1f, float fill = .5f, float delta = 0f) {
		if (isRepaint) {
			GenerateRoundedBarVertData(info);

			float ratio = info.angle / info.width * (.5f + info.innerGap) * .01f;
			float scale = (120f / 720f) * Screen.height * normalizedSize;
		
			mat.SetFloat("_Fill", fill);
			mat.SetFloat("_Delta", delta);
			mat.SetVector("_SizeInfo", new Vector4(ratio, 1, 0, 0));

			RenderCachedMesh(mat, point, Vector3.zero, new Vector3(scale, -scale, scale));

		}
	}	
	public static void RenderCachedMesh(Material mat, Vector3? useOffset = null, Vector3? useRotation = null, Vector3? useScale = null) {
		RenderMesh(triangles, verts, uv, mat, useOffset, useRotation, useScale);
	}

	public static void RenderMesh(List<int> triangles, List<Vector3> verts, List<Vector2> uv, Material material, Vector3? useOffset = null, Vector3? useRotation = null, Vector3? useScale = null) {
		if (isRepaint) { 
			
			Vector3 scale = useScale.HasValue ? useScale.Value : Vector3.one;
			Vector3 rot = useRotation.HasValue ? useRotation.Value : Vector3.zero;
			Vector3 offset = useOffset.HasValue ? useOffset.Value : Vector3.zero;

			Matrix4x4 trs = Matrix4x4.TRS(offset, Quaternion.Euler(rot), scale);

			GL.PushMatrix();
			GL.MultMatrix(trs);

			material.SetPass(0);

			GL.Begin(GL.TRIANGLES);

			for (int i = 0; i < triangles.Count; i += 3) {
				
				int a = triangles[i];
				int b = triangles[i + 1];
				int c = triangles[i + 2];
				Vector3 av = verts[a];
				Vector3 bv = verts[b];
				Vector3 cv = verts[c];
				
				if (a < uv.Count) { GL.MultiTexCoord(0, uv[a]); }
				GL.Color(Color.white);
				GL.Vertex(av);

				if (b < uv.Count) { GL.MultiTexCoord(0, uv[b]); }
				GL.Color(Color.white);
				GL.Vertex(bv);

				if (c < uv.Count) { GL.MultiTexCoord(0, uv[c]); }
				GL.Color(Color.white);
				GL.Vertex(cv);
				
			}
		
			GL.End();
		
			GL.PopMatrix();

		}
	}

	public static Mesh GenerateRoundedBar(float angle, float innerGap, float width, float startAngle, Vector2 uvScale, float direction = 1, float tesselationAngle = 5, float breakAngle = -1) {
		Mesh mesh = new Mesh();
		
		GenerateRoundedBarVertData(angle, innerGap, width, startAngle, uvScale, direction, tesselationAngle, breakAngle);

		mesh.SetVertices(verts);
		mesh.SetUVs(0, uv);
		mesh.SetTriangles(triangles, 0);
		
		return mesh;
	}

	public static void GenerateRoundedBarVertData(RoundedBarInfo info) {
		GenerateRoundedBarVertData(info.angle, info.innerGap, info.width, info.startAngle, info.uvScale, info.direction, info.tesselationAngle, info.breakAngle);
	}

	public static void GenerateRoundedBarVertData(float angle, float innerGap, float width, float startAngle, Vector2 uvScale, float direction = 1, float tesselationAngle = 5, float breakAngle = -1) {
		int cnt = ((int)(angle / tesselationAngle));

		verts.Clear();
		uv.Clear();
		triangles.Clear();

		float curAngle = startAngle * Mathf.Deg2Rad;
		direction = (direction < 0) ? -1 : 1;
		float mangle = ((int)(angle / tesselationAngle)) * tesselationAngle * Mathf.Deg2Rad;
		float dangle = tesselationAngle * direction * Mathf.Deg2Rad;
		float bangle = breakAngle * Mathf.Deg2Rad;
		float covered = 0;
		float innerDistance = Mathf.Abs(innerGap);
		float outerDistance = innerDistance + Mathf.Abs(width);

		float avgUV = (innerDistance + outerDistance) / 2f;

		Vector3 rotsNow = new Vector3(Mathf.Cos(curAngle), Mathf.Sin(curAngle), 0);
		Vector3 rotsLast = new Vector3(Mathf.Cos(curAngle - dangle), Mathf.Sin(curAngle - dangle), 0);
		Vector3 segDiff = (rotsNow - rotsLast);// * (outerDistance + innerDistance) / 2f;

		Vector3 iLast = rotsNow * innerDistance;
		Vector3 oLast = rotsNow * outerDistance;
		float pLast = 0;
		verts.Add(iLast); verts.Add(oLast);
		uv.Add(new Vector3(pLast, 0)); uv.Add(new Vector3(pLast, uvScale.y));


		for (int i = 0; i < cnt; i++) {
			int innerVert = 2 + i * 2;
			int outerVert = innerVert + 1;

			if (breakAngle > 0 && covered < bangle && (covered + Mathf.Abs(dangle)) > bangle) {
				segDiff = new Vector3(
					-Mathf.Sin(curAngle),
					Mathf.Cos(curAngle),
					0
					) * segDiff.magnitude * avgUV;
			}
			curAngle += dangle;
			covered += Mathf.Abs(dangle);
			float pNow = pLast + Mathf.Abs(dangle / mangle * uvScale.x);
			Vector3 iNow, oNow;
			if (breakAngle > 0 && covered > bangle) {

				iNow = iLast + segDiff;
				oNow = oLast + segDiff;

			} else {

				rotsNow = new Vector3(Mathf.Cos(curAngle), Mathf.Sin(curAngle), 0);
				rotsLast = rotsNow;

				iNow = rotsNow * innerDistance;
				oNow = rotsNow * outerDistance;
			}

			verts.Add(iNow); verts.Add(oNow);
			uv.Add(new Vector3(pNow, 0)); uv.Add(new Vector3(pNow, uvScale.y));

			// Both TRIs need to be front facing
			triangles.Add(innerVert - 0);
			triangles.Add(innerVert - 1);
			triangles.Add(innerVert - 2);

			triangles.Add(outerVert - 1);
			triangles.Add(outerVert - 0);
			triangles.Add(outerVert - 2);

			pLast = pNow;
			iLast = iNow;
			oLast = oNow;

		}
	}


	public static void DrawBar(Rect rect, Material mat, float fill, float delta = 0, float _barBorder = .005f, float _barSize = .008f) {
		mat.SetFloat("_Fill", fill);
		mat.SetFloat("_Delta", delta);
		mat.SetFloat("_Border", _barBorder);
		mat.SetVector("_SizeInfo", new Vector4(rect.width, rect.height, 0, 0) / rect.height);

		GLGUI.DrawRect(rect, new Rect(0, 0, 1, 1), mat);
	}
	/// <summary> Draws a material, on a (typically) screen rect, with a given set of texture coords and using a given material. </summary>
	/// <param name="rect"> Area of screen to draw on </param>
	/// <param name="texRect"> Texture coordinates </param>
	/// <param name="mat"> Material to use to draw (pass 0) </param>
	public static void DrawRect(Rect rect, Rect texRect, Material mat) {
		if (isRepaint) {

			GL.PushMatrix();
			mat.SetPass(0);

			GL.Begin(GL.TRIANGLES);
			GL.TexCoord(texRect.TopLeft());
			GL.Vertex(rect.TopLeft());

			GL.TexCoord(texRect.TopRight());
			GL.Vertex(rect.TopRight());

			GL.TexCoord(texRect.BottomLeft());
			GL.Vertex(rect.BottomLeft());

			GL.TexCoord(texRect.TopRight());
			GL.Vertex(rect.TopRight());

			GL.TexCoord(texRect.BottomLeft());
			GL.Vertex(rect.BottomLeft());

			GL.TexCoord(texRect.BottomRight());
			GL.Vertex(rect.BottomRight());

			GL.End();

			GL.PopMatrix();
		}
	}
	
	private static Dictionary<TMP_FontAsset, TextMeshPro> generators = new Dictionary<TMP_FontAsset, TextMeshPro>();
	private static TextMeshPro GeneratorFor(TMP_FontAsset asset) {
		if (!generators.ContainsKey(asset)) {
			GameObject obj = new GameObject("TextBitch - " + asset.name);
			GameObject.DontDestroyOnLoad(obj);
			TextMeshPro tb = obj.AddComponent<TextMeshPro>();
			
			tb.SetField("m_fontAsset", asset);
			tb.UpdateFontAsset();

			tb.color = Color.clear;
			tb.raycastTarget = false;
			tb.alignment = TextAlignmentOptions.Center;
			//tb.alignment = TextAlignmentOptions.Midline;
			
			tb.rectTransform.anchorMax = new Vector2(1, 1);
			tb.rectTransform.anchorMin = new Vector2(0, 0);

			tb.rectTransform.offsetMax = new Vector2(0, 0);
			tb.rectTransform.offsetMin = new Vector2(0, 0);

			generators[asset] = tb;
		}
		return generators[asset];
	}

	
	public static void DrawTextPro(Rect area, string text, TMP_FontAsset asset, TextAnchor? useAnchor = null, Vector3? useScale = null, Vector3? useParam = null) {
		if (isRepaint) {
			Vector3 scale = useScale.HasValue ? useScale.Value : Vector3.one;
			Vector3 param = useParam.HasValue ? useParam.Value : new Vector3(.5f, 1, .5f);

			TextAnchor anchor = useAnchor.HasValue ? useAnchor.Value : TextAnchor.MiddleCenter;
			
			TextMeshPro tb = GeneratorFor(asset);
			tb.text = text;
			
			tb.rectTransform.offsetMin = new Vector2(-area.width / 2f, -area.height / 2f);
			tb.rectTransform.offsetMax = new Vector2(area.width / 2f, area.height / 2f);

			tb.ForceMeshUpdate();
			Mesh m = tb.mesh;
			float width = tb.renderedWidth;
			float height = tb.renderedHeight;

			//GL.PushMatrix();
			asset.material.SetPass(0);
			GL.Begin(GL.TRIANGLES);

			//int[] triangles = m.triangles;
			//Vector3[] verts = m.vertices;
			//Vector2[] uv = m.uv;
			m.GetTriangles(triangles, 0);
			m.GetVertices(verts);
			m.GetUVs(0, uv);
			
			//StringBuilder s = "";
			Vector3 origin = area.Point(anchor);
			Rect bumpRect = new Rect(-width/2, -height/2, width, height);
			Vector3 bump = Vector3.Scale(bumpRect.Point(anchor), scale);
			//bump.y *= -1;
			for (int i = 0; i < triangles.Count; i+=3) {
				int a = triangles[i];
				int b = triangles[i+1];
				int c = triangles[i+2];

				
				Vector3 av = Vector3.Scale(scale, verts[a]); av.y *= -1; av += origin - bump;
				Vector3 bv = Vector3.Scale(scale, verts[b]); bv.y *= -1; bv += origin - bump;
				Vector3 cv = Vector3.Scale(scale, verts[c]); cv.y *= -1; cv += origin - bump;

				//GL.TexCoord(uv[a]);
				if (a < uv.Count) { GL.MultiTexCoord(0, uv[a]); }
				GL.MultiTexCoord(1, param);
				//if (uv2 != null && a < uv2.Length) { GL.MultiTexCoord(2, uv2[a]); }
				//if (uv3 != null && a < uv3.Length) { GL.MultiTexCoord(3, uv3[a]); }
				//if (uv4 != null && a < uv4.Length) { GL.MultiTexCoord(4, uv4[a]); }
				GL.Color(Color.white);
				GL.Vertex(av);

				//GL.TexCoord(uv[b]);
				if (b < uv.Count) { GL.MultiTexCoord(0, uv[b]); }
				GL.MultiTexCoord(1, param);
				GL.MultiTexCoord(2, param);
				//if (uv2 != null && b < uv2.Length) { GL.MultiTexCoord(2, uv2[b]); }
				//if (uv3 != null && b < uv3.Length) { GL.MultiTexCoord(3, uv3[b]); }
				//if (uv4 != null && b < uv4.Length) { GL.MultiTexCoord(4, uv4[b]); }
				GL.Color(Color.white);
				GL.Vertex(bv);

				//GL.TexCoord(uv[c]);
				if (c < uv.Count) { GL.MultiTexCoord(0, uv[c]); }
				GL.MultiTexCoord(1, param);
				GL.MultiTexCoord(2, param);
				//if (uv2 != null && c < uv2.Length) { GL.MultiTexCoord(2, uv2[c]); }
				//if (uv3 != null && c < uv3.Length) { GL.MultiTexCoord(3, uv3[c]); }
				//if (uv4 != null && c < uv4.Length) { GL.MultiTexCoord(4, uv4[c]); }
				GL.Color(Color.white);
				GL.Vertex(cv);
				//s = s + $"Tri from: {i/3} {av}, {bv}, {cv}\n";
			}

			//Debug.Log(s.ToString());
			GL.End();

			//GL.PopMatrix();

		}

	}




}
