using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using BakaDB;
using BakaBaka;
using System.Linq;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;

using Random = LevelUpper.RNG.Random;
using LevelUpper.RNG;

namespace BakaNet.Modules {

	/// <summary> Support class for the <see cref="Entities"/> Module. Holds information about active maps. </summary>
	public class Maps {

		private static LocalDB mapDB = DB.Local("content/maps");

		/// <summary> Information about what instanced maps exist (mapName)->(mapIDs) </summary>
		public ConcurrentDictionary<string, ConcurrentSet<string>> instances;

		/// <summary> Information about what persistant maps exist (mapName)->(mapID) </summary>
		public ConcurrentDictionary<string, string> persistant;

		/// <summary> Actual instances of maps. </summary>
		public ConcurrentDictionary<string, Map> live;
		
		public Maps() {
			persistant = new ConcurrentDictionary<string, string>();
			instances = new ConcurrentDictionary<string, ConcurrentSet<string>>();
			live = new ConcurrentDictionary<string, Map>();
		}
		
		/// <summary> Indexer. Retrieves a map by id. </summary>
		/// <param name="id"> </param>
		/// <returns></returns>
		public Map this[string id] { get { return live.ContainsKey(id) ? live[id] : null; } }

		/// <summary> Returns if a map by a given ID exists. </summary>
		/// <param name="id"> </param>
		/// <returns> </returns>
		public bool Has(string id) { return live.ContainsKey(id); }

		/// <summary> Returns a map by name, if it exists, or null if it does not. </summary>
		/// <param name="name"> Name of map to check for </param>
		/// <returns> Map with the given name, or null. </returns>
		public Map Get(string name) { 
			if (!persistant.ContainsKey(name)) { return null; }
			var id = persistant[name];
			return live[id];
		}

		/// <summary> Retrieves a map by name. If there is no map, spins it up. </summary>
		/// <param name="name"> Name of map to load </param>
		/// <returns> Map with the given name. </returns>
		public Map Place(string name) {
			if (!persistant.ContainsKey(name)) { return SpinUp(name); }
			var id = persistant[name];
			return live[id];
		}
		
		/// <summary> Spins up a new instance of a map </summary>
		/// <param name="name"> Name of map to spin up, files to load. </param>
		/// <returns> New Map instance created. </returns>
		private Map SpinUp(string name) {
			Daemon.Log("Spinning up new map " + name, LogLevel.Verbose);
			string id = Guid.NewGuid().ToString();

			
			JsonValue record;
			JsonObject data = null;
			if (mapDB.Check(name+"/data.wtf", out record)) {
				data = (JsonObject) record;
				UnityEngine.Debug.Log("Got Map Data: " + data.PrettyPrint());
			} else {
				Daemon.Log("Could not find map data for [" + name + "].", LogLevel.Lower);
			}

			
			Map map = new Map(name, id, data);
			persistant[name] = id;
			live[id] = map;

			return map;
		}

	}

	/// <summary> Featherweight struct which holds details for kinds of entities.  </summary>
	public class EntityFly {

		/// <summary> Type of entity </summary>
		public string type = "NoType";
		
		public Func<Map, EntityInfo, DateTime?> update = null;

		public Func<Map, Cell, EntityInfo, EntityInfo, bool> collision = null;

		public Action<Map, EntityInfo> unregistered = null;

		public Action<Map, EntityInfo> spawn = null;

	}

	/// <summary> </summary>
	public struct EntityInfo {
		/// <summary> Invariant flyweight information. </summary>
		public EntityFly fly;
		/// <summary> Index of entity in its given array. </summary>
		public int id;

		/// <summary> Is this EntityInfo representing a live entity? </summary>
		public bool live;

		public Vector3 position;
		public Quaternion rotation;
		public Vector3 velocity;
		public Vector3 angVelocity;

		public string name;
		public string model;


	}

	/// <summary> Support class for the <see cref="Entities"/> Module. Holds information about a single group of entities. </summary>
	public class Map {

		/// <summary> JsonArray used to mask a set of data to send to connected clients. </summary>
		public static string[] infoMask = new string[] { 
			"cellSize", "cellDist", "is3d" 
		};

		/// <summary> Functions to update entities. </summary>
		public static Dictionary<string, Func<Map, string, DateTime?>> updateFunctions = new Dictionary<string, Func<Map, string, DateTime?>>();

		/// <summary> Functions to collide entities. </summary>
		public static Dictionary<string, Func<Map, Cell, string, string, bool>> collisionFunctions = new Dictionary<string, Func<Map, Cell, string, string, bool>>() {
			{ "nothing", null },	
		};
		/// <summary> Functions to call when entities are used. </summary>
		public static Dictionary<string, Action<Map, string, string>> onUsedFunctions = new Dictionary<string, Action<Map, string, string>>();

		/// <summary> Functions to call when entities are unregistered </summary>
		public static Dictionary<string, Action<Map, string>> onUnregisteredFunctions = new Dictionary<string, Action<Map, string>>();

		/// <summary> Functions to call when objects are spawned </summary>
		public static Dictionary<string, Action<JsonObject>> onSpawnFunctions = new Dictionary<string, Action<JsonObject>>();

		/// <summary> Functions to call when entities are registered </summary>
		public static Dictionary<string, Action<string>> onRegisteredFunctions = new Dictionary<string, Action<string>>();


		/// <summary> Entity SyncData context </summary>
		private static SyncData entityData = SyncData.Context("Entities");
		
		/// <summary> Entity Database </summary>
		private static LocalDB contentDB = DB.Local("content");
		/// <summary> All Entity Types, loaded at startup. </summary>
		public static JsonObject entityTypes = LoadEntityTypes();
		public static JsonObject LoadEntityTypes() {
			return contentDB.Open("entityTypes.wtf") as JsonObject;
		}
		
		/// <summary> All Entities on a given map. </summary>
		public ConcurrentSet<string> entities;

		/// <summary> All Clients connected to a given map </summary>
		public ConcurrentSet<Client> clients;

		/// <summary> Cells in the given map </summary>
		public ConcurrentDictionary<Vector3Int, Cell> cells;

		/// <summary> Entities to despawn on the next tick. </summary>
		private ConcurrentSet<string> toDespawn;

		/// <summary> Entities to sapwn on the next tick. </summary>
		private ConcurrentSet<JsonObject> toSpawn;

		/// <summary> Is this map a 3d or 2d map? </summary>
		public bool is3d { get; private set; } 

		/// <summary> Max Sight Distance </summary>
		public int cellDist { get; private set; }
		
		/// <summary> Class to hold information about updating entities. </summary>
		internal class UpdateInfo {
			public string entityID;
			public Func<Map, string, DateTime?> updateFunc;
			public DateTime? nextTick;
		}
		/// <summary> Class to hold information about colliding entities. </summary>
		internal class CollideInfo {
			public string entityID;
			public Func<Map, Cell, string, string, bool> collideFunc;
			public int maxCollisions;
			public float radius;
		}
		/// <summary> List of updates informations for registered entities </summary>
		private ConcurrentDictionary<string, UpdateInfo> updateInfos;

		/// <summary> List of collide informations for registered entities </summary>
		private ConcurrentDictionary<string, CollideInfo> collideInfos;

		/// <summary> Cache of entityID to collisionMethods </summary>
		private Cache<string, string> entityCollisionCache;
		
		/// <summary> string GUID for this map. </summary>
		public string id { get; private set; }

		/// <summary> Name of this map. </summary>
		public string name { get; private set; }

		/// <summary> Gets the number of connected players </summary>
		public int numPlayers { get { return clients.Count; } }

		/// <summary> JsonObject that was used to load the map </summary>
		public JsonObject mapData;

		/// <summary> Cached json payload to send to clients that connect to the map. </summary>
		public string mapInfo;

		/// <summary> Delta for the last tick during updates. </summary>
		public float delta { get; private set; }
		/// <summary> Start timestamp of the tick for during updates. </summary>
		public DateTime tickStart { get; private set; }

		/// <summary> Size of a single cell. Cells are centered on points from (0,0) stepping in all directions by cellSize. </summary>
		public float cellSize = 10f;

		/// <summary> Callback chain for after entities are registered </summary>
		public Action<string> onRegisterEntity = null;

		/// <summary> Callback chain when entities are spawned </summary>
		public Action<JsonObject> onSpawnEntity = null;


		public Trender spawnTrend;
		public Trender despawnTrend;
		public Trender collideTrend;
		public Trender updateTrend;
		
		/// <summary> Constructor for a map instance </summary>
		/// <param name="name"> Name of the map </param>
		/// <param name="id"> ID of the map. Defaults to a newly created GUID string if not passed. </param>
		/// <param name="data"> Map data. Defaults to nothing if not passed. </param>
		public Map(string name, string id = null, JsonObject data = null) {
			this.name = name;
			mapData = data;

			if (id == null) { id = Guid.NewGuid().ToString(); }
			this.id = id;
			entities = new ConcurrentSet<string>();
			clients = new ConcurrentSet<Client>();
			cells = new ConcurrentDictionary<Vector3Int, Cell>();

			toSpawn = new ConcurrentSet<JsonObject>();
			toDespawn = new ConcurrentSet<string>();

			updateInfos = new ConcurrentDictionary<string, UpdateInfo>();
			collideInfos = new ConcurrentDictionary<string, CollideInfo>();
			
			spawnTrend = new Trender();
			despawnTrend = new Trender();
			collideTrend = new Trender();
			updateTrend = new Trender();
			
			entityCollisionCache = new Cache<string, string>((entityID)=>{
				var collisionFunc = entityData.PullServer(entityID + ".collisionFunc", "nothing");
				//if (!collisionFunctions.ContainsKey(collisionFunc)) { collisionFunc = "nothing"; }
				return collisionFunc;
			});

			LoadInfo(data);
		}
		
		/// <summary> Used upon startup, Loads map information from a JsonObject  </summary>
		/// <param name="data"> data object to load information from </param>
		private void LoadInfo(JsonObject data = null) {
			if (data == null) { return; }

			cellDist = data.Pull("cellDist", 1);
			cellSize = data.Pull("cellSize", 13.33f);
			is3d = data.Pull("is3d", false);

			JsonObject payload = data.DeepCopy() as JsonObject;
			payload.Remove("entities");

			payload["id"] = id;
			payload["name"] = name;
			mapInfo = payload.ToString();

			JsonArray onSpawn = data.Get<JsonArray>("onSpawn");
			if (onSpawn != null) {
				foreach (var it in onSpawn) {
					string name = it.stringVal;
					if (onSpawnFunctions.ContainsKey(name)) { onSpawnEntity += onSpawnFunctions[name]; }
				}
			}

			JsonArray onRegister = data.Get<JsonArray>("onRegister");
			if (onRegister != null) {
				foreach (var it in onRegister) {
					string name = it.stringVal;
					if (onRegisteredFunctions.ContainsKey(name)) { onRegisterEntity += onRegisteredFunctions[name]; }
				}	
			}


			if (data.ContainsKey("entities")) {
				var entityArray = data.Get<JsonArray>("entities");
				if (entityArray != null) {
					foreach (var ent in entityArray) {
						UnityEngine.Debug.Log("Spawning " + ent.ToString());
						JsonObject entData = ent as JsonObject;
						Spawn(entData);
					}
				}

				var entityObj = data.Get<JsonObject>("entities");
				if (entityObj != null) {
					foreach (var pair in entityObj) {
						JsonObject entData = pair.Value as JsonObject;
						Spawn(entData);
					}
				}
					
			}

		}

		internal static readonly string[] pickRandomly = {
			"name",
			"model",
			"sprite",
		};
		internal static readonly string[] lerpRandomly = {
			"scale",
			"radius",
		};
		
		static Rand rng = new Rand();
		private static JsonValue RandomPick(JsonArray arr) { return arr[rng.Range(0, arr.Count)]; }
		private static JsonValue RandomLerp(JsonArray arr) {
			float val = 0;
			if (arr.Count == 1) { val = arr[0].floatVal; }
			else if (arr.Count >= 2) {
				float p = rng.value;
				float a = arr[0].floatVal;
				float b = arr[1].floatVal;
				val =  Mathf.Lerp(a, b, p);
			}

			return val;
		}

		/// <summary> Load an entity type model from the database </summary>
		/// <param name="type"> Type of entity data to load </param>
		/// <returns> Processed copy of that entity's data </returns>
		private JsonObject LoadEntityType(string type) {
			return (entityTypes[type.ToLower()].DeepCopy() as JsonObject);
		}




		/// <summary> Queues an entity to be spawned during the next frame </summary>
		/// <param name="data"></param>
		/// <returns></returns>
		public string QueueForSpawn(JsonObject data) {
			string entityID = Entities.nextEntityID;
			data["entityID"] = entityID;
			toSpawn.Add(data);

			return entityID;
		}

		/// <summary> Spawns an entity on the map, using the given data. </summary>
		/// <param name="data"> Data source to use to spawn the entity. </param>
		/// <returns> Entity ID of new entity. </returns>
		public string Spawn(JsonObject data) {
			if (data == null) { Daemon.LogWarning("spawning null entity????"); }
			string entityID = (data.Has("entityID")) ? data.Get<string>("entityID") : Entities.nextEntityID;
			//if (entityData == null) { entityData = SyncData.Context("Entities"); }

			string type = data.Get<string>("type");
			//Daemon.Log("\\mSpawning entity of " + type, LogLevel.Verbose);
			
			JsonObject entity = LoadEntityType(type) ?? new JsonObject();
			JsonObject edata = new JsonObject();
			edata.Set(entity);
			
			edata.SetRecursively(data)
					.ReduceArrays(pickRandomly, RandomPick)
					.ReduceArrays(lerpRandomly, RandomLerp);

			edata["type"] = type;
			edata["mapID"] = id;

			onSpawnEntity(edata);

			entityData.SetData(entityID, edata);

			RegisterEntity(entityID);

			return entityID;
		}



		/// <summary> Holds common logic to regestering both Non-Player and Player entities </summary>
		/// <param name="entityID"></param>
		/// <param name="client"></param>
		public void RegisterEntity(string entityID, Client client = null) {
			JsonObject edata = entityData.ReadServer(entityID) as JsonObject;
			//UnityEngine.Debug.Log("Registered entity " + edata.PrettyPrint());

			Vector3 position = edata.GetV3("position");
			Cell cell = CellFor(position);
			entities.Add(entityID);
			cell.entities.Add(entityID);

			if (client != null) {
				cell.clients.Add(client);
				clients.Add(client);
			}

			onRegisterEntity?.Invoke(entityID);

			var updateFunc = edata.Pull("updateFunc", "nothing");
			if (updateFunc != "nothing" && updateFunctions.ContainsKey(updateFunc)) {
				updateInfos[entityID] = new UpdateInfo() {
					entityID = entityID,
					updateFunc = updateFunctions[updateFunc]
				};
			}
			var collideFunc = edata.Pull("collisionFunc", "nothing");
			if (collisionFunctions.ContainsKey(collideFunc)) {
				//UnityEngine.Debug.Log("Added collision info for " + entityID + " / " + collideFunc);
				collideInfos[entityID] = new CollideInfo() {
					entityID = entityID,
					collideFunc = collisionFunctions[collideFunc],
					maxCollisions = edata.Pull("maxCollisions", 1),
					radius = edata.Pull("radius", 1)
				};
			}

			entityData.SetData(entityID + ".mapID", id);
			foreach (var c in ClientsWhoCanSee(position)) {
				entityData.DoSubscribe(c, entityID);
			}
			
		}

		/// <summary> Marks the entitiy with the given ID for despawn on the end of the next tick. </summary>
		/// <param name="id"> ID of entity to despawn </param>
		public void MarkForDespawn(string id) { 
			if (entities.Contains(id)) {
				if (!toDespawn.Contains(id)) {
					//entityData.SetData(id+".dead", true);
					toDespawn.Add(id); 
				}

			} else { Daemon.LogWarning("Map " + name + " cannot despawn [" + id + "] as it is not on that map."); }
		}

		/// <summary> Despawns the entity with the given ID from the map. Cannot despawn players. </summary>
		/// <param name="id"> Entity ID </param>
		private void Despawn(string id) {

			if (entityData.ReadServer(id+".user") == null) {
				UnregisterEntity(id);
				// Remove Data for Despawned entities. 
				entityData.srvJson.Remove(id);
			} else { Daemon.LogWarning("Cannot Despawn USER entity. They may only be despawned by Entities.ExitMap(Client)"); }
		}

		/// <summary> Holds common logic to unregestering both Player and Non-Player Entities </summary>
		/// <param name="id"></param>
		/// <param name="client"></param>
		public void UnregisterEntity(string id, Client client = null) {
			if (entities.Contains(id)) {

				JsonObject entity = entityData.ReadServer(id) as JsonObject;
				if (entity != null) {

					Vector3 position = entity.GetV3("position");
					Cell cell = CellFor(position);

					entities.Remove(id);
					cell.entities.Remove(id);

					if (client != null) {
						clients.Remove(client);
						cell.clients.Remove(client);
					}
					
					// Optimization: These are linear, and potentially slow on populated maps
					//updateInfos.RemoveAll((ui) => (ui.entityID == id));
					UpdateInfo __ui;
					CollideInfo __ci;
					updateInfos.TryRemove(id, out __ui);
					collideInfos.TryRemove(id, out __ci);

					JsonObject onUnregistered = entity.Get<JsonObject>("onUnregistered");
					if (onUnregistered != null) {
						foreach (var pair in onUnregistered) {
							string cbName = pair.Key.stringVal;
							if (onUnregisteredFunctions.ContainsKey(cbName)) {
								var callback = onUnregisteredFunctions[cbName];
								try {
									callback(this, id);
								} catch(Exception e) { Daemon.LogWarning("onDeregistered: Failed to call " + cbName, e); }
							}
						}
					}
					
					foreach (var c in ClientsWhoCanSee(position)) {
						entityData.DoUnsubscribe(c, id);
					}
					
				} else { Daemon.LogWarning("Cannot unregister [" + id + "] - no entity data available."); }
			} else { Daemon.LogWarning("Cannot despawn [" + id + "] - entity is not in map " + name); }
		}
		
		Stopwatch sw = new Stopwatch();
		public void Update() {
			tickStart = NetworkDaemon.lastTickStart;
			delta = NetworkDaemon.lastDelta;

			updateLogger.Reset();
			
			sw.Start();
			UpdateEntities();
			sw.Stop();
			updateTrend.Record(sw.ElapsedMilliseconds);
			sw.Reset(); 


			foreach (var pair in cells) {
				Cell cell = pair.Value;
				
				sw.Start();
				CollideCell(cell);
				sw.Stop();
				collideTrend.Record(sw.ElapsedMilliseconds);
				sw.Reset();

			}

			sw.Start();
			if (!toDespawn.IsEmpty) {
				ConcurrentSet<string> despawn = new ConcurrentSet<string>();
				// Make sure nothing will be adding more entities to the set to get despawned.
				despawn = Interlocked.Exchange(ref toDespawn, despawn);
				foreach (var entityID in despawn) { Despawn(entityID); }
				sw.Stop();
				despawnTrend.Record(sw.ElapsedMilliseconds);
			}
			sw.Reset();

			sw.Start();
			if (!toSpawn.IsEmpty) {
				ConcurrentSet<JsonObject> spawn = new ConcurrentSet<JsonObject>();
				spawn = Interlocked.Exchange(ref toSpawn, spawn);
				foreach (var entityData in spawn) { Spawn(entityData); }
				sw.Stop();
				spawnTrend.Record(sw.ElapsedMilliseconds);
			}
			sw.Reset();
			
		}

		#region Collision Detection

		public static bool DRAW_COLLISION_DEBUG = false;

		internal struct EntityCollider {
			internal CollideInfo info;
			internal string entityID;
			internal Vector3 position;
			internal float radius;
			internal EntityCollider(CollideInfo info, Vector3 pos) { this.info = info; entityID = info.entityID; position = pos; radius = info.radius; }
			internal void Set(CollideInfo info, Vector3 pos) { this.info = info; entityID = info.entityID; position = pos; radius = info.radius; }
			internal bool Intersects(EntityCollider other) {
				Vector3 diff = position - other.position;
				float rad = radius + other.radius;

				bool hit = diff.sqrMagnitude < rad*rad;
				Vector3 pos1 = position;
				Vector3 pos2 = other.position;
				float rad1 = radius;
				float rad2 = other.radius;

				if (DRAW_COLLISION_DEBUG) {
					Daemon.RunOnMainThread(() => {
						UnityEngine.Debug.DrawLine(pos1, pos2, hit ? Color.red : Color.blue);

						UnityEngine.Debug.DrawLine(pos1 - Vector3.right * rad1, pos1 + Vector3.right * rad1, Color.green);
						UnityEngine.Debug.DrawLine(pos1 - Vector3.up * rad1, pos1 + Vector3.up * rad1, Color.green);
						UnityEngine.Debug.DrawLine(pos1 - Vector3.back * rad1, pos1 + Vector3.back * rad1, Color.green);

						UnityEngine.Debug.DrawLine(pos2 - Vector3.right * rad2, pos2 + Vector3.right * rad2, Color.green);
						UnityEngine.Debug.DrawLine(pos2 - Vector3.up * rad2, pos2 + Vector3.up * rad2, Color.green);
						UnityEngine.Debug.DrawLine(pos2 - Vector3.back * rad2, pos2 + Vector3.back * rad2, Color.green);
					});
				}

				return hit;
			}
		}

		TimeLogger updateLogger = new TimeLogger("Update Logger");
		
		public void UpdateEntities() {
			foreach (var pair in updateInfos) {
				var ui = pair.Value;
				if (ui.nextTick.HasValue && tickStart < ui.nextTick.Value) { continue; }
				string entityID = ui.entityID;
				try {		
					ui.nextTick = ui.updateFunc(this, entityID);
				} catch (Exception e) { Daemon.LogWarning("Error during update of [" + entityID + "]", e); }
			}
			
		}

		Dictionary<string, List<EntityCollider>> byCollisionFunc = new Dictionary<string, List<EntityCollider>>();
		List<EntityCollider> pool = new List<EntityCollider>();
		
		public void CollideCell(Cell cell) {
			// Reclaim entityColliders back into the pool.
			foreach (var pair in byCollisionFunc) { 
				foreach (var col in pair.Value) { pool.Add(col); }
				pair.Value.Clear(); 
			}
			//byCollisionFunc.Clear();

			EntityCollider collider = new EntityCollider();
			foreach (string entityID in cell.entities) {
				var collisionFunc = entityCollisionCache[entityID];
				
				// These allocs are fairly rare (only on new collision functions), and fine.
				if (!byCollisionFunc.ContainsKey(collisionFunc)) { byCollisionFunc[collisionFunc] = new List<EntityCollider>(); }
				JsonObject edata = entityData.ReadServer(entityID) as JsonObject;
				if (edata == null) { continue; }
				Vector3 pos = edata.GetV3("position");
				
				if (collideInfos.ContainsKey(entityID)) {
					CollideInfo info = collideInfos[entityID];
					// Should avoid most alloc
					//EntityCollider collider = (pool.Count > 0) ? pool[pool.Count-1] : new EntityCollider();
					//if (pool.Count > 0) { pool.RemoveAt(pool.Count-1); }
					
					collider.Set(info, pos);
					
					byCollisionFunc[collisionFunc].Add(collider);
				}
				
			}
			
			foreach (var pair in byCollisionFunc) {
				string collisionFunc = pair.Key;
				// Skip functions that have nothing bound to them 
				if (!collisionFunctions.ContainsKey(collisionFunc)) { continue; }
				//Action<Map, Cell, string, string> cfunc = collisionFunctions[collisionFunc];

				List<EntityCollider> colliders = pair.Value;

				foreach (EntityCollider col in colliders) {
					if (col.info.collideFunc == null) { continue; }
					
					//UnityEngine.Debug.Log("Colliding " + collider.entityID + " with " + collider.info.collideFunc.Method.Name);
					foreach (var otherPair in byCollisionFunc) {
						int collisions = 0;
						var otherFunc = otherPair.Key;
						if (collisionFunc == otherFunc) { continue; }

						List<EntityCollider> otherColliders = otherPair.Value;
						foreach (var otherCollider in otherColliders) {
							if (col.Intersects(otherCollider)) {
								bool hit = col.info.collideFunc.Invoke(this, cell, col.entityID, otherCollider.entityID);
								if (hit) { 
									collisions++;
									if (collisions > col.info.maxCollisions) { break; }
								}
							}
							
						}

					}

				}

			}
		}


		#endregion


		/// <summary> Sends a message to all clients who can see a given cell, delayed. </summary>
		/// <param name="position"> Position </param>
		/// <param name="message"> Message content to send </param>
		public void Send(Vector3 position, params object[] message) {
			Task.Run(()=>{ SendToVisibleClients(position, message); });
		}
		/// <summary> Sends a message to all clients that can see a given position</summary>
		/// <param name="position"> Position </param>
		/// <param name="stuff"> Message content to send </param>
		public void SendToVisibleClients(Vector3 position, params object[] stuff) { SendToVisibleClients(CellPositionFor(position), stuff); }
		/// <summary> Sends a message to all clients that can see a given cell</summary>
		/// <param name="cellPos"> Position </param>
		/// <param name="stuff"> Message content to send </param>
		public void SendToVisibleClients(Vector3Int cellPos, params object[] stuff) {
			var msg = Client.FormatMessage(stuff);
			foreach (var client in ClientsWhoCanSee(cellPos)) {
				client.SendMessageDirectly(msg);
			}
		}

		#region Visibility set calculation Methods
		/// <summary> Gets all clients that can see a given position </summary>
		/// <param name="position"> Position </param>
		/// <returns> HashSet of all clients who can see a position </returns>
		public HashSet<Client> ClientsWhoCanSee(Vector3 position) { return ClientsWhoCanSee(CellPositionFor(position)); }
		/// <summary> Gets all clients that can see a given cell </summary>
		/// <param name="position"> Position </param>
		/// <returns> HashSet of all clients who can see a cell </returns>
		public HashSet<Client> ClientsWhoCanSee(Vector3Int cellPos) {
			HashSet<Client> clients = new HashSet<Client>();
			IEnumerable<Vector3Int> visilbility = VisibleFrom(cellPos);

			foreach (var cpos in visilbility) {
				Cell cell = PeekCell(cpos);
				if (cell != null && cell.clients.Count > 0) { 
					foreach (var client in cell.clients) { clients.Add(client); }
				}
			}

			return clients;
		}

		/// <summary> Gets a IEnumerable  of cell positions that are visible from a given position. </summary>
		/// <param name="position"> Center position of cell to check visibility for. </param>
		/// <returns> IEnumerable of cell positions </returns>
		public IEnumerable<Vector3Int> VisibleFrom(Vector3 position) { return PeekCell(position)?.visibility; }
		/// <summary> Gets a IEnumerable  of cell positions that are visible from a given cell. </summary>
		/// <param name="position"> Coordinate of cell to check visibility for. </param>
		/// <returns> IEnumerable of cell positions </returns>
		public IEnumerable<Vector3Int> VisibleFrom(Vector3Int cellPos) { return PeekCell(cellPos)?.visibility; }

		/// <summary> Gets the cell for a given position </summary>
		/// <param name="position"> Position of cell to retrieve </param>
		/// <returns> Cell for the given position </returns>
		public Cell CellFor(Vector3 position) { return CellFor(CellPositionFor(position)); }
		/// <summary> Gets the cell for a given cell coordinate </summary>
		/// <param name="position"> Coordinate of cell to retrieve </param>
		/// <returns> Cell for the given coordinate </returns>
		public Cell CellFor(Vector3Int cellPos) {
			if (!cells.ContainsKey(cellPos)) {
				//Debug.Log("Spinning new cell up for [" + cellPos + "]");
				cells[cellPos] = new Cell(this, cellPos);
			}
			return cells[cellPos];
		}


		/// <summary> Gets the cell for a given position, or null if it does not exist. </summary>
		/// <param name="position"> Position of cell to retrieve </param>
		/// <returns> Cell for the given position, or null if it does not exist. </returns>
		public Cell PeekCell(Vector3 position) { return PeekCell(CellPositionFor(position)); }
		/// <summary> Gets the cell for a given position, or null if it does not exist. </summary>
		/// <param name="cellPos"> Position of cell to retrieve </param>
		/// <returns> Cell for the given position, or null if it does not exist. </returns>
		public Cell PeekCell(Vector3Int cellPos) {
			if (!cells.ContainsKey(cellPos)) { return null; }
			return cells[cellPos];
		}

		/// <summary> Gets the coordinate of the cell that <paramref name="position"/> belongs to. </summary>
		/// <param name="position"> Position in worldspace </param>
		/// <returns> Coordinate of <paramref name="position"/> in cell space </returns>
		public Vector3Int CellPositionFor(Vector3 position) { return CellPositionFor(position, cellSize, is3d); }
		/// <summary> Gets the coordinate of the cell that <paramref name="position"/> belongs to, given a specific cellSize </summary>
		/// <param name="position"> Position in worldspace </param>
		/// <param name="cellSize"> Size of cells </param>
		/// <returns> Position of <paramref name="position"/> in cell space </returns>
		public static Vector3Int CellPositionFor(Vector3 position, float cellSize, bool is3d = false) {
			float halfSize = cellSize / 2f;
			Vector3 cell = position;
			if (!is3d) { cell.y = 0; }
			cell += Vector3.one * halfSize;
			cell /= cellSize;
			return Vector3Int.FloorToInt(cell);
		}
		#endregion

	}



	/// <summary> Support class for <see cref="Map"/> to divide a map into cells. </summary>
	public class Cell {

		// <summary> Entity SyncData context </summary>
		//private static SyncData entityData = SyncData.Context("");

		// <summary> Entity Database </summary>
		//private static LocalDB entityDB = DB.Local("content/entities");

		/// <summary> Entities on a given map.  </summary>
		public ConcurrentSet<string> entities;

		/// <summary> Clients connected to a given map </summary>
		public ConcurrentSet<Client> clients;

		/// <summary> Private reference to a list of visible tiles </summary>
		private List<Vector3Int> _visibility = null;

		/// <summary> Accessor for a list of visibility </summary>
		public IEnumerable<Vector3Int> visibility {
			get { return (_visibility == null) 
					? (_visibility = (map.is3d ? Visibility3d(map.cellDist) : Visibility2d(map.cellDist)) ) 
					: _visibility; }
		}

		/// <summary> Position for the cell </summary>
		public Vector3Int cellPos { get; private set; }

		/// <summary> Map that owns the Cell </summary>
		public Map map { get; private set; }

		public Cell(Map map, Vector3Int cellPos) {
			this.map = map;
			this.cellPos = cellPos;
			entities = new ConcurrentSet<string>();
			clients = new ConcurrentSet<Client>();
		}

		/// <summary> Provides a list of 2d cell neighbors for a given <paramref name="position"/> and <paramref name="maxDist"/> </summary>
		/// <param name="position"> Center position to get neighbors for </param>
		/// <param name="maxDist"> Radius of valid neighbors, in cell distance. Defaults to 1, which is enough for a 3x3 grid around the cell. </param>
		/// <returns> Collection of neighbors </returns>
		public List<Vector3Int> Visibility2d(int maxDist = 1) {
			List<Vector3Int> vis = new List<Vector3Int>();
			maxDist = Mathf.Abs(maxDist);
			Vector3Int center = cellPos;

			for (int z = -maxDist; z <= maxDist; z++) {
				for (int x = -maxDist; x <= maxDist; x++) {
					vis.Add(center + new Vector3Int(x, 0, z));
				}
			}

			return vis;
		}

		/// <summary> Provides a list of 3d cell neighbors for a given <paramref name="position"/> and <paramref name="maxDist"/> </summary>
		/// <param name="position"> Center position to get neighbors for </param>
		/// <param name="maxDist"> Radius of valid neighbors, in cell distance. Defaults to 1, which is enough for a 3x3x3 grid around the cell. </param>
		/// <returns> Collection of neighbors </returns>
		public List<Vector3Int> Visibility3d(int maxDist = 1) {
			List<Vector3Int> vis = new List<Vector3Int>();
			maxDist = Mathf.Abs(maxDist);
			Vector3Int center = cellPos;

			for (int z = -maxDist; z < maxDist; z++) {
				for (int y = -maxDist; y < maxDist; y++) {
					for (int x = -maxDist; x < maxDist; x++) {
						vis.Add(center + new Vector3Int(x, y, z));
					}
				}
			}
			
			return vis;
		}


	}
}
