using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

public static class ReflectionUtils {

	public static readonly BindingFlags ALL = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
	public static readonly BindingFlags ALL_STATIC = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
	public static readonly BindingFlags ALL_MEMBER = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

	/// <summary> Returns all of the member void methods within Type <paramref name="t"/> that match the given signature <paramref name="sig"/> </summary>
	/// <param name="t"> Type to inspect </param>
	/// <param name="sig"> Signature to match </param>
	/// <returns> List of all member void methods matching the given signature </returns>
	public static List<MethodInfo> MemberVoidMethods(this Type t, params Type[] sig) {
		return GetMethodsWithSignature(t, ALL_MEMBER, typeof(void), sig);
	}

	/// <summary> Returns all of the static void methods within Type <paramref name="t"/> that match the given signature <paramref name="sig"/> </summary>
	/// <param name="t"> Type to inspect </param>
	/// <param name="sig"> Signature to match </param>
	/// <returns> List of all static void methods matching the given signature </returns>
	public static List<MethodInfo> StaticVoidMethods(this Type t, params Type[] sig) {
		return GetMethodsWithSignature(t, ALL_STATIC, typeof(void), sig);
	}
	/// <summary> Returns all of the static methods within Type <paramref name="t"/> that return <paramref name="returnType"/> and match the given signature <paramref name="sig"/> </summary>
	/// <param name="t"> Type to inspect </param>
	/// <param name="returnType"> Return type to match </param>
	/// <param name="sig"> Signature to match </param>
	/// <returns> List of all static methods that return the given type in the given method. </returns>
	public static List<MethodInfo> MemberMethods(this Type t, Type returnType, params Type[] sig) {
		return GetMethodsWithSignature(t, ALL_MEMBER, returnType, sig);
	}

	/// <summary> Returns all of the static methods within Type <paramref name="t"/> that return <paramref name="returnType"/> and match the given signature <paramref name="sig"/> </summary>
	/// <param name="t"> Type to inspect </param>
	/// <param name="returnType"> Return type to match </param>
	/// <param name="sig"> Signature to match </param>
	/// <returns> List of all static methods that return the given type in the given method. </returns>
	public static List<MethodInfo> StaticMethods(this Type t, Type returnType, params Type[] sig) {
		return GetMethodsWithSignature(t, ALL_STATIC, returnType, sig);
	}

	public static List<MethodInfo> GetMethodsWithSignature(this Type t, BindingFlags flags, Type returnType, params Type[] sig) {
		List<MethodInfo> infos = new List<MethodInfo>();
		var methods = t.GetMethods(flags);
		foreach (var method in methods) {
			if (method.ReturnType != returnType) { continue; }
			var prams = method.GetParameters();
			if (prams.Length != sig.Length) { continue; }
			
			for (int i = 0; i < sig.Length; i++) {
				if (prams[i].ParameterType != sig[i]) {
					goto next;
				}
			}

			infos.Add(method);

			next:
			continue;
		}
		
		return infos;
	}

	public static readonly Type TYPEOF_DELEGATE = typeof(Delegate);

	public static T Delegatize<T>(this MethodInfo info, object target = null) where T : class {
		if (!TYPEOF_DELEGATE.IsAssignableFrom(typeof(T))) {
			return null;
		}
		return (T) (object) info.CreateDelegate(typeof(T), target);
	}
	
	public static void SetField(this object obj, string name, object value) {
		FieldInfo info = obj.GetType().GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
		if (info != null) {
			info.SetValue(obj, value);
		}
	}
	
	
}
