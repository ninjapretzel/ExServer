using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaNet.Utils;

namespace BakaNet.Modules {

	/// <summary> Enables default Encryption on a given client. </summary>
	public class DefaultEncryption : Module {
	
		public DefaultEncryption() {
		
		}

		public override void OnClientAwake(Client c) {
			EncDecInstance ied = new EncDecInstance();
			c.SetEncDec(ied.Encrypt, ied.Decrypt);
		}

		private class EncDecInstance {
			/// <summary> Encryption/Decryption state object </summary>
			private EncDec ed = new EncDec();
			/// <summary> Encrypts a message </summary>
			/// <param name="message"> Byte[] to encrypt </param>
			/// <returns> Encrypted byte[] </returns>
			internal byte[] Encrypt(byte[] message) { return ed.Encrypt(message); }
			/// <summary> Encrypts a message </summary>
			/// <param name="message"> Byte[] to decrypt </param>
			/// <returns> Decrypted byte[] </returns>
			internal byte[] Decrypt(byte[] message) { return ed.Decrypt(message); }
		}
	
	}

}
