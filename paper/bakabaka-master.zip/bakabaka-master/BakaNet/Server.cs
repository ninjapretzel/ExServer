using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Threading;
using System.Reflection;
using BakaNet.Utils;
using System.Net;
using System.Linq;
using BakaBaka;
using BakaBaka.Utils;

namespace BakaNet {
	
	/// <summary> BakaNet Server class. </summary>
	public class Server {

		/// <summary> Class that maintains a server, so long as Unity remains open and running. </summary>
		public class Watcher {
			/// <summary> Service name for the server. </summary>
			public string serviceName { get; private set; }
			/// <summary> Port server is hosted on. </summary>
			public int port { get; private set; }
			/// <summary> Modules to attach server to. </summary>
			public List<Module> modules { get; private set; }

			/// <summary> Server object </summary>
			public Server server { get; private set; }

			public Watcher(string serviceName, int port, List<Module> modules = null) {
				this.serviceName = serviceName;
				this.port = port;
				this.modules = modules;
				
				Task.Run(WatchServer);
			}

			/// <summary> Async loop that watches a server. </summary>
			/// <returns> Running Task </returns>
			private async Task WatchServer() {
				while (true) {
					try {
						if (!Daemon.UnityRunning) {
							Daemon.Log("\\iServer.Watcher: Unity has stopped. ", LogLevel.Lower);
							if (server != null) { server.Stop(); }
							break;
						}

						if (server == null) {
							server = new Server(serviceName, port, modules);
								
						} else {
							if (server.listenTask.Exception != null) { 
								server.Stop();
								throw new Exception("From Listen: ", server.listenTask.Exception); 
							}
							if (server.updateTask.Exception != null) {
								server.Stop();
								throw new Exception("From Update: ", server.updateTask.Exception); 
							}

							if (server.doneStopping) {

								Daemon.Log("\\iServer.Watcher: Attempting to restart Server for [" + serviceName + "] on port " + port + ".", LogLevel.Lower);
								server = new Server(serviceName, port, modules);

							}
								
						}
					} catch (Exception e) {
						Daemon.LogWarning("\\rServer.Watcher: Exception at top level of task:\n" + e.InfoString());
					}

					await Task.Delay(100);
				}
					
			}

		}

		/// <summary> 
		/// Used to make sure a server stays up. 
		/// Servers themselves are fairly transient, but their modules should be designed to persist data in some form. 
		/// </summary>
		/// <param name="serviceName"> Service name of server to maintain. </param>
		/// <param name="port"> Port for server to listen for connections on. </param>
		/// <param name="modules"> Modules to attach to the server. </param>
		/// <returns> <see cref="Server.Watcher"/> object which maintains the server so long as Unity remains running. </returns>
		public static Watcher Maintain(string serviceName, int port, List<Module> modules = null) {
			return new Watcher(serviceName, port, modules);
		}
		

		/// <summary> Helper method terminates a thread if it is not the current thread. </summary>
		/// <param name="t"> Thread to try to terminate </param>
		static void TerminateIfNotActive(Thread t) {
			if (t != null && t != Thread.CurrentThread && t.IsAlive) {
				t.Abort();
			}
		}
		/// <summary> Helper method terminates all threads in the passed array, even if one of them is the current thread </summary>
		/// <param name="threads"> Threads to be terminated. </param>
		static void TerminateAll(params Thread[] threads) {
			foreach (var thread in threads) { TerminateIfNotActive(thread); }
			if (threads.Contains(Thread.CurrentThread)) { Thread.CurrentThread.Abort(); }
		}

		/// <summary> Port assigned to this server instance. </summary>
		public int port { get; private set; }
		/// <summary> Default port value to use if one is not provided. </summary>
		public const int DEFAULT_PORT = 32055;

		/// <summary> Connected clients. </summary>
		public ConcurrentDictionary<int, Client> clients;
		
		/// <summary> Unhandled RPC messages. </summary>
		public ConcurrentQueue<RPCMessage> messages;

		/// <summary> <see cref="TcpListener"/> object listening for connections </summary>
		TcpListener tcpListener;
		/// <summary> Task handling updates for the server object. </summary>
		Task updateTask;
		/// <summary> Task listening for new clients. </summary>
		Task listenTask;

		/// <summary> Name of the 'service' that this server provides. </summary>
		public string serviceName { get; private set; }

		/// <summary> Number of ticks per second. of the server. </summary>
		public static float tickrate = 99;
		
		/// <summary> Miliseconds of delay per server tick. </summary>
		public int tickMilis { get { return (int)(1000f/tickrate); } }

		/// <summary> Miliseconds of delay per message handler iteration. </summary>
		public const int messageMilis = 10;

		/// <summary> Timestamp of last update tick. </summary>
		DateTime lastTick;
		/// <summary> Flag to signal to work tasks that the server has been stopped. </summary>
		public bool stopping { get; private set; }

		/// <summary> Attached modules </summary>
		public List<Module> modules { get; private set; }

		/// <summary>Global counter to give unique ids to each connection.</summary>
		public int nextID = 10000;

		/// <summary> Time the last Update tick actually took to run </summary>
		public int tickTime = -1;

		public bool doneStopping {
			get { return stopping && clients.Count == 0 && !updateTask.IsAlive() && !listenTask.IsAlive(); } 
		} 

		/// <summary>
		/// Creates a BakaNet server with a given service name, on a port, with a given set of modules. 
		/// </summary>
		/// <param name="serviceName"></param>
		/// <param name="port"></param>
		/// <param name="modules"></param>
		public Server(string serviceName, int port, List<Module> modules = null) {
			this.port = port;
			stopping = false;

			messages = new ConcurrentQueue<RPCMessage>();
			clients = new ConcurrentDictionary<int, Client>();

			this.serviceName = serviceName;
			this.modules = modules;
			if (this.modules == null) { this.modules = new List<Module>(); }


			foreach (var module in modules) {
				module.TriggerOnServerAwake(this);
			}
			
			updateTask = Task.Run(UpdateLoop);
			listenTask = Task.Run(ListenForClients);

			Daemon.Log("\\iServer for service *[" + serviceName + "]* Started on port " + port, LogLevel.Lower);
		}

		public Server(string serviceName, List<Module> modules = null) : this(serviceName, DEFAULT_PORT, modules) { }
		
		/// <summary> Checks if Unity stopped, and if it did, stops the server. </summary>
		/// <returns> True if Unity stopped, false if it's still running. </returns>
		private bool DidUnityStop() {
			if (!Daemon.UnityRunning) {
				Daemon.Log("\\iServer for *[" + serviceName + "]* Running after unity closed. Terminating.", LogLevel.Lower);
				if (!stopping) { ((Action)Stop).TryInvoke(); }
				return true;
			}
			return false;
		}

		/// <summary> Sens an RPCMessage to all connected clients. </summary>
		/// <param name="stuff"> Everything to send. Method name first, parameters after. </param>
		/// <remarks> 
		///		ToString's all of the <paramref name="stuff"/>, and then joins it together with <see cref="Client.SEP"/>.
		///		Enqueues the resulting string into the <see cref="Client.outgoing"/> queue for all clients.
		///	</remarks>
		public void Send(params System.Object[] stuff) {
			// More efficient to cache the sent message and enqueue the same string in all of the clients,
			// compared to individual Send() calls.
			// Unfortunately they still all individually encrypt it, but oh well.
			string msg = Client.FormatMessage(stuff);
			
			foreach (var pair in clients) {
				pair.Value.SendMessageDirectly(msg);
			}
		}

		/// <summary> Sens an RPCMessage to all connected clients. </summary>
		/// <param name="clientIDs"> ID values of clients to send to. </param>
		/// <param name="stuff"> Everything to send. Method name first, parameters after. </param>
		/// <remarks> 
		///		ToString's all of the <paramref name="stuff"/>, and then joins it together with <see cref="Client.SEP"/>.
		///		Enqueues the resulting string into the <see cref="Client.outgoing"/> queue for all specified clients.
		///	</remarks>
		public void SendTo(int[] clientIDs, params System.Object[] stuff) {
			// More efficient to cache the sent message and enqueue the same string in all of the clients,
			// compared to individual Send() calls.
			// Unfortunately they still all individually encrypt it, but oh well.
			string msg = Client.FormatMessage(stuff);

			foreach (var id in clientIDs) {
				var client = clients.ContainsKey(id) ? clients[id] : null;
					
				if (client != null) {
					client.SendMessageDirectly(msg);
				}
			}
		}

		//long ticks = 0;
		async Task UpdateLoop() {
			lastTick = DateTime.UtcNow;


			await Task.Delay(tickMilis);
			if (!Daemon.UnityRunning || stopping) { goto finished; }

			while (!stopping) {
				//Daemon.Log("\\iServer Ticking. " + (++ticks), LogLevel.Maximal);
				if (DidUnityStop()) { goto finished; }
				DateTime tickStart = DateTime.UtcNow;
				float delta = (float)(tickStart - lastTick).TotalSeconds;
				NetworkDaemon.lastTickStart = tickStart;
				NetworkDaemon.lastDelta = delta;

				// Tick if ticks are not paused
				if (!Daemon.UnityPaused) {
					// Internal Server Tick
					Tick(tickStart, delta);

					// Tick attached modules
					foreach (var module in modules) {
						if (DidUnityStop()) { goto finished; }
						try {
							module.TriggerUpdate(tickStart, delta);
						} catch (Exception e) {
							Daemon.LogWarning("\\eFailed to trigger update on " + module, e);
						}
					}

				}

				// Handle Messages
				while (messages.Count > 0) {
					if (DidUnityStop()) { goto finished; }

					RPCMessage msg;
					
					if (messages.TryDequeue(out msg)) {
						bool called = false;
						if (msg != null) {
							Daemon.Log("\\bServer calling " + msg.methodName, LogLevel.Maximal);
							foreach (var module in modules) {
								called |= module.SendRPCEvent(msg);
							}
						}

						if (!called) {
							Daemon.LogWarning("\\rServer.Handle: Recieved request for unknown function \"" + msg.methodName + "\"");
						}

						/* Old way of calling RPCs... pretty verbose.
						if (Modules.rpcHandlers.ContainsKey(methodName)) {
							MethodInfo method = Modules.rpcHandlers[methodName];
							BakaNet.Log("Invoking " + method.DeclaringType.Name + "." + method.Name, LogLevel.Normal);

							try {
								method.Invoke(null, new object[] { msg });
							} catch (TargetInvocationException e) {
								StringBuilder str = "Server.Handle: Exception in Module ";
								str = str + method.DeclaringType + "." + methodName;
								str = str + "\nDetails: " + e.InfoString();

								Debug.LogWarning(str);

							} catch (Exception e) {
								Debug.LogWarning("Server.Handle: Something werid happened. Exception raised: " + e.InfoString());
							}
						} else {
							Debug.LogWarning("Server.Handle: Recieved request for unknown function \"" + methodName + "\"");
						}
						//*/

					}
				}
				DateTime tickEnd = DateTime.UtcNow;
				tickTime = (int) (tickEnd - tickStart).TotalMilliseconds;

				lastTick = tickStart;
				
				int delay = Mathf.Clamp(tickMilis - tickTime, 0, 100);
				await Task.Delay(delay);
			} // while(true) 

			finished:
			Daemon.Log("\\bServer.UpdateLoop: Terminated.", LogLevel.Normal);
		}

		/// <summary> Server 'tick' logic. </summary>
		/// <param name="tickStart"> DateTime the current Update tick began at. </param>
		/// <param name="lastDelta"> Delta between the last update tick and this one. </param>
		public void Tick(DateTime tickStart, float lastDelta) {
			// TBD: Any logic that happens outside of modules...
			

		}

		/// <summary> Endless loop to listen for client connections </summary>
		async Task ListenForClients() {
			tcpListener = new TcpListener(IPAddress.Any, port);
			tcpListener.Start();
			try {
				while (!stopping) {
					if (DidUnityStop()) { break; }
					TcpClient conn = await tcpListener.AcceptTcpClientAsync();
					if (DidUnityStop()) { break; }
					if (this == null || conn == null) { break; }
					Client client = new Client(this, conn, modules);
					client.server = this;

					clients[client.id] = client;
					foreach (var module in modules) {
						module.TriggerOnConnected(client);
					}

				}

			} catch (Exception e) {
				if (!stopping) {
					Daemon.LogWarning("\\rServer.ListenForClients: Exception occured.", e);
					Stop();
				}
			}

			
			Daemon.Log("\\bServer.ListenForClients: [" + serviceName + "] Exiting.", LogLevel.Normal);

		}

		/// <summary> Called by a client that is connected to a server when it closes. </summary>
		/// <param name="client"> Client that has been closed. </param>
		// private static readonly byte[] FORCE_DISCONNECT = ("ForceDisconnect"+Client.EOT).ToBytes();
		public void OnClosed(Client client) {
			clients.Remove(client.id);
			foreach (var module in modules) {
				module.TriggerOnDisconnected(client);
			}
		}

		/// <summary> Stops the server, and closes all of its clients. </summary>
		public void Stop() {
			if (stopping) { return; }
			stopping = true;
			tcpListener.Stop();

			List<Client> toClose = new List<Client>();
			foreach (var pair in clients) { toClose.Add(pair.Value); }
			foreach (var client in toClose) {
				client.Close();
			}

			clients.Clear();
			Daemon.Log("\\eServer Stopped.", LogLevel.Lower);
			
			//Task.Run(()=>{ });
		}



	}

}
