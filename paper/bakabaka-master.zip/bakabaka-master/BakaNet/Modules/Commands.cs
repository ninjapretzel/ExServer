using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaBaka;

namespace BakaNet.Modules {
	/// <summary> 
	/// Module for sending/running commands. 
	/// Intended to be used by a chat system to allow admins, moderators, and players to invoke commands.
	/// Commands intended to be run both on client and on server may be registered
	/// </summary>
	public class Commands : Module {

		/// <summary> Login Module providing authorization logic </summary>
		SimpleLogin login;
	
		/// <summary> Map of registered commands. </summary>
		private Dictionary<string, Action<string>> commands = new Dictionary<string, Action<string>>();
	
		/// <summary> RPC for checking if a command can be run. </summary>
		/// <param name="msg"></param>
		public void Command(RPCMessage msg) {
			if (IsServer) {
				string command = msg[0].ToLower();
				if (!login.AUTHZ(msg.client, command)) { return; }
				string param = msg[1];
				commands[command](param);
			}
		}
	
		/// <summary> Adds a command to this Commands Module </summary>
		/// <param name="name"> Name of command </param>
		/// <param name="command"> Callback to execute </param>
		public void Add(string name, Action<string> command) {
			commands[name.ToLower()] = command;
		}

		/// <summary> Runs a command with a given parameter </summary>
		/// <param name="command"> Command to run </param>
		/// <param name="rest"> Parameter for the command to use </param>
		public void RunCommand(string command, string rest) {
			command = command.ToLower();
			if (commands.ContainsKey(command)) {
				commands[command](rest);	

			} else { Daemon.Log("Unknown command [" + command + "].", LogLevel.Lower); }
		
		}


	}

}
