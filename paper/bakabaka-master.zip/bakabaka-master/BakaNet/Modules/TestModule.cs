using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaBaka;

namespace BakaNet.Modules {
	
	public class TestModule : Module {
	
		public TestModule() { }

		public override void OnClientAwake(Client client) {
			if (client.isLocal) {
				Daemon.Log("\\lTest Module: Local Client " + client.identity + " Start", LogLevel.Normal);
			} else {
				Daemon.Log("\\lTest Module: Server Client " + client.identity + " Start", LogLevel.Normal);
			}

		}

		public override void OnServerAwake(Server server) {
			Daemon.Log("\\lTest Module: Server Start", LogLevel.Normal);

		}

		public override void OnConnected(Client client) {
			if (client.isLocal) {
				Daemon.Log("\\uTest Module: Local client connected to server.", LogLevel.Normal);
			} else {
				Daemon.Log("\\uTest Module: " + client.identity + " connected to server.", LogLevel.Normal);
			}
		}

		float timeout = 0;
		public override void Update() {
			timeout += delta;
			if (timeout > 1) {
				Daemon.Log("\\iTest Module: Ticked.", LogLevel.Normal);
				timeout -= 1;
				server.Send("Ping");
			}
		}


		public override void OnDisconnected(Client client) {
			if (client.isLocal) {
				Daemon.Log("\\oTest Module: Local client disconnected from server.", LogLevel.Normal);
			} else {
				Daemon.Log("\\oTest Module: " + client.identity + " disconnected from server.", LogLevel.Normal);
			}
		}


		void Ping(RPCMessage msg) {
			Daemon.Log("\\o" + msg.client.identity + "Ping'd", LogLevel.Lower);
			msg.client.Send("Pong");
		}

		void Pong(RPCMessage msg) {
			Daemon.Log("\\e" + msg.client.identity + "Pong'd", LogLevel.Lower);
		}

	}

}
