using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BakaBaka.Utils {


	public static class TaskUtils {


		/// <summary> 
		///		<para> For Fire-And-Forget task usage. </para>
		///		<para> Watches a task, and makes sure any exceptions that get thrown get handled/logged. </para>
		///	</summary>
		/// <param name="task"> Task to watch </param>
		/// <param name="handler"> Optional handler with additional logic to do. Should be 100% safe. </param>
		/// <remarks>
		///		Always attempts to log with <see cref="Daemon.LogWarning"/>.
		///		Calls the optional <paramref name="handler"/> if provided.
		/// </remarks>
		public static async void Forget(this Task task, Action handler = null) {
			try {
				// ConfigureAwait(false) means don't resume this code in the same context as it was originally called in
				// Then we await it so it gets resumed elsewhere
				await task.ConfigureAwait(false);
			} catch (Exception e) {
				Daemon.LogWarning("Error in fire-and-forget task: " + e.GetType(), e);
				handler?.Invoke();
			}
		}


		/// <summary> Checks that a task is alive, and returns true if it is. </summary>
		/// <param name="task"> Task to check on </param>
		/// <returns> True if the task is running, or waiting in a state where it may run again in the future. </returns>
		public static bool IsAlive(this Task task) {
			var s = task.Status;
			return s == TaskStatus.Running || s == TaskStatus.WaitingForActivation || s == TaskStatus.WaitingForChildrenToComplete || s == TaskStatus.WaitingToRun;
		}

	}

}
