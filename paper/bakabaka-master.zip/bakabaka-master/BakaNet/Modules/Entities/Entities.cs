using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using System.Collections.Concurrent;
using BakaDB;
using LevelUpper.Extensions;
using BakaBaka;
using System.Threading.Tasks;
using System.Threading;

namespace BakaNet.Modules {

	public partial class Entities : Module {

		/// <summary> Minimum distance for accepting client moves (to prevent spam) </summary>
		public static float minMoveDelta = .01f;

		/// <summary> Maximum distance for accepting client moves in one tick (to prevent cheating) </summary>
		public static float maxMoveDelta = 1f;

		/// <summary> Minimum angle in degrees for accepting rotations. </summary>
		public static float minRotDelta = .1f;
		
		/// <summary> Distance where USE actions are allowed </summary>
		public static float useDistance = 10;

		/// <summary> Entity information SyncData context </summary>
		SyncData data;

		// <summary> Map information SyncData context </summary>
		//SyncData mapData;

		/// <summary> Database reference </summary>
		LocalDB users;

		/// <summary> Login module </summary>
		LoginModule loginModule;

		/// <summary> Maps data </summary>
		Maps maps;
	
		/// <summary> Map of active Client objects to entity ids. </summary>
		ConcurrentDictionary<Client, string> clientsToEntityIDs;

		/// <summary> Map of Entity IDs to active clients. </summary>
		ConcurrentDictionary<string, Client> entityIDsToClients;
		
		/// <summary> Callback chain to call when a player entity is spawned on a localClient </summary>
		public Action<Entity> onSpawnPlayerEntity;

		/// <summary> Callback chain when any entity is spawned on a localClient </summary>
		public Action<Entity> onSpawnEntity;

		/// <summary> Callback chain when a non-player entity is spawned on a localClient </summary>
		public Action<Entity> onSpawnNonPlayerEntity;

		/// <summary> Callback chain to initialize player information upon first login </summary>
		public Action<string, JsonObject> onInitializePlayerInfo;

		/// <summary> Callback chain to process player information upon each login </summary>
		public Action<string, JsonObject> onPlayerLogin;

		/// <summary> Callback chain to process map data being recieved on a client. </summary>
		public Action<JsonObject> onClientMapData = EntityManager.UpdateDebugCellData;

		/// <summary> GUID of localClient entity </summary>
		public string localID { get; private set; }

		/// <summary> Data of localClient entity </summary>
		public JsonObject localData { get { return data?.ReadClient(localID) as JsonObject; } }

		/// <summary> JsonObject of local map data </summary>
		public JsonObject localMap { get; private set; }

		// TBD: Hook up this callback in the onLoginSuccessServer action.
		//		Idea is to post-process a freshly logged in client's entity
		//		with new default information based on the needs of different games.
		//public Action<Client, JsonObject> processPlayerEntity;

		/// <summary> Default map to place new users into. </summary>
		public string defaultMap = "training";

		/// <summary> Default position for new users. </summary>
		public Vector3 defaultPosition = new Vector3(0, 0, 0);

		/// <summary> Default rotation for new users. </summary>
		public Quaternion defaultRotation = Quaternion.identity;

		private static int entityCounter = 100000;

		/// <summary> Gets the next ID for a user entity </summary>
		public static string nextUserID { get { return "u" + Interlocked.Increment(ref entityCounter); } }

		/// <summary> Gets the next ID for a non-user entity </summary>
		public static string nextEntityID { get { return "e" + Interlocked.Increment(ref entityCounter); } }
		
		public Entities() {
			data = SyncData.Context("Entities");
		}

		public override void OnServerAwake(Server s) {
			data.useWhitelist = (client, set) => {
				if (clientsToEntityIDs.ContainsKey(client)) {
					return set != clientsToEntityIDs[client];
				}
				return true;
			};
			data.whitelist.Add("position");
			data.whitelist.Add("rotation");
			data.whitelist.Add("velocity");
			data.whitelist.Add("angularVelocity");
			data.whitelist.Add("model");
			data.whitelist.Add("sprite");
			data.whitelist.Add("scale");
			data.whitelist.Add("radius");
			data.whitelist.Add("name");
			data.whitelist.Add("type");
			data.whitelist.Add("colors");

			data.whitelist.Add("usable");

			// for debug...
			data.whitelist.Add("stats");
			data.whitelist.Add("rewards");



			users = DB.Local("users", false);
			loginModule = GetModule<LoginModule>();

			maps = new Maps();
			
			clientsToEntityIDs = new ConcurrentDictionary<Client, string>();
			entityIDsToClients = new ConcurrentDictionary<string, Client>();

			loginModule.onLoginSuccessServer += SpawnPlayer;

		}
		
		/// <summary> Spawns the player object for the given <paramref name="client"/> </summary>
		/// <param name="client"> Client connection for the given player </param>
		void SpawnPlayer(Client client) {

			var creds = loginModule.GetInfo(client);
			string entityID = nextUserID;
			var user = creds.username;
			var file = user + "-EntityInfo.wtf";

			JsonValue record = null;
			if (!users.Check(file, out record)) {
				record = users.Open(file);

				record["map"] = defaultMap;

				record["position"] = Json.Reflect(defaultPosition);
				record["rotation"] = Json.Reflect(defaultRotation);

				try { onInitializePlayerInfo?.Invoke(user, record as JsonObject); }
				catch (Exception e) { Daemon.LogWarning("Error during InitializePlayer callback for " + user, e); }
				
				users.Save(file, record);
			}
			
			try { onPlayerLogin?.Invoke(user, record as JsonObject); }
			catch (Exception e) { Daemon.LogWarning("Error during PlayerLogin callback for " + user, e); }
			
			var name = (record.ContainsKey("nick") ? record["nick"].stringVal : user);
			record["user"] = user;
			record["name"] = name;
			record["type"] = "user";

			clientsToEntityIDs[client] = entityID;
			entityIDsToClients[entityID] = client;
			client.Send("SetGUID", entityID);
			
			data.SetData(entityID, record);

			EnterMap(client, (record as JsonObject).Get<string>("map"));
			
		}

		/// <summary> Called to send a client to another map. 
		/// It is assumed they are already been exited from an existing map, 
		/// and positioned properly before this is called. </summary>
		/// <param name="client"> Client object for connected player </param>
		/// <param name="mapName"> Map name to send them to </param>
		/// <param name="info"> excess information, currently ignored. </param>
		void EnterMap(Client client, string mapName, string info = null) {
			Debug.Log("Client " + client.identity + " has entered map " + mapName);

			// TBD: Look up MapData for mapName, decide to instance or place on persistant
			//		We might need more information on where to place the player if instanced.
			bool instanced = false;

			if (instanced) {
				// TBD: once instanced maps are supported...
			} else {
				Map map = maps.Place(mapName);
				string entityID = clientsToEntityIDs[client];

				map.RegisterEntity(entityID, client);
				client.Send("MapInfo", map.mapInfo);
				JsonObject entityInfo = data.ReadServer(entityID) as JsonObject;
				entityInfo["map"] = mapName;

				//map.UpdateVisibilityForAllCellsThatCanSee(entityPosition);
				UpdateVisibility(client);
			}

		}

		/// <summary> Exits the client's entity from their map. </summary>
		/// <param name="client"> Client object to exit from a map </param>
		void ExitMap(Client client) {

			string entityID = clientsToEntityIDs[client];
			string mapID = data.PullServer(entityID + ".mapID", NO__MAP);
			Map map = maps[mapID];
			map.UnregisterEntity(entityID, client);

			client.Send("MapInfo", "{clear:true}");

		}

		/// <summary> Transfers the client from their current map, to the given position, on the given map. </summary>
		/// <param name="client"> Client to transfer </param>
		/// <param name="mapName"> Map to move to </param>
		/// <param name="position"> Position on new map </param>
		public void Transfer(string clientEntityID, Client client, string mapName, string info, Vector3 position) {

			ExitMap(client);
			
			data.SetData(clientEntityID + ".position", position.ToJson());
			EnterMap(client, mapName, info);
			
			client.Send("RubberBand", position.ToJson());
		}

		public override void OnClientAwake(Client c) {

			if (c.isLocal) {
				// Ensure there is an entityManager present, in case it is not added manually.
				localMap = null;
				
				Daemon.RunOnMainThread(()=> {
					NetworkDaemon.main.Require<EntityManager>();
					
				});


			}

		}

		/// <summary> Unsubscribe or subscribe the given <paramref name="client"/> to sets of data they can see. </summary>
		/// <param name="client"> Client connection for the given player. </param>
		public void UpdateVisibility(Client client) {
			string entityID = EntityIdFor(client);
			Map map = MapFor(client);
			Vector3 position = WorldPosFor(entityID);
			HashSet<string> visible = new HashSet<string>();

			IEnumerable<Vector3Int> neighborhood = map.VisibleFrom(position);
			foreach (var cellPos in neighborhood) {
				Cell cell = map.PeekCell(cellPos);
				if (cell != null) {
					foreach(var id in cell.entities) { visible.Add(id); }
				}
			}
			
			data.DoBatchSub(client, visible);
			
		}

		/// <summary> Get an entityID for a given client </summary>
		/// <param name="client"> Client to get entityID for </param>
		/// <returns> entityID for the given client. </returns>
		public string EntityIdFor(Client client) { return clientsToEntityIDs.ContainsKey(client) ? clientsToEntityIDs[client] : null; }

		/// <summary> Get a client for a given entityID </summary>
		/// <param name="entityID"> EntityID for client </param>
		/// <returns> entityID for the given client, or null if it does not exist  </returns>
		public Client ClientFor(string entityID) { return entityIDsToClients.ContainsKey(entityID) ? entityIDsToClients[entityID] : null; }

		/// <summary> Gets the Map object that the client is on. </summary>
		/// <param name="client"> Client object </param>
		/// <returns> Map Object that the client object is currently on. </returns>
		public Map MapFor(Client client) { return MapFor(clientsToEntityIDs[client]); }

		/// <summary> Gets the world position of an entity. </summary>
		/// <param name="entityID"> ID of entity to get </param>
		/// <returns> World position of the given entity </returns>
		public Vector3 WorldPosFor(string entityID) { return data.PullServer(entityID + ".position", NAN_VECTOR); }

		/// <summary> Gets the Map object that the given entity is on. </summary>
		/// <param name="entityID"> EntityID </param>
		/// <returns> Map Object that the entity is currently on, or null if it does not exist. </returns>
		public Map MapFor(string entityID) {
			var mapID = data.ReadServer(entityID + ".mapID");
			if (mapID != null) {
				return maps[mapID.stringVal];
			}

			return null;
		}

		float backupTimeout = 0;
		float backupTime = 10;
		public override void Update() {
			backupTimeout += delta;
			
			// Ohh this is pretty bad... Triple nested foreach 
			// Perf could get pretty bad with lots of maps / cells ... 
			foreach (var mapPair in maps.live) {
				string id = mapPair.Key;
				Map map = mapPair.Value;
				// Skip maps where nobody is on to save cycles 
				if (map.clients.IsEmpty) { continue; }
				map.Update();

			}

			if (backupTimeout >= backupTime) {
				backupTimeout -= backupTime;

				// One time task which writes a backup. 
				Task.Run(() => {
					SaveUserData();
				});
				//*/

			}

		}

			
		/// <summary> Saves all userdata to the database </summary>
		internal void SaveUserData() {

			foreach (var pair in data.srvJson) {
				var guid = pair.Key;
				var data = pair.Value as JsonObject;

				if (data.ContainsKey("user")) {
					var file = data.Get<string>("user") + "-EntityInfo.wtf";
					users.JustOpen(file);
					JsonObject record = data.DeepCopy() as JsonObject;
					record["mapID"] = null;

					users.Save(file, record);
				}
			}
		}

		public override void OnConnected(Client c) {

			if (c.isLocal) {


			} else {

			}

		}

		public override void OnDisconnected(Client client) {

			if (IsServer) {
				Client _c;
				string _s;

				string entityID = clientsToEntityIDs[client];

				//var entityData = data.ReadServer(entityID) as JsonObject;
				// TBD: Uncomment above line and do more cleanup?

				ExitMap(client);

				
				clientsToEntityIDs.TryRemove(client, out _s);
				entityIDsToClients.TryRemove(entityID, out _c);

				data.SetData(entityID, null);
				// TBD: Other cleanup?


			} 

			if (client.isLocal) {

			}

		}

		/// <summary> Vector holding only <see cref="float.NaN"/> </summary>
		public static readonly Vector3 NAN_VECTOR = new Vector3(float.NaN, float.NaN, float.NaN);

		/// <summary> NO MAP assigned. </summary>
		public static readonly string NO__MAP = "NO_MAP";

		/// <summary> Full logic for entity movement. </summary>
		/// <param name="entityID"> EntityID to move  </param>
		/// <param name="pos"> new position, or null to not update it </param>
		/// <param name="rot"> new rotation, or null to not update it </param>
		/// <param name="vel"> new velocity, or null to not update it </param>
		/// <param name="angVel"> new angularVelocity, or null to not update it </param>
		public void MoveUpdate(string entityID, JsonValue pos = null, JsonValue rot = null, JsonValue vel = null, JsonValue angVel = null) {

			string mapID = data.PullServer(entityID + ".mapID", NO__MAP);
			Client client = entityIDsToClients.ContainsKey(entityID) ? entityIDsToClients[entityID] : null;

			if (mapID != NO__MAP) {
				var map = maps[mapID];
				if (map != null) {
					
					if (angVel != null) {
						data.SetData(entityID + ".angularVelocity", angVel);
					}

					if (vel != null) {
						data.SetData(entityID + ".velocity", vel);
					}
					
					if (rot != null) {
						Quaternion oldRot = Json.GetValue<Quaternion>(data.ReadServer(entityID + ".rotation"));
						Quaternion newRot = Json.GetValue<Quaternion>(rot);

						if (Quaternion.Angle(oldRot, newRot) > minRotDelta) {
							data.SetData(entityID + ".rotation", rot);
						}
					}

					if (pos != null) {	
						Vector3 oldPos = Json.GetValue<Vector3>(data.ReadServer(entityID + ".position"));
						Vector3 newPos = Json.GetValue<Vector3>(pos);
						MoveEntity(map, entityID, client, oldPos, newPos);
					}
						

				} else { Daemon.LogWarning("Entity [" + entityID + "]'s map is null. Cannot move across cells it."); }
			} else { Daemon.LogWarning("Entity [" + entityID + "] does not have a map. Cannot move it."); }

		}

		/// <summary> Starts a task that moves the given entity, transitioning it between cells if needed. </summary>
		/// <param name="map"> Map object containing the cells </param>
		/// <param name="entityID"> ID of entity to move </param>
		/// <param name="client"> Client object. null if not a user. </param>
		/// <param name="oldPos"> old world position </param>
		/// <param name="newPos"> new world position </param>
		/// <param name="serverMove"> Has this move originated from the server? </param>
		public void MoveEntity(Map map, string entityID, Client client, Vector3 oldPos, Vector3 newPos, bool serverMove = false) {
			Task.Run(() => {
				MoveEntityNow(map, entityID, client, oldPos, newPos, serverMove);
			});
		}

		/// <summary> Logic to actually move an entity immediately. </summary>
		/// <param name="map"> Map object containing the cells </param>
		/// <param name="entityID"> ID of entity to move </param>
		/// <param name="client"> Client object. null if not a user. </param>
		/// <param name="oldPos"> old world position </param>
		/// <param name="newPos"> new world position </param>
		/// <param name="serverMove"> Has this move originated from the server? </param>
		public void MoveEntityNow(Map map, string entityID, Client client, Vector3 oldPos, Vector3 newPos, bool serverMove = false) {
			var diff = (oldPos - newPos).magnitude;
			if (serverMove || (diff > minMoveDelta && diff < maxMoveDelta)) {
				data.SetData(entityID + ".position", newPos);

				Vector3Int oldCellPos = map.CellPositionFor(oldPos);
				Vector3Int newCellPos = map.CellPositionFor(newPos);
				if (newCellPos != oldCellPos) {

					Cell oldCell = map.CellFor(oldCellPos);
					Cell newCell = map.CellFor(newCellPos);

					oldCell.entities.Remove(entityID);
					newCell.entities.Add(entityID);

					if (client != null) {
						oldCell.clients.Remove(client);
						newCell.clients.Add(client);
					}

					HashSet<Client> oldVis = map.ClientsWhoCanSee(oldCellPos);
					HashSet<Client> newVis = map.ClientsWhoCanSee(newCellPos);

					foreach (var c in oldVis) {
						if (!newVis.Contains(c)) { data.DoUnsubscribe(c, entityID); }
					}
					foreach (var c in newVis) {
						if (!oldVis.Contains(c)) { data.DoSubscribe(c, entityID); }
					}
					
				}

				if (client != null) {

					UpdateVisibility(client);
					if (serverMove) {
						JsonObject targetPos = Json.Reflect(newPos) as JsonObject;
						client.Send("RubberBand", targetPos);
					}
				}

			} else { 
				// TBD: More robust detection for sending RubberBand messages
				//		(Server side solids)
				if (client != null && diff > maxMoveDelta) {
					JsonObject targetPos = Json.Reflect(serverMove ? newPos : oldPos) as JsonObject;
					client.Send("RubberBand", targetPos);
				}
			}

		}
		
		
		/// <summary> RPC, Server->Client, informs the client of their assigned entity GUID. </summary>
		/// <param name="msg"> RPC Message info </param>
		void SetGUID(RPCMessage msg) {
			localID = msg[0];
			Debug.Log("Client recieved entity GUID of " + localID);
		}


		/// <summary> RPC, Server->Client, tells the client to move to a position </summary>
		/// <param name="msg"> RPC Message info </param>
		void RubberBand(RPCMessage msg) {
			Vector3 pos = Json.To<Vector3>(msg[0]);
			Daemon.RunOnMainThread(() => {
				if (Entity.localEntity != null) {
					Entity.localEntity.RubberBand(pos);

				}

			});
		}

		/// <summary> RPC, Server->Client, Provides the client information for the map he's in. </summary>
		/// <param name="msg"> RPC Message info </param>
		void MapInfo(RPCMessage msg) {
			JsonObject obj = Json.Parse(msg[0]) as JsonObject;
			if (obj.Has("clear")) {
				Debug.Log("Clearing Map Data");
				localMap = null;

			} else {
				Debug.Log("Setting Map Data: " + obj.ToString());

				localMap = obj;

				onClientMapData(obj);
			}
		}


		/// <summary> RPC, Client->Server, asks the server to please move the client's position. </summary>
		/// <param name="msg"> RPC Message info </param>
		void Move(RPCMessage msg) {
			if (clientsToEntityIDs.ContainsKey(msg.client)) {

				string entityID = clientsToEntityIDs[msg.client];

				JsonObject updateData = Json.To<JsonObject>(msg[0]);
				JsonValue pos = updateData["position"];//Pull<JsonValue>("position", null);
				JsonValue rot = updateData["rotation"];//.Pull<JsonValue>("rotation", null);
				JsonValue vel = updateData["velocity"];//.Pull<JsonValue>("velocity", null);
				JsonValue angVel = updateData["angularVelocity"];//.Pull<JsonValue>("angularVelocity", null);

				MoveUpdate(entityID, pos, rot, vel, angVel);

			} else {
				Daemon.LogWarning("Client " + msg.client.identity + " does not have an entity.");
			}

		}

		/// <summary> RPC, Client->Server, asks the server to have the current entity use the target entity. </summary>
		/// <param name="msg"></param>
		void Use(RPCMessage msg) {
			if (clientsToEntityIDs.ContainsKey(msg.client)) {

				string targetID = msg[0];
				string useAction = msg.numArgs > 1 ? msg[1] : "use";
				string instigatorID = clientsToEntityIDs[msg.client];
				string mapID = data.PullServer(instigatorID + ".mapID", NO__MAP);
				TryUse(targetID, instigatorID, useAction, mapID);

			} else {
				Daemon.LogWarning("Client " + msg.client.identity + " does not have an entity.");
			}

		}

		/// <summary> Kicks off the task that has one entity use another. </summary>
		/// <param name="instigatorID"> Entity instigating the use </param>
		/// <param name="targetID"></param>
		/// <param name="mapID"></param>
		private void TryUse(string targetID, string instigatorID, string useAction, string mapID) {
			Task.Run(() => {
				try {
					Map map = maps[mapID];

					if (map != null && map.entities.Contains(targetID)) {
						JsonObject edata = data.ReadServer(instigatorID) as JsonObject;
						JsonObject tdata = data.ReadServer(targetID) as JsonObject;
						Vector3 epos = edata.GetV3("position");
						Vector3 tpos = tdata.GetV3("position");

						if ((epos - tpos).magnitude < useDistance) {
							JsonObject usable = tdata["usable"] as JsonObject;

							if (usable != null && usable.ContainsKey(useAction)) {
								if (Map.onUsedFunctions.ContainsKey(useAction)) {
									var func = Map.onUsedFunctions[useAction];
									func?.Invoke(map, targetID, instigatorID);
								}
							}

						} else {
							Daemon.Log("Entity " + instigatorID + " tried to use " + targetID + " but was too far away", LogLevel.Normal);
						}

					} else {
						Daemon.Log("Entity " + instigatorID + " tried to use " + targetID + " that doesn't exist on their map!", LogLevel.Normal);
					}

				} catch (Exception e) {
					Daemon.LogWarning("Error ocurred while entity " + instigatorID + " used " + targetID, e);
				}
			});
		}

		public override void DrawIMGUI(Rect area) {
			Rect brush = area;
			brush.height = 20;
			GUI.Label(brush, "Local GUID: " + (localID ?? "NONE") );
			brush.y += brush.height;

			if (IsServer) {
				GUI.Label(brush, "Maps!!!");
				brush.y += brush.height;
				brush.height *= 6;
				foreach (var pair in maps.live) {
					Map map = pair.Value;
					string mapID = pair.Key;

					StringBuilder str = map.name + " ( " + mapID + ")";
					str = str + (map.clients.IsEmpty ? "Inactive" : "Active");
					str = str + "\nUpdate (ms): " + map.updateTrend;
					str = str + "\nCollide (ms): " + map.collideTrend;
					str = str + "\nDespawn (ms): " + map.despawnTrend;
					str = str + "\nSpawn (ms): " + map.spawnTrend;

					GUI.Box(brush, str.ToString());
					brush.y += brush.height;
				}
			}
		}


	}

}
