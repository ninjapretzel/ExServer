using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet.Utils;
using LevelUpper.Markdown;
using System.Collections.Concurrent;
using LevelUpper.Extensions;
using BakaNet.Modules;
using System.IO;
using System.Linq;

namespace BakaNet { 
	public class NetworkDaemon : MonoBehaviour {
	
		/// <summary> Static reference to the singleton NetworkDaemon at any time. </summary>
		public static NetworkDaemon main;
	
		/// <summary> Is this a server? (Only allowed in the editor) </summary>
		#if !UNITY_EDITOR
		public bool isServer { get { return false; } }
		#else
		public bool isServer = false;
#endif
		/// <summary> Load host from file? (Only has effect outside of editor.)</summary>
		[Tooltip("Load host from file? (Only has effect outside of editor.)")]
		public bool loadHostFile = false;
		/// <summary> Name of host file to load outside of editor </summary>
		public string hostFile = "./host.wtf";

		/// <summary> What is the name of the service? </summary>
		public string serviceName = "Main";
		/// <summary> What is the remote host to connect to? </summary>
		public string remoteHost = "1.2.3.4";
		/// <summary> What port is used to connect over? </summary>
		public int port = 55555;

		/// <summary> </summary>
		public float maxMoveDelta = 1f;

		/// <summary> Function chain to call beforeall other GUI gets rendered </summary>
		public Action PreOnGUI; 
		/// <summary> Function chain to call after all other GUI has been rendered </summary>
		public Action PostOnGUI;

		/// <summary> Gets the first module of type <typeparamref name="T"/> </summary>
		/// <typeparam name="T"> Generic Module Type </typeparam>
		/// <returns> First Module of type <typeparamref name="T"/> attached to a Server or Client object related to this Module, or null if none are. </returns>
		public T GetModule<T>() where T : Module {
			return Module.GetModule<T>(modules);
		}

		/// <summary> Server Watcher instance </summary>
		protected Server.Watcher swatcher;
		/// <summary> Client Watcher instance </summary>
		protected Client.Watcher cwatcher;

		/// <summary> Current server instance </summary>
		public Server server { get { return swatcher?.server; } } 

		/// <summary> Current local client </summary>
		public Client localClient { get { return cwatcher?.client; } }
	
		/// <summary> Networking modules </summary>
		protected List<Module> modules;

		/// <summary> Is the debugging GUI open? </summary>
		public bool guiOpen = false;

		/// <summary> Should higher latency be simulated via delays? </summary>
		public bool debug_highLatency = false;

		/// <summary> Debug Map/Cell colliders? </summary>
		public bool debug_collisions = false;

		/// <summary> Debug cells? </summary>
		public bool debug_cells = true; 
	
		public static float lastDelta = 0f;
		public static DateTime lastTickStart = DateTime.MaxValue;
		
		void Awake() {
			if (main != null) { Destroy(gameObject); return; }
			DontDestroyOnLoad(gameObject);
			main = this;

				JsonObject.DictionaryGenerator = ()=>{ return new ConcurrentDictionary<JsonString, JsonValue>(); };
			
#if UNITY_EDITOR
			loadHostFile = false;
#endif

			if (loadHostFile) {
				if (File.Exists(hostFile)) {
					remoteHost = File.ReadAllLines(hostFile)[0];
				}
			}

			Action lowLatency = ()=>{
				Client.handleDelay = 1;
				Client.recieveDelay = 1;
				Client.sendDelay = 1;
				Server.tickrate = 55;
			};
			if (!debug_highLatency) { lowLatency(); }

		}
	
		public virtual void Start() {

			if (modules == null) {

				modules = new List<Module> {
					SyncData.Context("Debug"),
					new TestModule(),

					new SimpleLogin(),
					new SimpleChat(),

					//new Base64Armor(),
					new DefaultEncryption(),
			
					//new ClickerModule(),

				};

			}

			if (isServer) {
			
				swatcher = Server.Maintain(serviceName, port, modules);
				//server = new Server(serviceName, port);
				remoteHost = "127.0.0.1";

			}
			Debug.Log("Starting up for connecting to " + remoteHost + ":" + port);

			cwatcher = Client.Maintain(remoteHost, port, modules);

		}

		float timeout = 0;
		public virtual void Update() {
			timeout += Time.deltaTime;
			if (timeout > 5) {

			}
			

			Map.DRAW_COLLISION_DEBUG = debug_collisions;
		}

		/// <summary> Sends an RPCMessage through the localClient. </summary>
		/// <param name="stuff"> Content of message to send. </param>
		public void SendToServer(params object[] stuff) {
			localClient?.Send(stuff);
		}


		public float openModuleHeight = 400;
		public float moduleWidth = 400;
		Vector2 scroll;
		private void OnGUI() {
			GUI.skin = Resources.Load<GUISkin>("Standard");
			PreOnGUI?.Invoke();

			GUI.color = Color.white.Alpha(guiOpen ? 1 : .35f);
			if (GUI.Button(new Rect(0,0,20,20), guiOpen ? "-" : "+")) { guiOpen = !guiOpen; }
		
			if (guiOpen) {
				Rect b = new Rect(20, 0, 100, 20);
				if (GUI.Button(b, "Close Client")) {
					Debug.Log("\\rLOL OKAY CLOSING \\yCLIENT".ReplaceColors());
					cwatcher.client.Close();
				}

				b.y += b.height;
				if (GUI.Button(b, "Close Server")) {
					Debug.Log("\\rLOL OKAY CLOSING \\oSERVER".ReplaceColors());
					swatcher.server.Stop();
				}
				if (isServer) {

					b.y += b.height;
					b.height *= 3;
					GUI.Label(b, "Last Tick Time: \n" + swatcher.server.tickTime + "ms");
				}
			
				int openCnt = modules.Where(m=>m.open).Count();
				int closedCnt = modules.Count - openCnt;
				float totalHeight = openCnt * openModuleHeight + closedCnt * Module.TOP_SIZE;

				Rect scrollArea = new Rect(b.xMax, 0, moduleWidth + 24, Screen.height);
				Rect scrollView = new Rect(0, 0, moduleWidth, totalHeight);
				
				scroll = GUI.BeginScrollView(scrollArea, scroll, scrollView, false, true); {
				
					Rect brush = new Rect(0, 0, moduleWidth, Module.TOP_SIZE);

					foreach (var module in modules) {
						brush.height = (module.open) ? openModuleHeight : Module.TOP_SIZE;
						module.OnGUI(brush);
						brush.y += brush.height;
					}

				} GUI.EndScrollView();

			}

			PostOnGUI?.Invoke();
		}

	}

}
