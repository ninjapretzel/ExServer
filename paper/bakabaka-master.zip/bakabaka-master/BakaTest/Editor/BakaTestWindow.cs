#if UNITY_EDITOR && !UNITY_WEBPLAYER
using UnityEngine;
using UnityEditor;
using System;
using System.Linq;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using BakaTest;
using System.Reflection;
using LevelUpper.Extensions;

namespace LevelUpper.Editor {

	public class BakaTestWindow : EditorWindowLevelUpper {
		
		[MenuItem("Baka/Test Window")]
		public static void ShowWindow() { 
			EditorWindow.GetWindow(typeof(BakaTestWindow)); 
		}
		
		public BakaTestWindow() {
			
		}
		
		TestResultGroup[] groups;
		TestsResult result;

		Vector2 scroll;
		[SerializeField] public bool autorunTests = false;

		void OnGUI() { 
			if (Button("Run Tests")) {
				scroll = Vector2.zero;
				RunTests();
			}
			autorunTests = Toggle(autorunTests, "Auto-Run Tests");

			if (result != null) {
				
				Box("", ExpandWidth(true));
				Rect a = GUILayoutUtility.GetLastRect();

				float w = a.width;

				float p = result.totalSuccess;
				p /= result.totalCount;
				float f = 1.0f - p;
				GUI.color = Color.green;
				GUI.Box(a.Left(p), "");

				GUI.color = Color.red;
				GUI.Box(a.Right(f), "");

				GUIStyle style = new GUIStyle(GUI.skin.label);
				style.alignment = TextAnchor.MiddleCenter;

				GUI.color = new Color(1,1,1,.5f);
				GUI.Box(a, $"{result.totalSuccess} / {result.totalCount}");

				GUI.color = Color.white;
			}
			scroll = BeginScrollView(scroll, false, true); {

				if (groups.Length == 0) {
					Label("No Tests Run Yet.");
				}

				foreach (var group in groups) {
					DrawGroup(group);
				}

			} EndScrollView();
		}

		void Update() { }
		void OnInspectorUpdate() { }

		void OnEnable() {
			if (groups == null) {
				groups = new TestResultGroup[0];
			}

			if (autorunTests) {
				RunTests();
			}

		}
		
		void OnFocus() { }
		void OnLostFocus() { }

		void OnSelectionChange() { }
		void OnHierarchyChange() { }
		void OnProjectChange() { }
		
		void OnDestroy() { }

		void RunTests() {
			
			var testAssembly = Assembly.GetAssembly(typeof(BakaTests));
			var testTypes = testAssembly.DefinedTypes
				.Where(t => t.Name.EndsWith("_Tests")).ToArray();
			JsonObject result = null;
			
			try {
				result = BakaTests.RunTests(testTypes);
			} catch (Exception e) {
				UnityEngine.Debug.LogError($"Failed to run tests");
				UnityEngine.Debug.LogError(e);
			}

			try {
				this.result = Json.GetValue<TestsResult>(result);
				groups = this.result.groups;

			} catch (Exception e) {
				groups = new TestResultGroup[0];

				UnityEngine.Debug.LogError($"Failed to Convert TestResults...");
				UnityEngine.Debug.LogError(e);
			}

		}
		
		private void DrawGroup(TestResultGroup group) {
			Color color = group.status == "success" ? Color.green : Color.red;
			float width = position.width - 32;
			GUI.color = Color.Lerp(color, Color.white, .85f);
			BeginVertical("box", ExpandWidth(false), Width(width)); {
				GUI.color = Color.Lerp(color, Color.white, .5f);
				BeginHorizontal("box"); {
					GUI.color = Color.white;

					Label(group.type);
					FlexibleSpace();
					
					Label($"Time: {group.totalTime} (t {group.testTime}) (c {group.cleanupTime})");
					FlexibleSpace();

					Label($"{group.success} / {group.count}");

					if (Button(group.expanded ? "-" : "+", Width(32))) { group.ToggleExpand(); }
				} EndHorizontal();

				if (group.expanded) {
				
					foreach (var result in group.results) {

						DrawResult(result);

					}

				}

			} EndVertical();
		}

		public void DrawResult(TestResult result) {
			Color color = result.success ? Color.green : Color.red;
			GUI.color = Color.Lerp(color, Color.white, .75f);

			BeginHorizontal("box"); {
				
				GUI.color = Color.white;
				Label(result.time == null ? "" : (result.time), Width(64));
				Label(result.cleanupTime == null ? "" : (result.cleanupTime), Width(64));

				Label(result.name);

				FlexibleSpace();

				if (!result.success) {
					if (Button(result.expanded ? "-" : "+", Width(32))) { result.ToggleExpand(); }
				}

			} EndHorizontal();

			if (result.expanded) {

				if (result.message != null) {
					Label("Message:");
					LabelWithWordWrap(result.message);
				}

				if (result.stack != null) {
					Label("Stack:");
					LabelWithWordWrap(result.stack);
				}

				if (result.inner != null) {
					Label("Inner:");
					LabelWithWordWrap(result.inner);
				}

			}

		}
		
		public void LabelWithWordWrap(string label) {
			GUIStyle wrapper = new GUIStyle(GUI.skin.label);
			wrapper.wordWrap = true;
			GUILayout.Label(label, wrapper, ExpandWidth(false));
		}

	}

	public class TestsResult {
		public TestResultGroup[] groups;
		public int totalCount;
		public int totalSuccess;
		public int totalFailure;
	}

	public class TestResultGroup {
		public string type;
		public string status;
		public string totalTime;
		public string testTime;
		public string cleanupTime;
		public int count;
		public int failure;
		public int success;
		public TestResult[] results;
		public bool expandToggled = false;
		public bool isSuccess { get { return failure == 0; } }
		public bool expanded { get { return isSuccess ? expandToggled : !expandToggled; } }
		public void ToggleExpand() { expandToggled = !expandToggled; }
	}

	public class TestResult {
		public string name;
		public bool success;
		public string time;
		public string cleanupTime;
		public string message;
		public string stack;
		public string inner;
		private bool expandToggled = false;
		public bool expanded { get { return success ? expandToggled : !expandToggled; } }
		public void ToggleExpand() { expandToggled = !expandToggled; }
	}

	
}
#endif
