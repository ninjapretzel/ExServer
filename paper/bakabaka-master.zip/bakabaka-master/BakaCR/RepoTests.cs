using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaDB;
using BakaCR;
using System.Linq;
using BakaNet.Modules;
using BakaTest;

public static class Repo_Tests {

	public static readonly string TEST_DB_NAME = "TestRepository";

	public static Repository testRepo { get { return Repository.Local(TEST_DB_NAME); } }

	public static void Clean() {
		Repository.Drop(TEST_DB_NAME);
		
	}

	public static void SetupEmpty() {

	}
	public static string StupidHash(string pass) {
		return ":\\:" + (pass + "IM A STUPID HACKER DECOMPILING YOUR CODE LOL").GetHashCode() + ":/:";
	}

	private static readonly string[] USERNAMES = new string[]{
		"Billy", "Bob", "Joe", "Fred", "Saget", 
		"Reimu", "Marissa", "Flandere", "Remilia", "China", "Chen", "Awoo", "Momiji",
	};
	private static readonly string LOGIN_DATE = "1530137749179";

	public static void SetupTestUsers() {
		Node users = testRepo.Set("users");

		USERNAMES.ToList().ForEach((string name) => { 
			Node n = users.Set(name);
			string pass = StupidHash(name);
			
			n.Put("hash", pass);
			n.Put("lastLogin", LOGIN_DATE);
		});

		testRepo.root.Close();
		testRepo.__Reinitialize();
	}

	public static void TestDefaultInfos() {
		SetupEmpty();
		
		bool has;
		int version;

		Node root = testRepo.Get("/");
		has = root.Has("version");	has.ShouldBe(true);
		version = root.Pull<int>("version", -1);
		version.ShouldBe(0);

		has = root.Has("guid");		has.ShouldBe(true);
		has = root.Has("data");		has.ShouldBe(false);
		
		root.Set("data", "woah");
		has = root.Has("data");		has.ShouldBe(true);
		version = root.Pull<int>("version", -1);
		version.ShouldBe(1);

		root.Save();
		version = root.Pull<int>("version", -1);
		version.ShouldBe(2);
	}

	public static void TestFolders_Set() {
		SetupEmpty();

		Node root = testRepo.Get("/");
		// Call set with null value (implicit) to create a folder object.
		Node folder = root.Set("folder");
		Node file = folder.Set("file");
		
		// Setting a property should return the node it was set on.
		Node alsoFile = testRepo.Set("folder/file/key", "value");
		// Should get back same node.
		file.ShouldBe(alsoFile);

	}

	public static void TestFolders_Put() {
		SetupEmpty();

		Node root = testRepo.Get("/");
		// Call set with null value (implicit) to create a folder object.
		Node folder = root.Put("folder");
		Node file = folder.Put("file");

		// Setting a property should return the node it was set on.
		Node alsoFile = testRepo.Put("folder/file/key", "value");
		// Should get back same node.
		file.ShouldBe(alsoFile);

	}

	public static void TestHasses_Set() {
		SetupEmpty();
		
		Node root = testRepo.Get("/");
		// Call set with null value (implicit) to create a folder object.
		Node folder = root.Set("folder");
		Node file = folder.Set("file");
		Node alsoFile = testRepo.Set("folder/file/key", "value");

		bool has;
		has = root.Has("folder/file/key");	has.ShouldBe(true);
		has = folder.Has("file/key");		has.ShouldBe(true);
		has = file.Has("key");				has.ShouldBe(true);

	}

	public static void TestHasses_Put() {
		SetupEmpty();

		Node root = testRepo.Get("/");
		// Call set with null value (implicit) to create a folder object.
		Node folder = root.Put("folder");
		Node file = folder.Put("file");
		Node alsoFile = testRepo.Put("folder/file/key", "value");

		bool has;
		has = root.Has("folder/file/key"); has.ShouldBe(true);
		has = folder.Has("file/key"); has.ShouldBe(true);
		has = file.Has("key"); has.ShouldBe(true);

	}
	
	public static void TestNodeInvalidation() {
		SetupEmpty();

		Node root = testRepo.Get("/");
		Node blah = testRepo.Set("blah");

		blah.Set("x", 10);
		blah.Set("y");
		blah.Close();
		
		blah.ShouldBeInvalid();
		root.ShouldBeValid();

		testRepo.Close();
		
		root.ShouldBeInvalid();

	}

	public static void TestChildCount() {
		SetupTestUsers();

		Node root = testRepo.Get("/");
		Node users = root.Get("users");

		// Files for all users should be present.
		users.GetChildren().Count().ShouldBe(USERNAMES.Length);
		// No users should be loaded.
		users.children.Count.ShouldBe(0);
		
		// Loading a relative path
		string login = users.Pull("Reimu/lastLogin", "-1");
		// Should load that child
		users.children.Count.ShouldBe(1);
		// And retrieve the value properly.
		login.ShouldBe(LOGIN_DATE);

		// Retrieving information other way should also work
		Node user = users.Get("Reimu");
		user.ShouldNotBe(null);
		string login2 = user.properties["lastLogin"].stringVal;
		login2.ShouldBe(LOGIN_DATE);
		
	}

	public static void TestNodeReloading1() {
		SetupTestUsers();

		Node root = testRepo.Get("/");
		Node users = root.Get("users");

		users.children.Count.ShouldBe(0);
		Node user1, user2, user3; 

		user1 = users.Get("Awoo");
		user2 = users.Get("Momiji");
		user3 = users.Get("Chen");
		users.children.Count.ShouldBe(3);

		testRepo.Reload("users");

		user1.ShouldBeInvalid();
		users.ShouldBeInvalid();
		root.ShouldBeValid();

		users = testRepo.Get("/users");
		users.children.Count.ShouldBe(0);

		user1 = users.Get("Awoo");
		user2 = users.Get("Momiji");
		user3 = users.Get("Chen");
		users.children.Count.ShouldBe(3);

		Node user1old = user1;
		user1 = user1.Reload();
		user1.ShouldNotBe(user1old);

		user1.ShouldBeValid();
		user1old.ShouldBeInvalid();
		users.ShouldBeValid();
		users.ShouldBeValid();
		users.children.Count.ShouldBe(3);

	}

	public static void TestNodeReloading2() {
		SetupTestUsers();
		Node root = testRepo.Get("/");
		Node users = root.Get("users");

		users.children.Count.ShouldBe(0);
		Node user1, user2, user3;

		user1 = users.Get("Awoo");
		user2 = users.Get("Momiji");
		user3 = users.Get("Chen");
		users.children.Count.ShouldBe(3);

		root.Close();

		user1.ShouldBeInvalid();
		users.ShouldBeInvalid();
		root.ShouldBeInvalid();
		testRepo.__Reinitialize();
		
		user3.ShouldBeInvalid();
		root.ShouldBeInvalid();

		root = testRepo.root;
		root.ShouldBeValid();
		user2.ShouldBeInvalid();


	}




	private static void ShouldBeValid(this Node node) {
		Node got = node.Get("y");
		Node set = node.Set("x", 50);
		Node put = node.Put("x", 500);
		bool has = node.Has("y");
		int pulled = node.Pull("version", -1);

		int ChildCount = node.GetChildren().Count();

		// Not going to close/reload node...
	}


	private static void ShouldBeInvalid(this Node node) {

		Action get = () => { node.Get("y"); };
		Action set = () => { node.Set("x", 50); };
		Action put = () => { node.Put("x", 500); };
		Action has = () => { node.Has("y"); };
		Action pull = () => { node.Pull("version", -1); };

		Action getChildren = () => { node.GetChildren(); };

		Action close = () => { node.Close(); };
		Action reload1 = () => { node.Reload(); };
		Action reload2 = () => { node.Reload("y"); };

		get.ShouldThrow<InvalidOperationException>();
		set.ShouldThrow<InvalidOperationException>();
		put.ShouldThrow<InvalidOperationException>();
		has.ShouldThrow<InvalidOperationException>();
		pull.ShouldThrow<InvalidOperationException>();
		
		getChildren.ShouldThrow<InvalidOperationException>();

		close.ShouldThrow<InvalidOperationException>();
		reload1.ShouldThrow<InvalidOperationException>();
		reload2.ShouldThrow<InvalidOperationException>();

	}

}

