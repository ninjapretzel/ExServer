using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using BakaNet;
using BakaBaka;
using LevelUpper.Extensions;
using BakaNet.Utils;

namespace BakaNet.Modules {


	public class SimpleChat : Module {

		/// <summary> Information server uses to give people nicknames </summary>
		public SimpleLogin loginModule;

		/// <summary> Information server uses to track chat channels </summary>
		public ClientGroups channels;

		/// <summary> History of messages received from the server </summary>
		public List<string> history;

		/// <summary> Maximum number of messages to keep in the logs. </summary>
		public int maxMessages = 1024;

		/// <summary> Reference to the commands object. </summary>
		public Commands commands = null;

		/// <summary> Callback to hook up functions to run when messages are received on a local client </summary>
		public Action<string, string> onMessage = null;

		/// <summary> Current group the local client is talking to </summary>
		public string activeLocalGroup = "global";

		/// <summary> Says the given message. </summary>
		public void Say(string message) { localClient.Send("ChatMessage", activeLocalGroup, message, "say"); }

		/// <summary> Emotes a given message </summary>
		public void Emote(string message) { localClient.Send("ChatMessage", activeLocalGroup, message, "me"); }

		public override void OnServerAwake(Server server) {
			// Server-side initialization
			channels = new ClientGroups();

			loginModule = GetModule<SimpleLogin>();



		}

		public override void OnClientAwake(Client c) {

			if (c.isLocal) {
				history = history ?? new List<string>();
				RegisterCommands();
				// Local-Client initialization

			}
			// Common Client initialization

		}

		private void RegisterCommands() {
			commands = GetModule<Commands>();

			commands.Add("me", s => Emote(s));

			commands.Add("wrists", s => Emote("slashes their wrists"));

			commands.Add("glassesadjust", s => Emote("adjusts their glasses"));
			commands.Add("train", s => { Emote("shouts \"CHOOO CHOO CHOO\"."); });
			commands.Add("agree", s => { Emote("nods in agreement."); });
			commands.Add("nod", s => { Emote("nods."); });
			commands.Add("amaze", s => { Emote("is amazed."); });
			commands.Add("angry", s => { Emote("raises their fist in anger."); });
			commands.Add("clap", s => { Emote("claps their hands."); });
			commands.Add("bark", s => { Emote("barks. Woof woof."); });
			commands.Add("beg", s => { Emote("falls to their knees and begs."); });
			commands.Add("burp", s => { Emote("lets out a loud belch."); });
			commands.Add("brb", s => { Emote(": \\qHAHA DISREGARD THAT I SUCK COCKS."); });
		}

		public override void OnConnected(Client c) {


			if (IsServer) {
				// Server-side connection handling 
				if (!c.isLocal) {
					channels.AddToGroup("global", c);
				}
			

			} else {
				// Client-side connection handling

			}

		}
	
		float timeout = 0;
		float cleanupTime = 100;
		public override void Update() {

			// Always Server Only...
			timeout += delta;
			if (timeout > cleanupTime) {
				timeout -= delta;
				channels.Prune();
			}

		}

		public override void OnDisconnected(Client c) {

			if (IsServer) {
				// Server side disconnection cleanup 
			

			} else {
				// Client side disconnection cleanup 

			}

		}
		/// <summary> Called on client to send a message on the current channel </summary>
		/// <param name="message"> message to send </param>
		public void Chat(string message) {
			if (message.StartsWith("/")) {
				// Handle macro
				string command = message.FromFirst('/').UpToFirst(' ');
				string rest = message.FromFirst(' ');

				commands.RunCommand(command, rest);

			} else {
				Say(message);
			}


		}

		/// <summary> RPC, Client->Server, client requests a message to be relayed to other clients.  </summary>
		/// <param name="msg"> RPC Message info </param>
		void ChatMessage(RPCMessage msg) {

			if (!loginModule.AUTHZ(msg.client, "chat")) { return; }

			string group = msg[0];
			string message = msg[1];
			string kind = msg[2];

			// TBD: Format/color message based on group 
			string identity = loginModule.Nickname(msg.client);
			string fullMessage = "invalid message";
			string timestamp = Timestamp(msg.recievedAt);

			if (kind.ToLower() == "say") {
				fullMessage = "\\q[" + timestamp + "] \\j" + identity + "\\w: " + message;
			} else if (kind.ToLower() == "me") {
				fullMessage = "\\q[" + timestamp + "] \\j" + identity + " " + message + "";
			}
		
			//Daemon.Print("Server got " + message + " for " + group);
			channels.Broadcast(group, "AddMessage", group, fullMessage);

		}
	

		/// <summary> RPC, Server->Client, server message to client. </summary>
		/// <param name="msg"></param>
		void AddMessage(RPCMessage msg) {
			string group = msg[0];
			string message = msg[1];

			// Clean up message
			message = message.RemoveAll('<');
			Daemon.RunOnMainThread(()=>{ onMessage?.Invoke(group, message); } );

			history.Add(message);
			if (history.Count > maxMessages) { history.RemoveAt(0); }

		}



		public static string Timestamp(DateTime date) {
			int hr = date.Hour;
			int min = date.Minute;
			int sec = date.Second;

			string str = "";
			if (hr < 10) { str += "0"; }
			str += hr + ":";
			if (min < 10) { str += "0"; }
			str += min + ":";
			if (sec < 10) { str += "0"; }
			str += sec;

			return str;
		}

	}

}
