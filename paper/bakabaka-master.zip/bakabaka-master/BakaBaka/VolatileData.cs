using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace BakaBaka {
	
	/// <summary> Class for holding data for use across different tasks. </summary>
	/// <remarks> 
	///		Basically a volatile, in-memory database.
	///		Expect data stored here to basically be stale instantly, some other task may have changed it.
	///		Such is life with typical async/concurrent programs.
	/// </remarks>
	/// 
	public class VolatileData : ConcurrentDictionary<string, object> {
		/// <summary> Static reference to a global instance of volatile data. </summary>
		public static VolatileData global = new VolatileData();

		/// <summary> Access to JsonObjects </summary>
		/// <remarks> So long as XtoJSON_ConcurrentObjects compile flag is set, JsonObjects are Concurrent. </remarks>
		public JsonObject JsonData { get; private set; }
		

		public VolatileData() {
			JsonData = new JsonObject();
			Daemon.Print("\\yNew instance of VolatileData produced.");
		}

		/// <summary> Gets a value from the Data Dictionary of this VolatileData </summary>
		/// <typeparam name="T"> Requested Type </typeparam>
		/// <param name="key"> Name of field to get </param>
		/// <param name="defaultValue"> Value to 'get' instead if <paramref name="key"/> doesn't exist in Data as a <typeparamref name="T"/> </param>
		/// <returns> Value of type <typeparamref name="T"/> at index <paramref name="key"/> if it exists, or <paramref name="defaultValue"/> if it does not.</returns>
		public T Get<T>(string key, T defaultValue = (default(T)) ) {
			if (ContainsKey(key)) {
				object val = this[key];
				if (typeof(T).IsAssignableFrom(val.GetType())) { return (T)val; }
			}
			return defaultValue;
		}


		/// <summary> Attempts to get a value from the Data Dictionary of this VolatileData </summary>
		/// <typeparam name="T"> Requested Type </typeparam>
		/// <param name="key"> Name of field to get </param>
		/// <param name="ret"> Place to write value obtained from the internal Dictionary </param>
		/// <returns> True, if the value was contained, and was assignable to type <typeparamref name="T"/>. False, otherwise. </returns>
		public bool Get<T>(string key, out T ret) {
			if (ContainsKey(key)) {
				object val = this[key];
					
				if (typeof(T).IsAssignableFrom(val.GetType())) { 
					ret = (T) val; 
					return true; 
				}
			}

			ret = default(T);
			return false;
		}
		
		/// <summary> Sets a value into the data. </summary>
		/// <param name="key"> Name of field to set </param>
		/// <param name="value"> Value to set field to </param>
		public void Set(string key, object value) {
			this[key] = value;
		}

		/// <summary> Remove a value from the data. </summary>
		/// <param name="key"> Key to remove </param>
		/// <returns> True if <paramref name="key"/> existed, false otherwise </returns>
		public bool Remove(string key) {
			object rem;
			return TryRemove(key, out rem);
		}
	
	}

}
