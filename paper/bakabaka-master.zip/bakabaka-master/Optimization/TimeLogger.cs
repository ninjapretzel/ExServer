using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Diagnostics;

/// <summary> Optimization utility for quickly injecting calls at speicifc points to track the time things take. </summary>
public class TimeLogger {
	public string name { get; private set; }
	private List<long> times;
	private List<string> tags;
	private Stopwatch sw;
	private bool logMS;

	public TimeLogger(string name = "unnamed logger", bool logMS = false) {
		this.name = name;
		this.logMS = logMS;
		times = new List<long>();
		tags = new List<string>();
		sw = new Stopwatch();
		sw.Start();
	}
	/// <summary> Logs the current time from when this TimeLogger was created as the given <paramref name="tag"/> </summary>
	/// <param name="tag"> Tag to log the current time with </param>
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	public void Log(string tag) { times.Add(logMS ? sw.ElapsedMilliseconds : sw.ElapsedTicks); tags.Add(tag); }
	public override string ToString() {
		string unit = (logMS ? "ms" : "ticks");
		StringBuilder str = name + " [total " + (logMS ? sw.ElapsedMilliseconds : sw.ElapsedTicks) + unit + "]";
		for (int i = 0; i < times.Count; i++) {
			str = str + "\n\t" + tags[i] + ": " + times[i] + unit;
		}
		return str.ToString();
	}
	/// <summary> Stops the Stopwatch backing the TimeLogger and returns the logs of all times. </summary>
	/// <returns> String log of all the times that have been logged </returns>
	public string Finish() {
		sw.Stop();
		return ToString();
	}
	public void Reset() {
		times.Clear();
		tags.Clear();
		sw.Reset();
		sw.Start();
	}
}
