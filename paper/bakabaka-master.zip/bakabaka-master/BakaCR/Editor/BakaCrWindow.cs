#if UNITY_EDITOR && !UNITY_WEBPLAYER
using UnityEngine;
using UnityEditor;
using System;
using System.Linq;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEditor.IMGUI.Controls;
using BakaCR;
using LevelUpper.Extensions;

namespace LevelUpper.Editor {

	public class BakaCrWindow : EditorWindowLevelUpper {
		
		[MenuItem("Baka/Repo Editor")]
		public static void ShowWindow() { 
			EditorWindow.GetWindow(typeof(BakaCrWindow)); 
		}


		[NonSerialized] string repoPath = "repo";
		[NonSerialized] float lineHeight = 18;
		
		[SerializeField] public float region = .3f;

		Repository repo;
		public Dictionary<string, bool> expanded;
		public Dictionary<string, string[]> children;


		public BakaCrWindow() {
			expanded = new Dictionary<string, bool>();
			children = new Dictionary<string, string[]>();

		}
		
		void OnGUI() {
			float topHeight = 0;
			Rect top = new Rect(0, 0, position.width, lineHeight);
			repoPath = EditorGUI.TextField(top.Left(.5f), repoPath);
			if (GUI.Button(top.Right(.5f), "Load/Reload")) {
				ReloadRepo();
			}
			
			topHeight += lineHeight;

			Rect rest = new Rect(0, topHeight, position.width, position.height - topHeight);


		}

		private void ReloadRepo(bool save = false) {
			expanded.Clear();
			if (repo != null) {
				repo.Close(save);
			}
			repo = Repository.Local(repoPath);
		}

		void OnEnable() {
			
		}


		void Update() { }
		void OnInspectorUpdate() { }
		
		void OnFocus() { }
		void OnLostFocus() { }

		void OnSelectionChange() { }
		void OnHierarchyChange() { }
		void OnProjectChange() { }
		
		void OnDestroy() { }
		
	}

	public class BakaCrTreeView : TreeView {

		public string repoPath { get; private set; }
		public BakaCrTreeView(TreeViewState treeViewState, string repoPath) : base(treeViewState) {
			this.repoPath = repoPath;
			items = new List<TreeViewItem>();
			pathIds = new Dictionary<string, int>();
			pathItems = new Dictionary<string, TreeViewItem>();
			Reload();
		}
		
		private List<TreeViewItem> items;
		private Dictionary<string, int> pathIds;
		private Dictionary<string, TreeViewItem> pathItems;
		

		TreeViewItem Item(string path) {
			if (pathItems.ContainsKey(path)) { return pathItems[path]; }
			int id = items.Count;
			TreeViewItem item = new TreeViewItem { id = id, displayName = path };
			items.Add(item);
			pathIds[path] = id;
			pathItems[path] = item;
			return item;
		}

		
		protected override TreeViewItem BuildRoot() {
			Repository repo = Repository.Local(repoPath);
			var treeViewRoot = Item("Root");
			treeViewRoot.depth = -1;

			var repoRoot = Item("/");
			treeViewRoot.AddChild(repoRoot);

			return treeViewRoot;
		}
		protected override IList<int> GetDescendantsThatHaveChildren(int id) {
			var item = items[id];
			List<int> ids = new List<int>();
			var trace = item;
			
			

			return ids;
		}
		private void Fill(TreeViewItem item, List<int> ids) {
			if (item.hasChildren) {
				foreach (var child in item.children) {
					Fill(child, ids);
				}
			}
			ids.Add(item.id);
		}

		protected override IList<TreeViewItem> BuildRows(TreeViewItem root) {
			return base.BuildRows(root);
		}

	}
	
}
#endif
