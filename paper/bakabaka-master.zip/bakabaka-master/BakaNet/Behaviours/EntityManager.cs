using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using BakaNet.Modules;

namespace BakaNet {

	public class EntityManager : ClientBehaviour {
	
		/// <summary> Singleton instance of this type. </summary>
		public static EntityManager main;

		/// <summary> Map of entity GUI to active entity objects </summary>
		private Dictionary<string, Entity> entities;

		/// <summary> SyncData context holding entity datas </summary>
		private SyncData entityData;

		/// <summary> Entity BakaNet module. </summary>
		private Entities entityModule;

		/// <summary> Current player entity </summary>
		public Entity playerEntity { get; private set; }
	
		public float moveDampening = 9;
		public float rotDampening = 11;
		float lastMoveDampening = -1;
		float lastRotDampening = -1;

		public Action<Entity, JsonObject> DefaultInterpolationFunction;


		/// <summary> Size to draw debug cells. </summary>
		public float cellSize = 13.33f;
		/// <summary> Distance to draw cells </summary>
		public int cellDist = 1;
		/// <summary> Is the currentMap a 3d one?</summary>
		public bool is3d = false;

		public static void UpdateDebugCellData(JsonObject obj) {
			if (main != null) {
				main.cellDist = obj.Pull("cellDist", 1);
				main.cellSize = obj.Pull("cellSize", 13.33f);
				main.is3d = obj.Pull("is3d", false);
			}
		}

		void Awake() {
			if (main != null) { Destroy(gameObject); return; }
			main = this;
			DontDestroyOnLoad(gameObject);

			entities = new Dictionary<string, Entity>();
			entityData = SyncData.Context("Entities");

		}
	
		void Start() {
		}
	
		void Update() {
			if (moveDampening != lastMoveDampening || rotDampening != lastRotDampening) {
				DefaultInterpolationFunction = Entity.SmoothInterpolationFunction(moveDampening, rotDampening);
				lastMoveDampening = moveDampening;
				lastRotDampening = rotDampening;
			}


			if (entityModule == null) { entityModule = GetModule<Entities>(); }

			if (entityModule?.localID != null) {

				foreach (var pair in entityData.locJson) {
					if (!entities.ContainsKey(pair.Key)) {
						Spawn(pair.Key.stringVal, pair.Value as JsonObject);
					}

				}

				List<string> toRemove = null;
				foreach (var pair in entities) {
					if (!entityData.locJson.ContainsKey(pair.Key)) {
						toRemove = toRemove ?? new List<string>();

						toRemove.Add(pair.Key);
					
					}
				}

				if (toRemove != null) {
					foreach (var guid in toRemove) {
						// Forcibly Despawn entity...
						// TBD: Do this more gracefully?
						Entity entity = entities[guid];
						entities.Remove(guid);
						Destroy(entity.gameObject);

					}	
				}

			}

			if (NetworkDaemon.main.debug_cells) {
				DrawDebugCells();
			}

		}

		void Spawn(string guid, JsonObject data) {
			if (data == null) { 
				Debug.LogWarning("Cannot spawn entity with non object data"); 
				return; 
			}
		
			Vector3 position = data.Pull("position", Vector3.zero);
			Quaternion rotation = data.Pull("rotation", Quaternion.identity);

			//Vector3 velocity = data.Pull("velocity", Vector3.zero);
			//Vector3 angularVelocity = data.Pull("angularVelocity", Vector3.zero);

			Transform anchor;
			Entity entity;
			entity = new GameObject(guid).AddComponent<Entity>();

			anchor = entity.transform;

			anchor.position = position;
			anchor.rotation = rotation;

			entities[guid] = entity;

			entityModule.onSpawnEntity?.Invoke(entity);
			if (guid == entityModule?.localID) {
				// We have a player!
				playerEntity = entity;
				entityModule.onSpawnPlayerEntity?.Invoke(entity);
			} else {
				// Regular entity.
				entityModule.onSpawnNonPlayerEntity?.Invoke(entity);
			}
			entity.interpolationFunction = DefaultInterpolationFunction;
		

		}



		private void DrawDebugCells() {
			var localEntity = Entity.localEntity;
			if (localEntity != null) {
				Vector3Int cellpos = Map.CellPositionFor(localEntity.transform.position, cellSize, is3d);
				int cellDist = Mathf.Clamp(this.cellDist, 0, 5);

				int startX = cellpos.x - cellDist;
				int endX = startX + cellDist * 2;
				int startY = cellpos.y - cellDist;
				int endY = startY + cellDist * 2;
				int startZ = cellpos.z - cellDist;
				int endZ = startZ + cellDist * 2;
				if (!is3d) { startY = endY = cellpos.y; }


				for (int x = startX; x <= endX; x++) {
					for (int y = startY; y <= endY; y++) {
						for (int z = startZ; z <= endZ; z++) {

							Vector3 center = new Vector3(x, y, z) * cellSize;

							if (!is3d) {
								Vector3 XZ = center + new Vector3(cellSize / 2f, 0, cellSize / 2f);
								Vector3 xZ = center + new Vector3(cellSize / -2f, 0, cellSize / 2f);
								Vector3 Xz = center + new Vector3(cellSize / 2f, 0, cellSize / -2f);
								Vector3 xz = center + new Vector3(cellSize / -2f, 0, cellSize / -2f);

								Debug.DrawLine(XZ, xZ, Color.red);
								Debug.DrawLine(Xz, xz, Color.red);
								Debug.DrawLine(XZ, Xz, Color.blue);
								Debug.DrawLine(xZ, xz, Color.blue);

							} else {

								Vector3 XYZ = center + new Vector3(cellSize / 2f, cellSize / 2f, cellSize / 2f);
								Vector3 xYZ = center + new Vector3(cellSize / -2f, cellSize / 2f, cellSize / 2f);
								Vector3 XyZ = center + new Vector3(cellSize / 2f, cellSize / -2f, cellSize / 2f);
								Vector3 xyZ = center + new Vector3(cellSize / -2f, cellSize / -2f, cellSize / 2f);

								Vector3 XYz = center + new Vector3(cellSize / 2f, cellSize / 2f, cellSize / -2f);
								Vector3 xYz = center + new Vector3(cellSize / -2f, cellSize / 2f, cellSize / -2f);
								Vector3 Xyz = center + new Vector3(cellSize / 2f, cellSize / -2f, cellSize / -2f);
								Vector3 xyz = center + new Vector3(cellSize / -2f, cellSize / -2f, cellSize / -2f);

								Debug.DrawLine(XYZ, xYZ, Color.red);
								Debug.DrawLine(XyZ, xyZ, Color.red);
								Debug.DrawLine(XYz, xYz, Color.red);
								Debug.DrawLine(Xyz, xyz, Color.red);

								Debug.DrawLine(XYZ, XyZ, Color.green);
								Debug.DrawLine(xYZ, xyZ, Color.green);
								Debug.DrawLine(XYz, Xyz, Color.green);
								Debug.DrawLine(xYz, xyz, Color.green);

								Debug.DrawLine(XYZ, XYz, Color.blue);
								Debug.DrawLine(xYZ, xYz, Color.blue);
								Debug.DrawLine(XyZ, Xyz, Color.blue);
								Debug.DrawLine(xyZ, xyz, Color.blue);

							}


						}
					}
				}

			}
		}

	}
}
