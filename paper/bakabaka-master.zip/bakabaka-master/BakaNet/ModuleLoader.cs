using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

using System.CodeDom.Compiler;
using Microsoft.CSharp;

using BakaNet.Utils;

namespace BakaNet {

	/// <summary> Holds logic for compiling and loading dynamic modules. </summary>
	public static class ModuleLoader {

		/// <summary> Temporary place to put 'extra' module types to load. </summary>
		public static List<Type> typesToLoad = new List<Type>();


		public static List<Type> FindModules() {
			List<Type> types = new List<Type>();
			var assemblies = AppDomain.CurrentDomain.GetAssemblies();
			Type modBase = typeof(Module);
			foreach (var assembly in assemblies) {
				foreach (var type in assembly.GetTypes()) {
					// ModuleBase just has some example code in it, no reason to hook into it
					if (type == modBase) { continue; } 

					if (modBase.IsAssignableFrom(type)) {
						LoadStaticType(type);
					}

				}
			}



			return types;
		}

		/// <summary> Reloads all dynamic modules </summary>
		public static void ReloadAll() {
			// Not doing this inside of unity... not yet at least. 
			// TBD: Find a secure way to provide/compile module code for user hosted servers...
			//		Dynamically compiling code is useful and could make this a very modular platform...
			//		but it's a bit risky to distribute something like this...
			//LoadModule(CompileModule());

			// For now, we will just have a list of types that get assigned to before this function is called
			foreach (var type in typesToLoad) {
				LoadStaticType(type);
			}
			
		}

		/// <summary> Searches all modules subfolders for module source files. </summary>
		/// <returns> string[] containing all paths to module source files. </returns>
		public static string[] CollectSource() {
			List<string> dirsToProcess = new List<string>();
			List<string> sources = new List<string>();
			dirsToProcess.Add(Directory.GetCurrentDirectory() + "/modules");

			while (dirsToProcess.Count > 0) {
				string dir = dirsToProcess[0]; dirsToProcess.RemoveAt(0);

				string[] dirs = Directory.GetDirectories(dir);
				dirsToProcess.AddRange(dirs);

				string[] srcFiles = Directory.GetFiles(dir, "*.cs");
				sources.AddRange(srcFiles);

			}

			return sources.ToArray();
		}

		/// <summary> Dynamically compiles source found by <see cref="CollectSource"/> </summary>
		/// <returns> Compiled <see cref="System.Reflection.Module"/> if successful, otherwise null. </returns>
		public static System.Reflection.Module CompileModule() {
			//string outputDir = Directory.GetCurrentDirectory() + "/dynamic";
			string[] sourceFiles = CollectSource();

			CompilerParameters compilerParams = new CompilerParameters();

			compilerParams.GenerateInMemory = true;
			compilerParams.IncludeDebugInformation = true;
			compilerParams.TreatWarningsAsErrors = false;
			compilerParams.GenerateExecutable = false;
			compilerParams.CompilerOptions = "/optimize";

			string[] references = { "System.dll", "System.Core.dll", "mscorlib.dll" };
			compilerParams.ReferencedAssemblies.AddRange(references);

			CSharpCodeProvider provider = new CSharpCodeProvider();
			CompilerResults compile = provider.CompileAssemblyFromFile(compilerParams, sourceFiles);
			if (compile.Errors.HasErrors) {
				StringBuilder str = "Compile Failed!\nErrors: ";
				foreach (var error in compile.Errors) {
					str = str + "\n" + error.ToString();
				}
				Debug.LogWarning(str);
				return null;
			}

			var modules = compile.CompiledAssembly.GetModules();
			if (modules.Length > 1) {
				Debug.LogWarning("More than one module was compiled! Check the module source! (Figure out what causes this!) ");
			}

			return modules[0];
		}


		/// <summary> Check the signature of a MethodInfo. </summary>
		/// <param name="info"> MethodInfo to check </param>
		/// <param name="name"> Optional parameter, if not null or empty, checked against <paramref name="info"/>'s Name. </param>
		/// <param name="paramTypes"> Optional parameter, if not null, is checked against <paramref name="info"/>'s Parameters. </param>
		/// <param name="returnType"> Optional parameter, if not null, is checked against <paramref name="info"/>'s ReturnType. </param>
		/// <returns> True, if the given <paramref name="info"/> matches the given parameters, and false otherwise. </returns>
		public static bool MatchesSig(this MethodInfo info, string name = null, Type[] paramTypes = null, Type returnType = null) {
			if ((name == null || name.Length == 0 || info.Name == name) && (returnType == null || info.ReturnType == returnType)) {

				if (paramTypes != null) {
					int numArgs = paramTypes.Length;
					var param = info.GetParameters();
					if (numArgs == param.Length) {
						for (int i = 0; i < numArgs; i++) {
							if (paramTypes[i] != param[i].ParameterType) { return false; }
						}
					}

				}
				return true;

			}
			return false;
		}

		/// <summary> Empty Type Params </summary>
		public static readonly Type[] EMPTY_PARAMS = { };
		/// <summary> Params for Module Update methods </summary>
		public static readonly Type[] UPDATE_PARAMS = { typeof(float) };
		/// <summary> Params for Module RPC Handler methods </summary>
		public static readonly Type[] RPC_HANDLER_PARAMS = { typeof(RPCMessage) };
		/// <summary> Params for Module Command methods </summary>
		public static readonly Type[] COMMAND_PARAMS = { typeof(string) };
		/// <summary> Params for Module Interaction methods </summary>
		public static readonly Type[] INTERACTION_PARAMS = { typeof(object), typeof(object), typeof(JsonObject) };
		/// <summary> Params for Module Connect/Disconnect methods</summary>
		public static readonly Type[] DIS_CONNECT_PARAMS = { typeof(Client) };

		/// <summary> Empty Arguments </summary>
		public static readonly object[] EMPTY_ARGS = { };
		


		/// <summary> Loads a dynamically compiled source code module. </summary>
		/// <param name="module"> Module contianing types to load. </param>
		public static void LoadModule(System.Reflection.Module module) {

			if (module != null) {

				Queue<Type> toLoad = new Queue<Type>();
				Type[] types = module.GetTypes();
				foreach (Type t in types) { toLoad.Enqueue(t); }

				while (toLoad.Count > 0) {
					Type type = toLoad.Dequeue();


					var nested = type.GetNestedTypes();
					foreach (var t in nested) { toLoad.Enqueue(t); }

					// Static classes are marked abstract and sealed. 
					if (type.IsAbstract && type.IsSealed) {
						LoadStaticType(type);
					}

					//if (type.BaseType == typeof(ServerComponent)) {
						//LoadComponent(type);
					//}


					/*
					var commandMapField = type.GetField("commandMap");
					if (commandMapField != null) {
						if (commandMapField.FieldType == typeof(Dictionary<string, Action>)) {
							var dict = commandMapField.GetValue(null) as Dictionary<string, Action>;
							foreach (var pair in dict) {
								string command = pair.Key;
								var method = pair.Value;
								var method = type.GetMethod(methodName, PUBLIC_STATIC);
								if (method != null) {
									if (method.MatchesSig("", COMMAND_PARAMS)) {
										Modules.commands[method.Name.ToLower()] = method;
									}
								}

							}

						}

					}	
					//*/
				}
			} else {
				Debug.LogWarning("ModuleLoader.LoadModule: Can't load a null module...");
			}

		}

		private readonly static BindingFlags PUBLIC_STATIC = BindingFlags.Public | BindingFlags.Static;
		/// <summary> Loads a module in a static context from a given type. </summary>
		/// <param name="type"> Type to load methods from. </param>
		public static void LoadStaticType(Type type) {
			MethodInfo[] methods = type.GetMethods(PUBLIC_STATIC);
			foreach (var method in methods) {
				//var param = method.GetParameters();
				/*
				if (method.MatchesSig("Load", EMPTY_PARAMS)) {
					Debug.Log("Calling Load for Module Type " + type.Name);
					try {
						method.Invoke(null, EMPTY_ARGS);
					} catch (Exception e) {
						Debug.LogWarning("ModuleLoader: Exception during [" + type.Name + "].Load(). " + e.InfoString());
					}

				} else if (method.MatchesSig("OnConnect", DIS_CONNECT_PARAMS)) {
					Modules.onConnect[type.Name] = method;
				} else if (method.MatchesSig("OnDisconnect", DIS_CONNECT_PARAMS)) {
					Modules.onDisconnect[type.Name] = method;
				} else if (method.MatchesSig("Update", UPDATE_PARAMS)) {
					Modules.updates[type.Name] = method;
				} else if (method.MatchesSig("", RPC_HANDLER_PARAMS)) {
					Modules.rpcHandlers[method.Name] = method;
				} else if (method.MatchesSig("", COMMAND_PARAMS)) {
					Modules.commands[method.Name.ToLower()] = method;
				} else if (method.MatchesSig("", INTERACTION_PARAMS)) {
					Modules.commands[method.Name.ToLower()] = method;
				}
				//*/
			}

		}


	}
}
